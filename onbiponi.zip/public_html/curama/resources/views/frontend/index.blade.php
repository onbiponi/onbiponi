@extends('layouts.front')
@section('content')
<div class="container bg-red">
    <div class="row justify-content-center">
    </div>
</div>
@endsection
