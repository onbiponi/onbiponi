<!DOCTYPE html>
<!-- saved from url=(0103)https:///C:/Users/Tanvir/Desktop/Compare%20cheap%20moving%20rates%20and%20rates!%20-Living%20market.html -->
<html lang="en" class="translated-ltr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <title>Compare cheap moving rates and rates!  -Living market</title>
    <meta name="description" content="ハウスクリーニングや家事代行、不用品回収、引越しなどの暮らしのサービスをオンラインで予約するなら「くらしのマーケット」。サービスを利用したユーザーの口コミ、満足度や具体的なサービス料金で簡単・便利に徹底比較！[保証制度完備！]">
    <meta name="keywords" content="くらしのマーケット,口コミ,評判,料金,相場">
    <meta name="format-detection" content="telephone=no">
    <meta property="og:title" content="くらしのマーケット - くらべておトク、プロのお仕事。">
    <meta property="og:description" content="ハウスクリーニングや家事代行、不用品回収、引越しなどの暮らしのサービスをオンラインで予約するなら「くらしのマーケット」。サービスを利用したユーザーの口コミ、満足度や具体的なサービス料金で簡単・便利に徹底比較！[保証制度完備！]">
    <meta property="og:image" content="https://cdn.curama.jp/common/image/facebook_tn.png">
    <meta name="robots" content="NOODP">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:site" content="@curama_jp">
    <meta name="norton-safeweb-site-verification" content="eiua9xdu203jyvdt-t3fwq7cr3ood0zfs9hfpmy-lo1biedsgn92olrq-937s7vesslkpdhnhiyp5czrtfkrl4yen8fnks4eow92h8ycbfshe2yehit2nsns8qpmw3wq">
    
    <link rel="dns-prefetch" href="<?php echo e(url('/')); ?>">
    <link rel="index" href="<?php echo e(url('/')); ?>">
    <link rel="canonical" href="">
    
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.curama.jp/static/pc/css/slick.css">
	<link rel="stylesheet" href="https://cdn.curama.jp/static/pc/css/slick-theme.css">
	<link rel="stylesheet" href="https://cdn.curama.jp/static/pc/css/style.css">
    
    
    <link rel="stylesheet" href="https://cdn.curama.jp/fonts/curama-icons/style.css">
	
	<script id="snaScript" async="" src="https://r2.snva.jp/javascripts/reco/2/sna.js"></script>
</head>
<body>
<div>
	<svg display="none" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
    <defs>
        <symbol id="tv" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                18.3,62.5 77.9,96.9 77.9,53.7 18.3,19.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                22,60.1 74.1,90.2 74.1,55.8 22,25.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                22.1,17 18.3,19.3 77.8,53.7 81.7,51.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                81.7,94.4 77.9,96.7 77.9,53.7 81.7,51.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                51.4,94.7 36.9,86.3 44.4,82 58.9,90.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                44.4,82 58.9,90.4 58.9,86.1 44.4,77.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                36.9,90.6 51.4,99 51.4,94.7 36.9,86.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                51.4,94.7 51.4,99 62.6,92.5 62.6,88.2 58.9,86.1 58.9,90.4"></polygon>
            </g>
        </symbol>
        <symbol id="tv-40" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                12.9,56.2 83.5,97 83.5,43.9 12.9,3.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                58.8,94.9 30.6,78.6 37.7,74.5 65.9,90.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,74.5 65.9,90.9 65.9,86.8 37.7,70.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                30.6,82.7 58.8,99 58.8,94.9 30.6,78.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                58.8,94.9 58.8,99 69.4,92.9 69.4,88.8 65.9,86.8 65.9,90.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                16.5,54.1 80,90.8 80,46 16.5,9.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                16.7,1 12.9,3.2 83.5,44 87.1,41.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                87.1,94.9 83.5,97 83.5,44 87.1,41.9"></polygon>
            </g>
        </symbol>
        <symbol id="tv-board" viewBox="0 0 100 100">
            <g>
                <polyline fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                51.9,52.8 75.5,66.2 75.5,61.8 1,19.2 1,23.7 24.5,37.1 24.5,63.7 51.9,79.5"></polyline><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                24.5,5.7 1,19.2 75.5,61.7 99,48.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                99,79.6 75.5,93 75.5,61.8 99,48.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                24.5,63.7 1,50.3 1,23.7 24.5,37.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                75.5,93 51.9,79.5 51.9,52.8 75.5,66.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                24.5,46 51.9,61.6 51.9,52.8 24.5,37.1"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.5" y1="46" x2="32.3" y2="41.6"></line><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                24.5,59.4 51.9,75.1 51.9,66.1 24.5,50.5"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.5" y1="59.4" x2="32.3" y2="55"></line>
            </g>
        </symbol>
        <symbol id="bed-single" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,71.2 7.1,53.5 59.2,23.4 89.8,41.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,71.2 7.1,53.5 59.2,23.4 89.8,41.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,78.3 37.7,71.2 7.1,53.5 7.1,60.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,81.9 37.7,78.3 7.1,60.6 7.1,64.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                89.8,41.2 89.8,48.2 37.7,78.3 37.7,71.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                89.8,48.2 89.8,51.8 37.7,81.9 37.7,78.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,88.9 40.8,87.2 40.8,80.1 37.7,81.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                34.6,80.1 34.7,87.2 37.7,88.9 37.7,81.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                7.1,64.2 7.1,71.2 10.2,73 10.2,65.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                10.2,65.9 10.2,73 13.2,71.2 13.2,67.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                89.8,51.8 89.8,58.8 86.8,57.1 86.8,53.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                92.9,57.1 89.8,58.9 89.8,30.5 92.9,28.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.2,12.8 89.8,30.5 92.9,28.8 62.3,11.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                89.8,41.2 89.8,30.5 59.2,12.8 59.2,23.4"></polygon>
            </g>
        </symbol>
        <symbol id="bed-semi-double" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.8,73 4,51.8 56.1,21.7 92.9,42.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.8,80.1 40.8,73 4,51.8 4,58.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.8,83.7 40.8,80.1 4,58.9 4,62.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                92.9,42.9 92.9,50 40.8,80.1 40.8,73"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                92.9,50 92.9,53.5 40.8,83.6 40.8,80.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.8,90.7 43.9,88.9 43.9,81.9 40.8,83.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.7,81.9 37.7,88.9 40.8,90.7 40.8,83.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                4,62.4 4,69.5 7.1,71.3 7.1,64.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                7.1,64.2 7.1,71.2 10.1,69.5 10.1,65.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                92.9,53.5 92.9,60.6 89.9,58.8 89.9,55.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                96,58.9 92.9,60.6 92.9,32.3 96,30.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.1,11.1 92.9,32.3 96,30.5 59.2,9.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                92.9,42.9 92.9,32.3 56.1,11.1 56.1,21.7"></polygon>
            </g>
        </symbol>
        <symbol id="bed-double" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                1,60.6 1,67.7 4.1,69.5 4.1,62.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                4.1,62.4 4.1,69.5 7.1,67.7 7.1,64.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                95.9,55.3 95.9,62.4 92.9,60.6 92.9,57"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                99,60.6 95.9,62.4 95.9,34.1 99,32.3"></polygon>
                <g><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                43.9,74.7 1,50 53.1,20 95.9,44.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                43.9,81.8 43.9,74.7 1,50 1,57.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                43.9,85.4 43.9,81.8 1,57.1 1,60.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                95.9,44.7 95.9,51.8 43.9,81.8 43.9,74.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                95.9,51.8 95.9,55.3 43.9,85.3 43.9,81.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                43.9,92.4 46.9,90.7 46.9,83.6 43.9,85.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.8,83.6 40.8,90.7 43.9,92.4 43.9,85.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.1,9.3 95.9,34.1 99,32.3 56.1,7.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                95.9,44.7 95.9,34.1 53.1,9.3 53.1,20"></polygon></g>
            </g>
        </symbol>
        <symbol id="futon" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M64.8,88.1c0-0.7,34.2-28.7,34.2-28.7l0,0c0-1.5-0.8-2.8-2.1-3.6l-0.3-0.2L40.4,23.1L4,43.9c-1.8,1.1-3,3-3,5.1v4.3
                c0,2.1,1.1,4.1,2.9,5.1l52.8,30.6c1.9,1.1,4.3,1.1,6.3,0L64.8,88.1"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M93.1,36.7l-0.7-0.4l0,0L48.3,10.9c-1.8-1-4.1-1-5.9,0L9.1,30c-1.8,1-3,3-3,5.1l0,10.1c0,2.1,1.1,4.1,3,5.1L51.9,75
                c1.9,1.1,4.3,1.1,6.3,0l0.9-0.5h0c-1.8,1-4-0.3-4-2.3v-0.7v-8c0-2.2,1.2-4.2,3.1-5.2l26.2-13.9l9.7-4.5v-1.4
                C94.1,37.7,93.7,37.1,93.1,36.7z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M89.2,51.4L61.6,67c-0.9,0.5-2-0.1-2-1.2v-1.4c0-0.9,0.5-1.8,1.3-2.3l30.3-17.5c1.3-0.8,2.9,0.2,2.9,1.7l0,4.5
                c0,2.1-1.1,4.1-2.9,5.1L59.4,74.2c-2,1.1-4.4-0.3-4.4-2.6l0-8.3c0-2.1,1.1-4,2.9-5.1l34.7-20.1c0.7-0.4,1.5,0.1,1.5,0.9l0,1.9
                c0,1.3-0.7,2.4-1.8,3l-1.7,1"></path><polygon fill="#F8F8F8" points="29,31.7 55.3,46.9 75,35.5 48.7,20.3 		"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M29.1,31.7c0,0,2.6,1.3,3.6,1.9c1.1,0.6,18.5,10.6,19.5,11.3c1.1,0.7,2.9,1.9,2.9,1.9s0.8-1.1,2.2-2.3c1.4-1.1,9.6-8,10.9-9
                c1.6-1.3,4.5-2.8,4.5-2.8s-3-3-4.2-3.7c-2.5-1.5-14.2-9.1-19.7-10.7c-1.3-0.4-2.1-0.1-2.1-0.1s-1.4,0.5-2.9,1.7s-9.6,7.4-10.8,8.3
                C30.7,29.9,29.1,31.7,29.1,31.7z"></path><path fill="#F8F8F8" d="M29.1,31.7c0,0,2.6,1.3,3.6,1.9c1.1,0.6,18.5,10.6,19.5,11.3c1.1,0.7,2.9,1.9,2.9,1.9s0.8-1.1,2.2-2.3
                c1.4-1.1,9.6-8,10.9-9c1.6-1.3,4.5-2.8,4.5-2.8l-1.4-0.2c0,0-3.5,2-4.5,2.4c-1.1,0.4-10.8,8.2-10.8,8.2s-9.1-5.4-11.2-6.6
                c-1.4-0.8-5.6-3.5-9.9-4.7C34.3,31.7,29.1,31.7,29.1,31.7"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M29.1,31.7c0,0,2.6,1.3,3.6,1.9c1.1,0.6,18.5,10.6,19.5,11.3c1.1,0.7,2.9,1.9,2.9,1.9s0.8-1.1,2.2-2.3c1.4-1.1,9.6-8,10.9-9
                c1.6-1.3,4.5-2.8,4.5-2.8s-3-3-4.2-3.7c-2.5-1.5-14.2-9.1-19.7-10.7c-1.3-0.4-2.1-0.1-2.1-0.1s-1.4,0.5-2.9,1.7s-9.6,7.4-10.8,8.3
                C30.7,29.9,29.1,31.7,29.1,31.7z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M99,60.9v-1.1c0-1.2-1.3-2-2.4-1.4l-2.5,1.4L61.9,78.5c-1.2,0.7-1.9,2-1.9,3.4l0,4.6c0,2,2.1,3.2,3.8,2.2l30.3-17.5l0,0l0,0l0.1,0
                v0l0.5-0.3l2.8-1.6c0,0,0,0,0,0l0.1-0.1c0.9-0.5,1.5-1.5,1.5-2.6v-0.2c0,0,0,0,0,0l0-0.2l0,0v-0.1c0,0,0,0,0,0l0-0.1v-0.9
                c0-1.1-1.2-1.8-2.1-1.2l0.6-0.4C98.4,63,99,62,99,60.9z"></path><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="64.6" y1="82.4" x2="96.9" y2="63.9"></line>
            </g>
        </symbol>
        <symbol id="sofa" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M80.3,47.3L78,46L47.6,63.5c-1,0.6-1.6,1.6-1.6,2.8v21.2l4,2.3l0-21.2c0-1.1,0.6-2.2,1.6-2.8L76,51.7l6,0.8l0-2.4
                C82,48.9,81.3,47.9,80.3,47.3z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M48.4,16.8l-2.9,1.6C44.6,19,44,20,43.9,21.1L42,48.2l16,9.3l11.9-7L71.7,37c0.1-1,0.7-1.9,1.6-2.4l2.2-1.2l2.4,1.4l0-0.9
                c0-1.1-0.6-2.2-1.6-2.8L51.6,16.9C50.6,16.3,49.4,16.3,48.4,16.8z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M77.9,45.9l0-11.1c0-1.2-1.3-2-2.4-1.4L74,34.3c-1.3,0.7-2.2,2.1-2.4,3.5l-1.7,12.7L77.9,45.9z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M43,33.8L19.6,47.3c-1,0.6-1.6,1.6-1.6,2.8v21.2l4,2.3l0-21.2c0-1.1,0.6-2.2,1.6-2.8l19-11L43,33.8z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                22,69 46,82.8 46,87.5 22,73.6"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M58,57.5l-16-9.3L22.8,59.3c-0.5,0.3-0.8,0.8-0.8,1.4l0,8.3l24,13.9v-9.3v-7.4c0-1.1,0.6-2.2,1.6-2.8L58,57.5z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                18,80.5 18,71.3 22,73.6 22,82.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,75.9 26,80.5 22,82.8 22,73.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                81.9,80.5 81.9,71.3 78,73.6 78,82.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                74,75.9 74,80.5 78,82.8 78,73.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,99 50,89.8 54,87.5 54,96.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                46,87.5 46,96.7 50,99 50,89.8"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M82,71.3V51c0-1.2-1.3-2-2.4-1.4l-28,16.2c-1,0.6-1.6,1.6-1.6,2.8l0,21.2L82,71.3z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M42.7,38.6l-19,11c-1,0.6-1.6,1.6-1.6,2.8l0,7.4L42,48.2L42.7,38.6z"></path>
            </g>
        </symbol>
        <symbol id="sofa-2" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M93,46.5l-2.4-1.3L59.7,62.9c-1,0.6-1.6,1.7-1.6,2.8v21.6l4.1,2.3l0-21.5c0-1.2,0.6-2.2,1.6-2.8l24.8-14.4l6.1,0.8l0-2.4
                C94.7,48.1,94,47,93,46.5z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M36.2,1.4l-2.9,1.7c-0.9,0.5-1.6,1.5-1.6,2.6l-2,27.6l40.6,23.5l12.1-7.1L84.3,36c0.1-1,0.7-1.9,1.6-2.4l2.2-1.3l2.4,1.4l0-0.9
                c0-1.2-0.6-2.2-1.6-2.8L39.4,1.4C38.4,0.9,37.2,0.9,36.2,1.4z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M90.5,45.1l0-11.3c0-1.3-1.4-2-2.4-1.4l-1.5,0.9c-1.3,0.8-2.2,2.1-2.4,3.6l-1.7,12.9L90.5,45.1z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.7,18.7L7,32.4c-1,0.6-1.6,1.7-1.6,2.8v21.6l4.1,2.4l0-21.6c0-1.2,0.6-2.2,1.6-2.8l19.3-11.2L30.7,18.7z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                9.4,54.4 58.1,82.6 58.1,87.3 9.4,59.1"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70.3,56.8L29.6,33.3L10.2,44.6c-0.5,0.3-0.8,0.8-0.8,1.4l0,8.5l48.7,28.2v-9.4v-7.5c0-1.2,0.6-2.2,1.6-2.8L70.3,56.8z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                5.3,66.1 5.3,56.8 9.4,59.1 9.4,68.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                13.4,61.5 13.4,66.1 9.4,68.5 9.4,59.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                94.6,80.2 94.6,70.9 90.6,73.2 90.6,82.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                86.6,75.6 86.6,80.2 90.6,82.6 90.6,73.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                62.2,99 62.2,89.6 66.2,87.3 66.2,96.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                58.1,87.3 58.1,96.7 62.2,99 62.2,89.6"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M94.7,70.9V50.2c0-1.3-1.4-2-2.5-1.4L63.8,65.3c-1,0.6-1.6,1.7-1.6,2.8l0,21.5L94.7,70.9z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.3,23.5L11,34.7c-1,0.6-1.6,1.7-1.6,2.8l0,7.5l20.2-11.7L30.3,23.5z"></path>
            </g>
        </symbol>
        <symbol id="sofa-3" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M97.1,51l-2.2-1.2L66.5,66.2c-0.9,0.5-1.5,1.5-1.5,2.6v19.9l3.7,2.1l0-19.8c0-1.1,0.6-2.1,1.5-2.6l22.8-13.2l5.6,0.7l0-2.2
                C98.7,52.6,98.1,51.6,97.1,51z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M29.8,0.9l-2.7,1.5c-0.9,0.5-1.4,1.4-1.5,2.4l-1.8,25.5l52.5,30.3L87.4,54l1.7-12.6c0.1-0.9,0.7-1.8,1.5-2.2l2-1.2l2.3,1.3l0-0.9
                c0-1.1-0.6-2.1-1.5-2.6l-60.6-35C31.8,0.4,30.7,0.4,29.8,0.9z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M94.9,49.7l0-10.4c0-1.2-1.2-1.9-2.3-1.3l-1.4,0.8c-1.2,0.7-2.1,1.9-2.2,3.3L87.4,54L94.9,49.7z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M24.7,16.8L2.8,29.4C1.9,30,1.3,31,1.3,32v19.9l3.7,2.2l0-19.9c0-1.1,0.6-2.1,1.5-2.6l17.8-10.4L24.7,16.8z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                5.1,49.8 65,84.4 65,88.7 5.1,54.1"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M76.2,60.6L23.7,30.3L5.8,40.7C5.3,41,5.1,41.4,5.1,42l0,7.8L65,84.4v-8.7v-6.9c0-1.1,0.6-2.1,1.5-2.6L76.2,60.6z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                1.3,60.6 1.3,51.9 5.1,54.1 5.1,62.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                8.8,56.3 8.8,60.6 5.1,62.7 5.1,54.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                98.7,82.2 98.7,73.6 94.9,75.7 94.9,84.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                91.2,77.9 91.2,82.2 94.9,84.4 94.9,75.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                68.7,99.5 68.7,90.9 72.5,88.7 72.5,97.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                65,88.7 65,97.3 68.7,99.5 68.7,90.9"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M98.7,73.6v-19c0-1.2-1.3-1.9-2.3-1.3L70.2,68.4c-0.9,0.5-1.5,1.5-1.5,2.6l0,19.8L98.7,73.6z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M24.4,21.3L6.6,31.6c-0.9,0.5-1.5,1.5-1.5,2.6l0,6.9l18.7-10.8L24.4,21.3z"></path>
            </g>
        </symbol>
        <symbol id="low-table" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                1,32.6 1,28.2 61.3,63.1 61.3,67.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                1,28.2 38.7,6.5 99,41.3 61.3,63.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                99,45.6 61.3,67.4 61.3,63.1 99,41.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                61.3,93.5 61.3,67.4 65.1,65.2 65.1,91.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.5,91.3 57.5,65.2 61.3,67.4 61.3,93.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                95.2,73.9 95.2,47.8 99,45.6 99,71.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                91.5,71.8 91.5,50 95.2,47.8 95.2,73.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                4.8,60.9 4.8,34.8 8.5,36.9 8.5,58.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                1,58.7 1,32.6 4.8,34.8 4.8,60.9"></polygon>
            </g>
        </symbol>
        <symbol id="kotatsu" viewBox="0 0 100 100">
            <g>
               <g><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.4,33.6 82.4,33.6 82.4,33.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,33.6 17.6,33.6 17.6,33.6"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M82.4,33.6C82.4,33.6,82.4,33.6,82.4,33.6L50,52.3L37.4,45L17.6,33.6l0,0l0,0c0,0-0.5,0.3-0.8,1.5c-0.3,1.1-1.8,4.5-2.1,6.2
                c-0.1,0.7,0,1.8,0.1,2.1c0,0-0.1,0.1-0.1,0.1c-0.2,0.1-0.9,0.4-1.4,1c-0.6,0.7-2.4,4.5-3,5.5c-0.7,1.1-0.5,1.8-0.5,1.8
                s-0.8,0-1.4,0.7c-0.8,0.8-3,3.4-4.1,4.7c-0.4,0.4-0.3,1.2-0.3,1.2S3.4,58,2.8,58.5c-0.5,0.4-0.8,0.8-1.1,1
                c-1.5,1.2-0.4,2.1-0.4,2.1l6.3,3.6l39.2,22.6c2,1.1,4.4,1.1,6.4,0l39-22.6"></path></g><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,33.6 17.6,29.8 50,48.5 50,52.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,29.8 50,11.1 82.4,29.8 50,48.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.4,33.6 50,52.3 50,48.5 82.4,29.8"></polygon><g><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.4,33.6 82.4,33.6 82.4,33.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,33.6 17.6,33.6 17.6,33.6"></polygon></g><g><polygon fill="#FFFFFF" points="82.4,33.6 82.4,33.6 82.4,33.6"></polygon><polygon fill="#FFFFFF" points="17.6,33.6 17.6,33.6 17.6,33.6"></polygon></g><g><path fill="#F8F8F8" d="M52.5,88c0.2-1-0.7-2.4-1-3c-0.5-0.9-1.5-0.7-1.1-0.7s1-0.9,0.9-2.1c-0.1-0.7-0.4-4.8-0.4-5.9
                c0-0.7-0.8-1.3-0.8-1.3s0.9-0.7,0.8-1.8c-0.1-0.9-0.2-7.9-0.2-7.9s0.1-1.3-0.6-1.7c0.5-0.3,0.4-1.3,0.4-1.3s0.2-4.7,0.2-7.2
                c0-2.5-0.7-2.8-0.7-2.8l32.4-18.7c0,0,0.5,0.3,0.8,1.5c0.3,1.1,1.8,4.5,2.1,6.2c0.1,0.7,0,1.8-0.1,2.1c0,0,0.1,0.1,0.1,0.1
                c0.2,0.1,0.9,0.4,1.4,1c0.6,0.7,2.4,4.5,3,5.5c0.7,1.1,0.5,1.8,0.5,1.8s0.8,0,1.4,0.7c0.8,0.8,3,3.4,4.1,4.7
                c0.4,0.4,0.3,1.2,0.3,1.2s0.6-0.2,1.1,0.3c0.5,0.4,0.8,0.8,1.1,1c1.5,1.2,0.4,2.1,0.4,2.1l-6.3,3.6L52.5,88z"></path><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,33.6 17.6,33.6 17.6,33.6"></polygon><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.4,33.6 82.4,33.6 82.4,33.6"></polygon><path fill="#F8F8F8" d="M51.1,64.1L15,43.3c0,0-0.2-1.8-0.2-2.3c0.9,1.1,36.6,21.1,36.6,21.1L51.1,64.1z"></path><path fill="#F8F8F8" d="M51.5,75.8l-41.6-24c0,0,0.2-1.4,0.2-1.9c0.9,1.1,41.7,24,41.7,24L51.5,75.8z"></path><path fill="#F8F8F8" d="M51.4,81.5c0,0-0.9,1.1-2.8,0c-3.8-2.2-43.1-24.5-44-25.5c0,0.5-0.7,2.1-0.7,2.1l44.5,25.7l0,0l0,0
                l0.4,0.2l0-0.1c0.7,0.2,2.1,0.6,3.2-0.2C53.7,82.9,51.4,81.5,51.4,81.5z"></path><path fill="#F8F8F8" d="M52.6,85.8c0,0-1.8,1.6-4.9-0.1C43.8,83.5,2.9,60.3,2,59.3c-1.3,1.3-0.6,2-0.6,2l47,27.2l0,0l0,0l0.4,0.2
                l0-0.1c0.7,0.2,2.1,0.6,3.2-0.2C53.7,87.4,52.6,85.8,52.6,85.8z"></path></g><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M96.1,58.2L51.6,83.9c-1,0.6-2.2,0.6-3.2,0L3.9,58.2"></path><g><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.4,33.6 82.4,33.6 82.4,33.6"></polygon><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,33.6 17.6,33.6 17.6,33.6"></polygon><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M82.4,33.6C82.4,33.6,82.4,33.6,82.4,33.6L50,52.3L37.4,45L17.6,33.6l0,0l0,0c0,0-0.5,0.3-0.8,1.5c-0.3,1.1-1.8,4.5-2.1,6.2
                c-0.1,0.7,0,1.8,0.1,2.1c0,0-0.1,0.1-0.1,0.1c-0.2,0.1-0.9,0.4-1.4,1c-0.6,0.7-2.4,4.5-3,5.5c-0.7,1.1-0.5,1.8-0.5,1.8
                s-0.8,0-1.4,0.7c-0.8,0.8-3,3.4-4.1,4.7c-0.4,0.4-0.3,1.2-0.3,1.2S3.4,58,2.8,58.5c-0.5,0.4-0.8,0.8-1.1,1
                c-1.5,1.2-0.4,2.1-0.4,2.1l6.3,3.6l39.2,22.6c2,1.1,4.4,1.1,6.4,0l39-22.6"></path></g><g><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                17.6,33.6 17.6,33.6 17.6,33.6"></polygon><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.4,33.6 82.4,33.6 82.4,33.6"></polygon><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M82.4,33.6c0,0,0.5,0.3,0.8,1.5c0.3,1.1,1.8,4.5,2.1,6.2c0.1,0.7,0,1.8-0.1,2.1c0,0,0.1,0.1,0.1,0.1c0.2,0.1,0.9,0.4,1.4,1
                c0.6,0.7,2.4,4.5,3,5.5c0.7,1.1,0.5,1.8,0.5,1.8s0.8,0,1.4,0.7c0.8,0.8,3,3.4,4.1,4.7c0.4,0.4,0.3,1.2,0.3,1.2s0.6-0.2,1.1,0.3
                c0.5,0.4,0.8,0.8,1.1,1c1.5,1.2,0.4,2.1,0.4,2.1l-6.3,3.6"></path></g>
            </g>
        </symbol>
        <symbol id="color-box" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                24.2,13.8 27.9,15.9 27.9,84.1 24.2,82"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,28.7 53.7,30.8 53.7,99 50,96.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,79.8 27.9,62.8 50,75.6 50,92.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,62.8 27.9,79.8 42.6,71.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,58.6 27.9,41.5 50,54.3 50,71.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,41.5 27.9,58.6 42.6,50.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,37.2 27.9,20.2 50,33 50,50"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,20.2 27.9,37.2 46.3,26.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,84.1 27.9,79.8 50,92.6 50,96.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,62.8 27.9,58.5 50,71.3 50,75.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,41.5 27.9,37.3 50,50.1 50,54.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,20.2 27.9,15.9 50,28.7 50,33"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.7,99 75.8,86.2 75.8,18 53.7,30.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                46.3,1 75.8,18 53.7,30.8 24.2,13.8"></polygon><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="27.9" y1="15.9" x2="50" y2="3.1"></line><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="28.7" x2="72.1" y2="15.9"></line>
            </g>
        </symbol>
        <symbol id="clothes-chest" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,79.4 54.2,99 54.2,94.1 20.3,74.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,59.8 54.2,79.4 54.2,74.5 20.3,54.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,74.5 54.2,94.1 54.2,79.4 20.3,59.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                33,72.1 41.5,77 41.5,72 33,67.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,40.2 54.2,59.8 54.2,54.9 20.3,35.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,54.9 54.2,74.5 54.2,59.8 20.3,40.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                33,52.5 41.5,57.4 41.5,52.4 33,47.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,20.6 54.2,40.2 54.2,35.3 20.3,15.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.3,35.3 54.2,54.9 54.2,40.2 20.3,20.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                33,32.9 41.5,37.8 41.5,32.8 33,28"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                45.8,1 20.3,15.7 54.2,35.3 79.7,20.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.7,84.3 79.7,20.6 54.2,35.3 54.2,99"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.7,25.5 54.2,40.2 54.2,35.3 79.7,20.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.7,45.1 54.2,59.8 54.2,54.9 79.7,40.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.7,64.7 54.2,79.4 54.2,74.5 79.7,59.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.7,84.3 54.2,99 54.2,94.1 79.7,79.4"></polygon>
            </g>
        </symbol>
        <symbol id="rack-small" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.2,54.2 44.1,43.9 73.8,61.1 56,71.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.2,33.6 44.1,23.3 73.8,40.5 56,50.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.2,74.9 44.1,64.5 73.8,81.7 56,92"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.2,78.3 56,95.5 56,92 26.2,74.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                73.8,85.2 56,95.5 56,92 73.8,81.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.2,57.7 56,74.9 56,71.4 26.2,54.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                73.8,64.5 56,74.9 56,71.4 73.8,61.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.2,37 56,54.2 56,50.8 26.2,33.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                73.8,43.9 56,54.2 56,50.8 73.8,40.5"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,69.6V53.7l-1,0.6l-1-0.6v15.9h0c0,0.4,0.4,0.7,1,0.7C56.5,70.3,57,70,57,69.6C57,69.6,57,69.6,57,69.6z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,90.2V74.3l-1,0.6l-1-0.6v15.9h0c0,0.4,0.4,0.7,1,0.7C56.5,90.9,57,90.6,57,90.2C57,90.2,57,90.2,57,90.2z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,99.3v-4.4l-1,0.6l-1-0.6v4.4h0c0,0.4,0.4,0.7,1,0.7C56.5,100,57,99.7,57,99.3L57,99.3z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.2,54.1V39.3l-1-0.6l-1-0.6v15.9h0c0,0.4,0.4,0.7,1,0.7S30.2,54.5,30.2,54.1L30.2,54.1z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.2,74.7V59.9l-1-0.6l-1-0.6v15.9h0c0,0.4,0.4,0.7,1,0.7S30.2,75.1,30.2,74.7L30.2,74.7z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.2,83.8v-3.3l-1-0.6l-1-0.6v4.4h0c0,0.4,0.4,0.7,1,0.7S30.2,84.2,30.2,83.8L30.2,83.8z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M69.8,61V46.2l1-0.6l1-0.6V61h0c0,0.4-0.4,0.7-1,0.7C70.3,61.7,69.8,61.4,69.8,61L69.8,61z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M69.8,81.6V66.8l1-0.6l1-0.6v15.9h0c0,0.4-0.4,0.7-1,0.7C70.3,82.3,69.8,82,69.8,81.6L69.8,81.6z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M69.8,90.7v-3.3l1-0.6l1-0.6v4.4h0c0,0.4-0.4,0.7-1,0.7C70.3,91.5,69.8,91.1,69.8,90.7L69.8,90.7z"></path>
            </g>
        </symbol>
        <symbol id="rack-large" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,52.9 44,42.5 74,59.8 56,70.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,32.2 44,21.8 74,39.1 56,49.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,73.7 44,63.3 74,80.6 56,91"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,77.1 56,94.4 56,91 26,73.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                74,84 56,94.4 56,91 74,80.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,56.4 56,73.7 56,70.2 26,52.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                74,63.3 56,73.7 56,70.2 74,59.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,35.6 56,52.9 56,49.4 26,32.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                74,42.5 56,52.9 56,49.4 74,39.1"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,68.4v-16l-1,0.6l-1-0.6v16h0c0,0.4,0.4,0.7,1,0.7S57,68.7,57,68.4C57,68.4,57,68.4,57,68.4z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,89.1v-16l-1,0.6l-1-0.6v16h0c0,0.4,0.4,0.7,1,0.7S57,89.5,57,89.1C57,89.1,57,89.1,57,89.1z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,98.3v-4.4l-1,0.6l-1-0.6v4.4h0c0,0.4,0.4,0.7,1,0.7S57,98.7,57,98.3L57,98.3z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30,52.8V37.9l-1-0.6l-1-0.6v16h0c0,0.4,0.4,0.7,1,0.7S30,53.2,30,52.8L30,52.8z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30,73.5V58.7l-1-0.6l-1-0.6v16h0c0,0.4,0.4,0.7,1,0.7S30,73.9,30,73.5L30,73.5z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30,82.7v-3.3l-1-0.6l-1-0.6v4.4h0c0,0.4,0.4,0.7,1,0.7S30,83.1,30,82.7L30,82.7z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70,59.7V44.8l1-0.6l1-0.6v16h0c0,0.4-0.4,0.7-1,0.7C70.4,60.4,70,60.1,70,59.7L70,59.7z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,11.4 44,1 74,18.3 56,28.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26,14.8 56,32.1 56,28.7 26,11.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                74,21.8 56,32.1 56,28.7 74,18.3"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,47.6v-16l-1,0.6l-1-0.6v16h0c0,0.4,0.4,0.7,1,0.7S57,48,57,47.6L57,47.6z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30,32V17.1l-1-0.6L28,16v16h0c0,0.4,0.4,0.7,1,0.7S30,32.4,30,32L30,32z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70,38.9V24.1l1-0.6l1-0.6v16h0c0,0.4-0.4,0.7-1,0.7C70.4,39.7,70,39.3,70,38.9L70,38.9z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70,80.5V65.6l1-0.6l1-0.6v16h0c0,0.4-0.4,0.7-1,0.7C70.4,81.2,70,80.9,70,80.5L70,80.5z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70,89.7v-3.3l1-0.6l1-0.6v4.4h0c0,0.4-0.4,0.7-1,0.7C70.4,90.4,70,90.1,70,89.7L70,89.7z"></path>
            </g>
        </symbol>
        <symbol id="shelf" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.6,7.8 29.5,9.5 29.5,80.4 26.6,78.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                58.8,26.4 61.7,28 61.7,99 58.8,97.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,77 29.5,63.5 58.8,80.4 58.8,93.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,63.5 29.5,77 41.2,70.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,63.5 29.5,50 58.8,66.9 58.8,80.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,50 29.5,63.5 41.2,56.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,50 29.5,36.5 58.8,53.4 58.8,66.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,36.5 29.5,50 41.2,43.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,36.5 29.5,26.3 58.8,43.2 58.8,53.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,26.3 29.5,36.5 38.3,31.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,80.4 29.5,77 58.8,93.9 58.8,97.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,66.9 29.5,63.5 58.8,80.4 58.8,83.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,53.4 29.5,50 58.8,66.9 58.8,70.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,39.9 29.5,36.5 58.8,53.4 58.8,56.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,26.3 29.5,23 58.8,39.9 58.8,43.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                61.7,99 73.4,92.2 73.4,21.3 61.7,28"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                38.3,1 73.4,21.3 61.7,28 26.6,7.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,23 29.5,12.8 58.8,29.7 58.8,39.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,12.8 29.5,23 38.3,17.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.5,12.8 29.5,9.5 58.8,26.4 58.8,29.7"></polygon><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="29.5" y1="9.5" x2="41.2" y2="2.7"></line><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="70.5" y1="19.6" x2="58.8" y2="26.3"></line>
            </g>
        </symbol>
        <symbol id="chest" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.8,70.1 53.7,87.4 53.7,70.1 23.8,52.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.8,74.4 53.7,91.7 53.7,87.4 23.8,70.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.8,18.3 53.7,35.6 53.7,31.2 23.8,14"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                46.3,1 23.8,14 53.7,31.2 76.2,18.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                76.2,78.8 76.2,18.3 53.7,31.2 53.7,91.7"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M55,98.1V91l-1.3,0.7L52.5,91v7.1h0c0,0.5,0.6,0.9,1.2,0.9S55,98.6,55,98.1L55,98.1z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M72.7,86.6v-5.7l1.3-0.7l1.2-0.7v7.2h0c0,0.5-0.6,0.9-1.2,0.9S72.7,87.1,72.7,86.6L72.7,86.6z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M27.3,82.2v-5.7L26,75.7L24.8,75v7.2h0c0,0.5,0.6,0.9,1.2,0.9S27.3,82.7,27.3,82.2L27.3,82.2z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.7,35.6 76.2,22.6 76.2,18.3 53.7,31.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.7,91.7 76.2,78.8 76.2,74.4 53.7,87.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.7,87.4 55.6,86.3 55.6,69 53.7,70.1"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M33.8,69.1c-0.1-0.4-0.2-1.2-0.1-1.6c0.1-0.5,0.4-0.6,0.6-0.6c0.4,0,0.6,0.4,0.6,0.5c0,0-0.2,1.6,1.8,3c2.9,1.9,5.6,1.4,5.6,1.4
                c0.4,0,0.7,0.3,0.8,0.5c0.1,0.4,0,0.7-0.2,0.8c-0.2,0.1-0.6,0.1-0.6,0.1s-2.9,0.5-5.9-1.3C34.5,70.8,34,69.8,33.8,69.1z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.8,52.8 53.7,70.1 53.7,52.8 23.8,35.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.7,70.1 55.6,69 55.6,51.8 53.7,52.8"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M33.8,51.8c-0.1-0.4-0.2-1.2-0.1-1.6c0.1-0.5,0.4-0.6,0.6-0.6c0.4,0,0.6,0.4,0.6,0.5c0,0-0.2,1.6,1.8,3c2.9,1.9,5.6,1.4,5.6,1.4
                c0.4,0,0.7,0.3,0.8,0.5c0.1,0.4,0,0.7-0.2,0.8C42.8,56,42.4,56,42.4,56s-2.9,0.5-5.9-1.3C34.5,53.5,34,52.6,33.8,51.8z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.8,35.6 53.7,52.8 53.7,35.6 23.8,18.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.7,52.8 55.6,51.8 55.6,34.5 53.7,35.6"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M33.8,34.6c-0.1-0.4-0.2-1.2-0.1-1.6c0.1-0.5,0.4-0.6,0.6-0.6c0.4,0,0.6,0.4,0.6,0.5c0,0-0.2,1.6,1.8,3c2.9,1.9,5.6,1.4,5.6,1.4
                c0.4,0,0.7,0.3,0.8,0.5c0.1,0.4,0,0.7-0.2,0.8c-0.2,0.1-0.6,0.1-0.6,0.1s-2.9,0.5-5.9-1.3C34.5,36.2,34,35.3,33.8,34.6z"></path>
            </g>
        </symbol>
        <symbol id="wardrobe-small" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.9,76.4 56.5,95.2 56.5,80.2 23.9,61.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.9,80.2 56.5,99 56.5,95.2 23.9,76.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.9,16.1 56.5,34.9 56.5,31.2 23.9,12.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                43.5,1 23.9,12.3 56.5,31.2 76.1,19.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                76.1,87.7 76.1,19.9 56.5,31.2 56.5,99"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.5,34.9 76.1,23.6 76.1,19.8 56.5,31.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.5,99 76.1,87.7 76.1,83.9 56.5,95.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.5,95.2 58.2,94.3 58.2,79.2 56.5,80.2"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M35.9,77.4c-0.1-0.3-0.2-1-0.1-1.4c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.6c2.6,1.7,4.9,1.2,4.9,1.2
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7C43.7,81,43.4,81,43.4,81s-2.6,0.4-5.2-1.1C36.5,78.9,36.1,78,35.9,77.4z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.9,61.3 56.5,80.2 56.5,65.1 23.9,46.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.5,80.2 58.2,79.2 58.2,64.1 56.5,65.1"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M35.9,62.3c-0.1-0.3-0.2-1-0.1-1.4c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.6c2.6,1.7,4.9,1.2,4.9,1.2
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.6,0.4-5.2-1.1C36.5,63.8,36.1,62.9,35.9,62.3z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.9,46.2 56.5,65.1 56.5,50 23.9,31.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.5,65.1 58.2,64.1 58.2,49 56.5,50"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M35.9,47.2c-0.1-0.3-0.2-1-0.1-1.4c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.6c2.6,1.7,4.9,1.2,4.9,1.2
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.6,0.4-5.2-1.1C36.5,48.7,36.1,47.9,35.9,47.2z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                23.9,31.2 56.5,50 56.5,34.9 23.9,16.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.5,50 58.2,49 58.2,34 56.5,34.9"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M35.9,32.2c-0.1-0.3-0.2-1-0.1-1.4c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.6c2.6,1.7,4.9,1.2,4.9,1.2
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.6,0.4-5.2-1.1C36.5,33.6,36.1,32.8,35.9,32.2z"></path>
            </g>
        </symbol>
        <symbol id="wardrobe-large" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,73.6 59.4,95.4 59.4,80.9 21.7,59.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,77.2 59.4,99 59.4,95.4 21.7,73.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,15.5 59.4,37.3 59.4,33.7 21.7,11.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.6,1 21.7,11.9 59.4,33.7 78.3,22.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                78.3,88.1 78.3,22.8 59.4,33.7 59.4,99"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,37.3 78.3,26.4 78.3,22.8 59.4,33.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,99 78.3,88.1 78.3,84.5 59.4,95.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,95.4 61,94.5 61,79.9 59.4,80.9"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M36.4,76.4c-0.1-0.3-0.2-1-0.1-1.3c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.5c2.5,1.6,4.7,1.1,4.7,1.1
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.5,0.4-5-1.1C37,77.8,36.6,77,36.4,76.4z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,59.1 59.4,80.9 59.4,70 21.7,48.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,80.9 61,79.9 61,69.1 59.4,70"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M36.4,63.5c-0.1-0.3-0.2-1-0.1-1.3c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.5c2.5,1.6,4.7,1.1,4.7,1.1
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7C43.9,67,43.6,67,43.6,67s-2.5,0.4-5-1.1C37,64.9,36.6,64.1,36.4,63.5z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,48.2 59.4,70 59.4,59.1 21.7,37.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,70 61,69.1 61,58.2 59.4,59.1"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M36.4,52.6c-0.1-0.3-0.2-1-0.1-1.3c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.5c2.5,1.6,4.7,1.1,4.7,1.1
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.5,0.4-5-1.1C37,54,36.6,53.2,36.4,52.6z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,37.3 59.4,59.1 59.4,48.2 21.7,26.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,59.1 61,58.2 61,47.3 59.4,48.2"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M36.4,41.7c-0.1-0.3-0.2-1-0.1-1.3c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.5c2.5,1.6,4.7,1.1,4.7,1.1
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.5,0.4-5-1.1C37,43.1,36.6,42.3,36.4,41.7z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21.7,26.4 59.4,48.2 59.4,37.3 21.7,15.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                59.4,48.2 61,47.3 61,36.4 59.4,37.3"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M36.4,30.8c-0.1-0.3-0.2-1-0.1-1.3c0.1-0.4,0.3-0.5,0.5-0.5c0.4,0,0.5,0.4,0.5,0.4c0,0-0.1,1.4,1.6,2.5c2.5,1.6,4.7,1.1,4.7,1.1
                c0.3,0,0.6,0.2,0.7,0.5c0.1,0.3,0,0.6-0.2,0.7c-0.2,0.1-0.5,0.1-0.5,0.1s-2.5,0.4-5-1.1C37,32.2,36.6,31.4,36.4,30.8z"></path>
            </g>
        </symbol>
        <symbol id="pc" viewBox="0 0 100 100">
            <g>
                <ellipse transform="matrix(0.2925 -0.9563 0.9563 0.2925 -43.645 122.859)" fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="61.2" cy="90.9" rx="7.2" ry="14.5"></ellipse><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.3,79.2 27.3,32.5 61.2,12.9 61.2,59.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                7,20.8 7,67.5 27.3,79.2 27.3,32.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                9.6,25.2 9.6,28.1 24.7,36.9 24.7,34"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.9,1 7,20.8 27.3,32.5 61.2,12.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                87.9,96.7 87.9,50 93,47.1 93,93.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                34.9,19.4 34.8,66 87.9,96.7 87.9,50"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                37.4,23.7 37.4,64.6 85.4,92.3 85.4,51.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                39.9,16.4 34.9,19.4 87.9,50 93,47.1"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="7" y1="32.5" x2="27.3" y2="44.2"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="7" y1="35.4" x2="27.3" y2="47.1"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="7" y1="38.3" x2="27.3" y2="50"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="7" y1="41.2" x2="27.3" y2="52.8"></line><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M65.5,83.8l-8.7-5v10c0,0,0,0,0,0v0h0c0,0.7,0.7,1.6,1.9,2.3c2,1.2,4.7,1.5,6,0.7c0.4-0.2,0.6-0.6,0.7-0.9l0,0V83.8z"></path>
            </g>
        </symbol>
        <symbol id="pc-desk" viewBox="0 0 100 100">
            <g>
                <g><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                3.5,17.3 31.8,1 96.5,38.3 68.2,54.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                3.5,22 68.2,59.3 68.2,54.7 3.5,17.3"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                96.5,43 68.2,59.3 68.2,54.7 96.5,38.3"></polygon></g><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                70.2,97.8 68.2,99 68.2,59.3 70.2,58.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                66.2,97.8 68.2,99 68.2,59.3 66.2,58.2"></polygon></g><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                96.5,82.7 94.4,83.8 94.4,44.2 96.5,43"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                92.4,82.7 94.4,83.8 94.4,44.2 92.4,45.4"></polygon></g><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                7.6,61.7 5.6,62.8 5.6,23.2 7.6,24.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                3.5,61.7 5.6,62.8 5.6,23.2 3.5,22"></polygon></g><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                33.8,46.3 31.8,47.5 31.8,38.3 33.8,39.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.8,46.3 31.8,47.5 31.8,38.3 29.8,37.2"></polygon></g>
            </g>
        </symbol>
        <symbol id="printer" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M68,81.8c0,0,26.6-15.4,28.8-16.6c2.2-1.3,2.2-3,2.2-3l0-21.7c0,0,0.3,1.6-2.2,3C94.3,44.9,68,52.8,68,52.8
                c-2.5,1.5-5.7,1.5-8.2,0l-2.2-1.3l0,29l2.2,1.2C62.3,83.3,65.4,83.3,68,81.8z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M56.7,14.9l41,23.7c1.7,1,1.7,3.5,0,4.5L68,60.2c-2.6,1.5-5.7,1.5-8.2,0L17.4,35.7c-1.7-1-1.7-3.4,0-4.4l28.5-16.5
                C49.2,12.9,53.4,12.9,56.7,14.9z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M16.1,33.5L16.1,33.5c0,1.8,2.7,3,4.1,3.8l37.4,21.6l0,21.7L16.1,56.7L16.1,33.5z"></path><polyline fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,15.4 19.9,37.1 19.9,58.8"></polyline><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="16.1" y1="42.1" x2="57.6" y2="66.1"></line><polyline fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,80.6 57.6,58.9 95.3,37.1"></polyline><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,66.1 57.6,73.3 19.9,51.6 19.9,44.3"></polygon><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,73.3 57.6,80.6 19.9,58.8 19.9,51.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,75.7 38.7,86.6 1,64.8 1,62.5 19.9,51.6 57.6,73.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,73.3 38.7,84.2 1,62.5 19.9,51.6 26.1,47.9 57.6,66.1"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57.6,69.7 38.7,80.6 7.3,62.5 23,53.4 29.3,49.8 57.6,66.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                38.7,86.6 38.7,84.2 57.6,73.3 57.6,75.7"></polygon><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57.6,66.1l2.2,1.3c2.5,1.5,5.7,1.5,8.2,0c0,0,20.7-12,29.8-17.2c0.8-0.5,1.3-1.3,1.3-2.2"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                19.9,44.3 26.1,47.9 19.9,51.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                1,62.5 38.7,84.2 38.7,86.6 1,64.8"></polygon>
            </g>
        </symbol>
        <symbol id="refrigerator-2door" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.2,78.4 50,91 50,34.3 28.2,21.6"></polygon><path fill="#F8F8F8" d="M28.2,42.9c0,0,2.1,2.8,10.9,7.9c8.2,4.7,10.9,4.7,10.9,4.7l0-0.8L28.2,42.1L28.2,42.9z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.2,78.4 50,91 50,89.4 28.2,76.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.2,42.1 50,54.7 50,53.1 28.2,40.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,9 28.2,21.6 50,34.3 71.8,21.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                71.8,78.4 71.8,21.6 50,34.3 50,91"></polygon><polyline fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                52.7,89.4 52.7,32.7 30.9,20"></polyline><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="53.1" x2="52.7" y2="51.6"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="54.7" x2="52.7" y2="53.1"></line><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.2,78.4 50,91 50,34.3 28.2,21.6"></polygon>
            </g>
        </symbol>
        <symbol id="refrigerator-3door" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,86.4 50,99 50,23.1 28.1,13.7"></polygon><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,86.4 50,99 50,80 28.1,67.4"></polygon><path fill="#F8F8F8" d="M28.1,69.8c0,0,2.1,2.8,11,7.9c8.2,4.7,11,4.7,11,4.7l0-0.8L28.1,69L28.1,69.8z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,86.4 50,99 50,97.4 28.1,84.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,69 50,81.6 50,80 28.1,67.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,67.4 50,80 50,70.6 28.1,57.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,45.3 50,57.9 50,26.3 28.1,13.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                71.9,86.4 71.9,13.6 50,26.3 50,99"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="39" y1="64.2" x2="39" y2="73.7"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="52.7" y1="21.5" x2="52.7" y2="97.4"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="57.9" x2="52.7" y2="56.3"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="70.5" x2="52.7" y2="69"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="80" x2="52.7" y2="78.4"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="81.6" x2="52.7" y2="80"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="72.1" x2="52.7" y2="70.5"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="50" y1="59.5" x2="52.7" y2="57.9"></line><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,86.4 50,99 50,80 28.1,67.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,59.5 50,72.1 50,70.6 28.1,57.9"></polygon><path fill="#F8F8F8" d="M28.1,47.6c0,0,2.1,2.8,11,7.9c8.2,4.7,11,4.7,11,4.7l0-0.8L28.1,46.8L28.1,47.6z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,46.8 50,59.5 50,57.9 28.1,45.3"></polygon><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                28.1,86.4 50,99 50,23.1 28.1,13.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                71.9,13.6 50,1 28.1,13.7 50,26.3"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="30.8" y1="12.1" x2="52.7" y2="24.7"></line>
            </g>
        </symbol>
        <symbol id="washing-machine" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M83.1,20.4v59.2c0,0.3-0.2,0.7-0.5,0.8L51,98.7c-0.6,0.4-1.3,0.4-2,0.2c-2.6-0.8-9.8-3.1-18.6-8.1c-7.7-4.3-11.7-8.1-13.4-10
                c-0.3-0.3-0.4-0.7-0.3-1.1V20.8L83.1,20.4z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M82.6,19.4L51.2,1.3c-0.7-0.4-1.5-0.4-2.2,0L17.4,19.6C16.6,20,16.4,21,17,21.7c1.7,1.9,5.7,5.7,13.4,10c7.6,4.3,14,6.6,17.3,7.7
                c1.5,0.5,3,0.3,4.4-0.5l30.5-17.6C83.3,20.9,83.3,19.8,82.6,19.4z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M23.2,16.2c0,0,3.3,5.1,14.5,11.3s19.6,8.4,19.6,8.4"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M64.9,11.8c-6.5-3.8-17-3.8-23.6,0c-6.5,3.8-6.5,9.8,0,13.6s17,3.8,23.6,0C71.4,21.7,71.4,15.6,64.9,11.8z M63.1,23.4
                c-5.2,3-13.6,3-18.9,0c-5.2-3-5.2-7.9,0-10.9c5.2-3,13.6-3,18.9,0C68.3,15.5,68.3,20.4,63.1,23.4z"></path><ellipse fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="43.9" cy="34.1" rx="1.8" ry="1"></ellipse><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="41.6" y1="5.6" x2="75.6" y2="25.2"></line><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                31.7,28.7 35.4,30.8 37.3,29.8 33.6,27.6"></polygon><path fill="#F8F8F8" d="M50.1,98.3l0-58.2l33.2-19.2l-0.2,58.7c0,0.4-0.2,0.8-0.6,1L50.8,98.7C50.5,98.9,50.1,98.7,50.1,98.3z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M82.6,19.4L51.2,1.3c-0.7-0.4-1.5-0.4-2.2,0L17.4,19.6C16.6,20,16.4,21,17,21.7c1.7,1.9,5.7,5.7,13.4,10c7.6,4.3,14,6.6,17.3,7.7
                c1.5,0.5,3,0.3,4.4-0.5l30.5-17.6C83.3,20.9,83.3,19.8,82.6,19.4z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M83.1,20.4v59.2c0,0.3-0.2,0.7-0.5,0.8L52.1,98c-1.3,0.8-2.9,0.9-4.4,0.5c-3.3-1.1-9.7-3.4-17.3-7.7c-7.7-4.3-11.7-8.1-13.4-10
                c-0.3-0.3-0.4-0.7-0.3-1.1V20.8"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M16.7,26.2c-0.1,0.4,0,0.8,0.3,1.1c1.7,1.9,5.7,5.7,13.4,10c7.6,4.3,14,6.6,17.3,7.7c1.5,0.5,3,0.3,4.4-0.5l30.5-17.6
                c0.3-0.2,0.5-0.5,0.5-0.8"></path><g><path fill="none" d="M44.3,23.4c2.9,1.7,6.9,2.4,10.7,2.2l-14.5-8.4C40.1,19.4,41.4,21.7,44.3,23.4z"></path><path fill="none" d="M63.1,12.5c-5.2-3-13.6-3-18.9,0c-1.6,0.9-2.7,2.1-3.3,3.2l0.6-0.4l16.9,9.7c1.7-0.4,3.3-0.9,4.7-1.7
                C68.3,20.4,68.3,15.5,63.1,12.5z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M41.2,15.2c-0.3,0.5-0.7,1.5-0.8,2l14.5,8.4c1.2-0.1,2.4-0.2,3.5-0.4l-16.9-9.7L41.2,15.2z"></path></g>
            </g>
        </symbol>
        <symbol id="washing-machine-drum" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                48.1,1 25.5,14.1 59.4,33.7 82.1,20.6"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M51.9,99c0,0,0-0.3,0-17.4c0-17.5,2.8-31.1,4-36c2.3-9,3.5-11.9,3.5-11.9l-34-19.6c0,0-0.1,0.3-0.4,1.1c-0.5,1.5-1.6,4.8-3.1,10.8
                c-1.2,4.9-4,18.5-4,36c0,17,0,17.4,0,17.4L51.9,99z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M51.9,99c0,0,0-0.3,0-17.4c0-17.5,2.8-31.1,4-36c2.3-9,3.5-11.9,3.5-11.9l22.6-13.1v61.1L51.9,99z"></path><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="23.1" y1="21.4" x2="57.1" y2="41.1"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="17.9" y1="67.5" x2="51.9" y2="87.1"></line><ellipse transform="matrix(0.9545 -0.2983 0.2983 0.9545 -14.405 13.1747)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="36" cy="53.8" rx="14" ry="21.3"></ellipse><ellipse transform="matrix(0.9545 -0.2983 0.2983 0.9545 -14.405 13.1747)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="36" cy="53.8" rx="11.2" ry="17"></ellipse><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                36,22.4 34.6,25.9 45.9,32.4 47.3,28.9"></polygon>
            </g>
        </symbol>
        <symbol id="dining-table" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                9.6,29 9.6,24.3 50,47.8 50,52.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                9.6,24.3 50,1 90.4,24.4 50,47.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                90.4,29.1 50,52.4 50,47.8 90.4,24.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,99 50,52.4 54,50.1 54,96.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                46,96.7 46,50.1 50,52.4 50,99"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                86.4,78 86.4,31.4 90.4,29.1 90.4,75.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.3,75.7 82.3,33.8 86.4,31.4 86.4,78"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                13.6,77.9 13.6,31.3 17.7,33.7 17.7,75.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                9.6,75.6 9.6,29 13.6,31.3 13.6,77.9"></polygon>
            </g>
        </symbol>
        <symbol id="chair" viewBox="0 0 100 100">
            <g>
                <polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,99 50,63.3 52.6,61.8 52.6,97.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                47.4,97.4 47.4,61.8 50,63.3 50,99"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,33.8 50,4 52.6,5.5 52.6,35.2"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                47.4,35.6 47.4,2.5 50,4 50,33.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.9,85.5 26.9,49.9 29.5,51.4 29.5,84"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                24.3,84 24.3,48.4 26.9,49.9 26.9,85.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                73.1,85.5 73.1,17.3 70.5,15.8 70.5,84"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                75.7,84 75.6,15.8 73.1,17.3 73.1,85.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                26.9,55.8 26.9,49.9 47.4,61.8 47.4,67.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                47.4,2.5 49.9,1 75.6,15.8 73.1,17.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50,9.9 50,4 70.5,15.8 70.5,21.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                73.1,55.7 52.6,67.7 52.6,61.8 73.1,49.9"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M73.1,49.9c0,0-0.1-3-2.6-4.4c-2.5-1.4-19.8-11.3-19.8-11.3c-2.1-1.2-4.6-1.2-6.7,0L26.9,44c0,0-2.6,1.1-2.6,4.4L50,63.3
                L73.1,49.9z"></path>
            </g>
        </symbol>
        <symbol id="mirror" viewBox="0 0 100 100">
            <g>
                <polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                60.7,64.3 68.9,90.1 57.5,83.3 57.8,81.7 66.1,86.6 60.2,67.7"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                43.5,2.4 65.8,15.2 51.9,99 29.6,86.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                46.1,8.1 61.8,17.2 49.1,92.7 33.5,83.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                51.9,99 65.8,15.2 69.1,13.8 55.1,97.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                69.1,13.8 46.8,1 43.5,2.4 65.8,15.2"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                70.4,88.9 61.4,60.2 60.7,64.3 68.9,90.1"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                65.7,85.1 58,80.5 57.8,81.7 66.1,86.6"></polygon>
            </g>
        </symbol>
        <symbol id="cupboard" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29.3,83.1 56.9,99 56.9,95.8 29.3,79.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,80.7 55.5,96.6 55.5,74.3 27.9,58.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,13.7 55.5,29.7 55.5,26.5 27.9,10.6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                44.5,1 27.9,10.6 55.5,26.5 72.1,16.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                72.1,90.2 72.1,20.1 56.9,28.9 56.9,99"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                55.5,29.7 72.1,20.1 72.1,16.9 55.5,26.5"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                55.5,96.6 56.9,95.8 56.9,73.5 55.5,74.3"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,58.4 55.5,74.3 55.5,64.7 27.9,48.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                55.5,74.3 56.9,73.5 56.9,60.8 55.5,61.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                27.9,48.8 55.5,64.7 55.5,29.7 27.9,13.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                55.5,64.7 56.9,63.9 56.9,28.9 55.5,29.7"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="41.7" y1="66.3" x2="41.7" y2="88.6"></line><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                30.7,50.4 30.7,15.3 27.9,13.7 27.9,48.8"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                39,55.2 39,20.1 44.5,23.3 44.5,58.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                52.8,63.1 52.8,28.1 55.5,29.7 55.5,64.7"></polygon><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="41.7" y1="21.7" x2="41.7" y2="56.8"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="40.3" y1="35.3" x2="40.3" y2="40"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="43.1" y1="36.9" x2="43.1" y2="41.6"></line><line fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="40.3" y1="59.2" x2="43.1" y2="60.8"></line>
            </g>
        </symbol>
        <symbol id="microwave-oven" viewBox="0 0 100 100">
            <g>
                <polyline fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                15.1,27.1 15.1,64.9 57,89 57,51.3 15.1,27.1"></polyline><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                57,89 84.9,72.9 84.9,35.1 57,51.3"></polygon><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M43,11l41.9,24.1L57,51.3c0,0-10.5-3-22.9-10.5s-19-13.6-19-13.6L43,11z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                15.1,29.8 57,54 57,78.2 15.1,54"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                15.1,54 57,78.2 57,86.3 15.1,62.2"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57,51.3c0,0-8.4-3.3-21-10.7c-16.8-9.9-21-13.5-21-13.5v2.7c0,0,4.1,3.7,21,13.5C48.6,50.7,57,54,57,54V51.3z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                29,64.8 29,67.5 38.4,72.8 38.4,70.2"></polygon><ellipse transform="matrix(0.5254 -0.8508 0.8508 0.5254 -42.5338 70.4877)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="41.9" cy="73.4" rx="1.4" ry="2.3"></ellipse>
            </g>
        </symbol>
        <symbol id="aircon" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M27,6.9l70.1,40.5c1.1,0.7,1.8,1.9,1.8,3.2l0,8.7l-10.3,33l-2.2,1.3c-0.9,0.5-2,0.5-3,0L10.3,51.2L5,48.2c-2.5-1.4-4-4.1-4-7V20.9
                c0-1.3,0.7-2.6,1.9-3.3L21.6,6.9C23.3,5.9,25.4,5.9,27,6.9z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M15.6,54.3l-5.3-3.1c-2.5-1.4-4-4.1-4-7"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M81,92l-5.3-3.1c-2.5-1.4-4-4.1-4-7"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M97.1,49.5L77.5,60.7c-1.2,0.7-1.9,1.9-1.9,3.3l0,20.2c0,2.9,1.5,5.6,4,7l3.7,2.2c1,0.6,2.1,0.6,3.1,0l10.6-6.1
                c1.2-0.7,1.9-1.9,1.9-3.2l0-33.5C99,49.6,97.9,49,97.1,49.5z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M76.2,62.1c-0.3,0.6-0.5,1.2-0.5,1.9v21.3L1,41.2V20.9c0-0.7,0.2-1.3,0.5-1.9L76.2,62.1z"></path><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                40.7,28.2 17.3,14.7 24.3,10.7 47.7,24.2"></polygon><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="19.7" y1="13.4" x2="43" y2="26.9"></line><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="22" y1="12" x2="45.3" y2="25.5"></line></g><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                82.7,52.4 54.7,36.2 61.7,32.2 89.7,48.4"></polygon><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="57.1" y1="34.9" x2="85.1" y2="51.1"></line><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="59.4" y1="33.5" x2="87.4" y2="49.7"></line></g>
            </g>
        </symbol>
        <symbol id="heater" viewBox="0 0 100 100">
            <g>
                <path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M50.6,93.9c0-1.4-1-2-2.3-1.3c-1.2,0.7-2.3,2.5-2.3,3.9c0,0.9,0.3,1.2,0.9,1.6l1.6,0.9C49.9,98.3,50.6,95.4,50.6,93.9z"></path><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -58.1755 91.4157)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="50.1" cy="96.1" rx="3.2" ry="1.8"></ellipse><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M74,80.7c0-1.4-1-2-2.3-1.3c-1.2,0.7-2.3,2.5-2.3,3.9c0,0.9,0.3,1.2,0.9,1.6l1.6,0.9C73.3,85.1,74,82.2,74,80.7z"></path><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -35.0469 105.0983)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="73.5" cy="82.9" rx="3.2" ry="1.8"></ellipse><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M48.9,94.3l-2.1-1.2c-0.2-0.1-0.3-0.3-0.3-0.6c0-0.2,0-2.5,0-2.5l25.1-12.8l3.9,0c0,0,0,2.4,0,2.5c0,0.2-0.1,0.3-0.2,0.4
                L50.7,94.3C50.2,94.6,49.5,94.6,48.9,94.3z"></path><path fill="#F8F8F8" d="M49.8,92.3l0.6-0.9L73,78.9l2.5-1.5c0,0,0,2.1,0,2.3c0,0.2-0.1,0.3-0.2,0.4L50.7,94.3
                c-0.3,0.2-0.6,0.2-0.9,0.2L49.8,92.3z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M48.7,91.6l-1.6-0.9c-0.7-0.4-0.7-1.5,0-1.9l24.3-14.1c0.1-0.1,0.3-0.1,0.4,0l3.5,2c0.3,0.2,0.3,0.6,0,0.8L51,91.6
                C50.3,92,49.4,92,48.7,91.6z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M46.6,90c0,0,0,2.3,0,2.5c0,0.2,0.1,0.4,0.3,0.6l2.1,1.2c0.6,0.3,1.2,0.3,1.8,0l24.6-13.9c0.2-0.1,0.3-0.3,0.3-0.5v-2.7l-4,2.5"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M28.8,81.3c0-1.4-1-2-2.3-1.3c-1.2,0.7-2.3,2.5-2.3,3.9c0,0.9,0.3,1.2,0.9,1.6l1.6,0.9C28.1,85.7,28.8,82.8,28.8,81.3z"></path><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -58.2118 66.2063)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="28.2" cy="83.5" rx="3.2" ry="1.8"></ellipse><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M27.1,81.7l-2.5-1.4c-0.2-0.1-0.3-0.3-0.3-0.6c0-0.2,0-2.5,0-2.5l25.6-12.6l4.4,2.5L28.9,81.7C28.3,82,27.6,82,27.1,81.7z"></path><path fill="#F8F8F8" d="M27.9,79.7l0.6-0.9l21.3-14.2l4.4,2.5L28.9,81.7c-0.3,0.2-0.6,0.2-0.9,0.2L27.9,79.7z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M27.1,79.2l-2.5-1.4c-0.4-0.2-0.4-0.9,0-1.1l25.2-14.6l4.4,2.5L28.9,79.2C28.3,79.5,27.6,79.5,27.1,79.2z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M54.2,67.1L28.9,81.7c-0.6,0.3-1.2,0.3-1.8,0l-2.5-1.4c-0.2-0.1-0.3-0.3-0.3-0.6c0-0.2,0-2.5,0-2.5"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M37.3,1.1l-5.9,3.4c-0.8,0.4-1.2,1.3-1.2,2.1v62.2c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V2.1
                C38.9,1.2,38,0.7,37.3,1.1z"></path><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M43,4.5l-5.9,3.4c-0.8,0.4-1.2,1.3-1.2,2.1v62.2c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V5.4
                C44.6,4.6,43.7,4.1,43,4.5z"></path></g><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M48.7,7.8l-5.9,3.4c-0.8,0.4-1.2,1.3-1.2,2.1v62.2c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V8.7
                C50.3,7.9,49.4,7.4,48.7,7.8z"></path></g><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M54.4,11.1l-5.9,3.4c-0.8,0.4-1.2,1.3-1.2,2.1v62.2c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V12
                C56,11.2,55.1,10.7,54.4,11.1z"></path></g><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M60,14.4l-5.9,3.4c-0.8,0.4-1.2,1.3-1.2,2.1v62.2c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V15.4
                C61.7,14.5,60.8,14,60,14.4z"></path></g><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M64.9,18.4L59,21.8c-0.8,0.4-1.2,1.3-1.2,2.1v62.2c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V19.3
                C66.5,18.5,65.6,18,64.9,18.4z"></path></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M69.2,21.2l-5.9,3.4C62.5,25,62,25.9,62,26.7V89c0,0.8,0.9,1.4,1.6,0.9l5.9-3.4c0.8-0.4,1.2-1.3,1.2-2.1V22.1
                C70.8,21.3,69.9,20.8,69.2,21.2z"></path>
            </g>
        </symbol>
        <symbol id="vacuum" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M26.4,81.2L8.7,69.8c0,0,0,0,0,0c-0.5-0.3-0.9-0.5-1.5-0.3l-4.3,1.4c-0.8,0.4-1.3,0.7-1.6,1.4L1.1,73c-0.1,0.4-0.1,0.6,0,0.7l0,0
			l18.7,12.5l8-1.4v-1.1C27.8,82.7,27.3,81.7,26.4,81.2z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M27.8,85.2c0,0.4-0.3,0.7-0.7,0.7l-6.8,0.4c-0.3,0-1-0.1-0.7-0.9l0.2-0.5c0.2-0.7,0.8-1.2,1.6-1.4l4.1-0.9
			c1.2-0.3,2.3,0.6,2.3,1.8V85.2z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M77.3,36.6c0,0,7.8,3.9,2.8,16.2l3.5,1.1c0,0,1.3-2.1,1.7-5.1C86,43.2,84.9,34.6,76,32L77.3,36.6z"></path><path fill="#F8F8F8" d="M72.3,81.7l-0.2,1.2c-0.5,2.9,2.3,4.7,5,3.2l16.4-8.6c2.3-1.2,4-3.4,4.4-5.8l0.6-3.5
			c1.1-6-4.7-9.8-10.4-6.8L87,62C79.3,66.1,73.7,73.6,72.3,81.7z"></path><path fill="#FFFFFF" d="M92.8,58.6c0,0-5.9-3.7-7.9-4.7c-2.8-1.2-6.2-1.9-10.3,0.3l0,0c-7.8,4.6-13.3,12.2-13.3,21.2v1.3
			c0,1.6,1.2,3.2,3,4.4c0.4,0.2,4.2,2.4,7.3,4.1c2.1,1.1,3.8,1.6,6.5,0.4l17.1-8c2.3-1.3,3.8-3.8,3.8-6.5l0-3.9
			C99,63.4,96.9,60.9,92.8,58.6z"></path><path fill="#F8F8F8" d="M72.3,81.7l-0.2,1.2c-0.5,2.9,2.3,4.7,5,3.2l16.4-8.6c2.3-1.2,4-3.4,4.4-5.8l0.6-3.5
			c1.1-6-4.7-9.8-10.4-6.8L87,62C79.3,66.1,73.7,73.6,72.3,81.7z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M92.8,58.6c0,0-5.9-3.7-7.9-4.7c-2.8-1.2-6.2-1.9-10.3,0.3l0,0c-7.8,4.6-13.3,12.2-13.3,21.2v1.3c0,1.6,1.2,3.2,3,4.4
			c0.4,0.2,4.2,2.4,7.3,4.1c2.1,1.1,3.8,1.6,6.5,0.4l17.1-8c2.3-1.3,3.8-3.8,3.8-6.5l0-3.9C99,63.4,96.9,60.9,92.8,58.6z"></path><g><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -18.0493 117.6309)" fill="#F8F8F8" cx="92.8" cy="74.4" rx="8.7" ry="5"></ellipse><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -18.0493 117.6309)" fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="92.8" cy="74.4" rx="8.7" ry="5"></ellipse></g><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M62.1,69.6c0,0,0.8,2.1,4.5,4.1c3.2,1.7,7,2.5,8.1,0.7c2.7-4.4,4.3-7.4,11.1-11.8c2.1-1.4,5-2.3,5-2.3C90.5,59.2,80,52.8,78,53"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M85.8,62.6c-0.9-1.4-10.7-7.5-12.6-7.4"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M64.9,36.4L76,32c0,0,1.1,0.5,1.7,1.9c0.8,1.8-0.5,2.7-0.5,2.7L65.9,41l0.1-2.3L64.9,36.4z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M87.1,16.9c-0.7-0.6-3.3-2.1-3.3-2.1c-3-1.8-6.2-2.1-8.7-0.1C72.4,16.8,65,23.9,65,23.9c-0.1,0.1-0.2,0.2-0.2,0.4
			c0,0-0.9,3.8-1.5,6.4c-0.5,1.9-1.4,3.2-2.6,4.2L15.4,73.5l3.6,3.1l48.2-41.1l14.9-6.5c2-0.8,3.6-2.2,4.6-4.1l1.5-2.8
			C89.1,20.2,88.9,18.5,87.1,16.9z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M69.9,29.6c0,0,0.7-3.5,1.8-5c1.4-2,6.7-7.6,8.8-7.1c2,0.5,4.4,2,3.9,3.2c-0.3,0.6-1.2,3.4-2.9,4.3C77.1,27.6,69.9,29.6,69.9,29.6
			z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M65.9,41c0,0-5.2,3.5-8,4.7c-2.8,1.1-7.1,3.8-7.1,3.8"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M65,23.9c0,0,0.3,1.3,2.6,1.3c0.9,0,8.8-7.5,9.5-8.7s-1-2.5-2-1.9L65,23.9z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M69.1,82.1c0.4-0.3,0.7-0.8,0.7-1.5c0-1.5-1.1-3.4-2.4-4.2c-0.7-0.4-1.3-0.4-1.7-0.1l0,0L60.8,79l3.3,5.9L69.1,82.1
			C69.1,82.1,69.1,82.1,69.1,82.1L69.1,82.1L69.1,82.1z"></path><g><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -32.5961 42.2383)" fill="#F8F8F8" cx="62.5" cy="81.9" rx="2" ry="3.4"></ellipse><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -32.5961 42.2383)" fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="62.5" cy="81.9" rx="2" ry="3.4"></ellipse></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M63.5,83.4c0-1.1-0.8-2.5-1.7-3c-0.4-0.2-0.7-0.2-0.9-0.2l0,0c0,0-9.3,1.8-11.8,0c0,0,5.4-3,12.3-5.9c0,0,0-0.7,0.2-2.1
			c0.2-1.4,0.7-3.2,0.7-3.2s-15,6.9-17.3,8.6c-4,2.9-1.9,7.1,4.9,7.7c6,0.6,13-0.7,13-0.7l0,0C63.3,84.3,63.5,83.9,63.5,83.4z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
			M27.7,70.2c0.4-0.3,0.5-0.9,0.4-1.6c-0.3-1.5-1.7-3.2-3.1-3.7c-0.7-0.3-1.3-0.2-1.7,0.2l0,0l-8.9,7.6c0,0-2.6,2.2-0.7,4.5
			c1.2,1.4,3.7,1.6,5,0.7L27.7,70.2C27.6,70.3,27.6,70.3,27.7,70.2L27.7,70.2L27.7,70.2z"></path>
            </g>
        </symbol>
        <symbol id="fan" viewBox="0 0 100 100">
            <g>
                <path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M74.2,86.9c-0.7-1.9-2.2-3.6-4.7-5.1c-6.8-3.9-17.9-3.9-24.7,0c-2.5,1.4-4.1,3.2-4.7,5.1h-0.4v2.3l0,0c0.1,2.5,1.8,5,5.1,6.9
                c6.8,3.9,17.9,3.9,24.7,0c3.3-1.9,5-4.4,5.1-6.9l0,0v-2.3H74.2z"></path><ellipse fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="57.1" cy="86.5" rx="17.4" ry="10.1"></ellipse>
                <path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M54.4,59.7v26l0,0c0,0.4,0.3,0.8,0.8,1.1c1.1,0.6,2.8,0.6,3.9,0c0.5-0.3,0.8-0.7,0.8-1.1l0,0v-26H54.4z"></path><ellipse fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="57.1" cy="59.7" rx="2.7" ry="1.6"></ellipse><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M55.2,25.2v34.2l0,0c0,0.3,0.2,0.6,0.6,0.8c0.8,0.4,2,0.4,2.7,0c0.4-0.2,0.6-0.5,0.6-0.8l0,0V25.2H55.2z"></path><g><g><path fill="#F8F8F8" d="M63.2,20.5c0-3.4-2.4-7.5-5.3-9.2c-1.5-0.8-2.8-0.9-3.8-0.4l-4.6,2.5c0,0.6-1.1,3.6-1.1,4.4
                c0.3,3.6,0.8,11.1,3.2,12.5l9.9-6.3C62.6,23.4,63.2,22.2,63.2,20.5z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M63.2,20.5c0-3.4-2.4-7.5-5.3-9.2c-1.5-0.8-2.8-0.9-3.8-0.4l-4.6,2.5c0,0.6-1.1,3.6-1.1,4.4c0.3,3.6,0.8,11.1,3.2,12.5l9.9-6.3
                C62.6,23.4,63.2,22.2,63.2,20.5z"></path></g><g><path fill="#F8F8F8" d="M51.7,24.9c0-2.6-1.8-5.7-4.1-7c-1.1-0.6-2.1-0.7-2.9-0.3l-3.5,1.8c0,0.5,2.4,1.9,2.4,2.6
                c0.2,2.8,1,6.6,2.8,7.7l4-2C51.2,27.1,51.7,26.2,51.7,24.9z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M51.7,24.9c0-2.6-1.8-5.7-4.1-7c-1.1-0.6-2.1-0.7-2.9-0.3l-3.5,1.8c0,0.5,2.4,1.9,2.4,2.6c0.2,2.8,1,6.6,2.8,7.7l4-2
                C51.2,27.1,51.7,26.2,51.7,24.9z"></path></g><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -6.28 24.9405)" fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="43.4" cy="24.2" rx="14.7" ry="25.4"></ellipse><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M43.5,24.3c2.6,4.7,3.8,9.8,3.3,13.8l-0.2,2.3c-0.1,0.8,0,1.7,0.7,2.5c0.6,0.8,1.1,0.9,1.6,1l0,0c3.2,0.4,6-0.6,7.8-3.2
                c0.6-0.9,1.1-2,1.5-3.1c0.3-1,1.5-4.8-1.6-8.2c-2.2-2.4-7.5-3.7-7.5-3.7l0.3,0.1L43.5,24.3"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M43.5,24.3c-3.7-1.1-7.6-4.4-10.6-8.8l-1.7-2.3c-0.6-0.8-1.3-1.6-2-1.5c-0.6,0.1-0.8,0.6-0.9,1.1l0,0c-0.5,3.6,0,8,1.9,12.7
                c0.6,1.6,1.4,3.2,2.2,4.7c0.7,1.3,3.5,6.4,6.2,5.6c1.9-0.5,3.3-5.9,3.3-5.9l-0.1,0.3L43.5,24.3"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M43.5,24.3c1.1-3.6,3.8-5.4,7.3-5.1l1.9,0.1c0.6,0,1.2-0.1,1.2-1.1c0-0.8-0.4-1.5-0.7-2.1l0,0c-2.6-4-6-7.4-9.7-9.6
                C42.2,5.9,41,5.4,39.8,5c-1-0.3-5-1.6-4.7,2.5c0.3,2.9,4.2,9.6,4.2,9.6l-0.2-0.3L43.5,24.3"></path><g><path fill="#F8F8F8" d="M47.6,26.6c0-2.6-1.8-5.7-4.1-7c-1.1-0.6-2.1-0.7-2.9-0.3l-3.5,1.8c0,0.5,2.4,1.9,2.4,2.6
                c0.2,2.8,1,6.6,2.8,7.7l4-2C47.1,28.9,47.6,28,47.6,26.6z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M47.6,26.6c0-2.6-1.8-5.7-4.1-7c-1.1-0.6-2.1-0.7-2.9-0.3l-3.5,1.8c0,0.5,2.4,1.9,2.4,2.6c0.2,2.8,1,6.6,2.8,7.7l4-2
                C47.1,28.9,47.6,28,47.6,26.6z"></path></g></g><g><g></g></g><g><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -7.7832 23.3769)" fill="#FFFFFF" cx="39.7" cy="26.2" rx="3.3" ry="5.7"></ellipse><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -7.7832 23.3769)" fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="39.7" cy="26.2" rx="3.3" ry="5.7"></ellipse></g><g><g></g></g>
            </g>
        </symbol>
        <symbol id="bicycle" viewBox="0 0 100 100">
            <g>
                <polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                52.2,42 46.1,38.5 42.2,40.9 42.2,42.4 48.2,45.9 52.2,43.4"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M49.3,44.8l-2.6,11.8c0,0-0.3,1.3,0.9,1.6c1.1,0.2,1.4-0.9,1.4-0.9l2.6-12.2c0,0,0.5-1.8-0.9-1.8C49.6,43.3,49.3,44.8,49.3,44.8z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M19.1,73.3l7.4-23.8c0.3-0.9,1.3-2.7,2.1-3.1c0,0,1.7-1.2,3-1.4c0.3-0.1,1.1,0.1,0.6,1.3c-0.5,1.5-1.5,1.7-1.5,1.7l-0.1,0
                c-0.5,0.2-0.8,0.6-1,1.1l-8.7,25.3c0,0-0.9,0.9-1.4,0.5C18.9,74.5,19.1,73.3,19.1,73.3z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                75.5,45.8 76.9,42.1 78.8,43.2 77.1,46.2"></polygon><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="49.5" y1="61.9" x2="54" y2="59.7"></line><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M74,37c-0.1,0-0.1,0.1-0.2,0.1L51,48.6c-0.3,0.1-0.6,0.2-0.9,0.4c-3.1,1.8-5.6,6.1-5.6,9.6s2.5,5,5.6,3.2L74,45.6
                c2.1-1.2,3.7-4.1,3.7-6.4C77.7,36.8,76.1,35.8,74,37z"></path><g><path fill="#FFFFFF" d="M22.3,95.3c16.3-6.6,18.3-27,17.6-32.6c-1-11.3-10.9-11.1-8-10.1c3.7,1.4,6,5.3,6,11.3
                c0,10.6-7.4,23.4-16.6,28.7c-5.7,3.3-10.8,2.9-13.7-0.5C5.9,90.1,9.8,100.4,22.3,95.3z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M22.3,95.3c16.3-6.6,18.3-27,17.6-32.6c-1-11.3-10.9-11.1-8-10.1c3.7,1.4,6,5.3,6,11.3c0,10.6-7.4,23.4-16.6,28.7
                c-5.7,3.3-10.8,2.9-13.7-0.5C5.9,90.1,9.8,100.4,22.3,95.3z"></path></g><g><g><path fill="#F8F8F8" d="M37,51.8c-3.7-2.9-9.1-3.2-15.2,0.3C11.4,58,2.9,72.7,2.9,84.7c0,5.7,1.8,9.7,4.8,12
                c3.7,2.9,9.1,3.3,15.2-0.3c10.4-6,18.8-20.6,18.8-32.6C41.7,58.1,39.9,54.1,37,51.8z M22.9,93.8c-9.1,5.3-16.6,1-16.6-9.6
                c0-10.6,7.4-23.4,16.6-28.7c9.1-5.3,16.6-1,16.6,9.6C39.4,75.7,32,88.5,22.9,93.8z"></path></g><g><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M37,51.8c-3.7-2.9-9.1-3.2-15.2,0.3C11.4,58,2.9,72.7,2.9,84.7c0,5.7,1.8,9.7,4.8,12c3.7,2.9,9.1,3.3,15.2-0.3
                c10.4-6,18.8-20.6,18.8-32.6C41.7,58.1,39.9,54.1,37,51.8z M22.9,93.8c-9.1,5.3-16.6,1-16.6-9.6c0-10.6,7.4-23.4,16.6-28.7
                c9.1-5.3,16.6-1,16.6,9.6C39.4,75.7,32,88.5,22.9,93.8z"></path></g></g><g><path fill="#FFFFFF" d="M77.7,63.5C94,56.9,96,36.5,95.3,31c-1-11.3-10.9-11.1-8-10.1c3.7,1.4,6,5.3,6,11.3
                c0,10.6-7.4,23.4-16.6,28.7C71,64.1,66,63.7,63,60.3C61.2,58.3,65.1,68.6,77.7,63.5z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M77.7,63.5C94,56.9,96,36.5,95.3,31c-1-11.3-10.9-11.1-8-10.1c3.7,1.4,6,5.3,6,11.3c0,10.6-7.4,23.4-16.6,28.7
                C71,64.1,66,63.7,63,60.3C61.2,58.3,65.1,68.6,77.7,63.5z"></path></g><g><g><path fill="#F8F8F8" d="M92.3,19.9c-3.7-2.9-9.1-3.2-15.2,0.3c-10.4,6-18.8,20.6-18.8,32.6c0,5.7,1.8,9.7,4.8,12
                c3.7,2.9,9.1,3.3,15.2-0.3C88.6,58.6,97.1,44,97.1,32C97.1,26.3,95.2,22.3,92.3,19.9z M78.2,62c-9.1,5.3-16.6,1-16.6-9.6
                c0-10.6,7.4-23.4,16.6-28.7c9.1-5.3,16.6-1,16.6,9.6C94.8,43.8,87.4,56.7,78.2,62z"></path></g><g><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M92.3,19.9c-3.7-2.9-9.1-3.2-15.2,0.3c-10.4,6-18.8,20.6-18.8,32.6c0,5.7,1.8,9.7,4.8,12c3.7,2.9,9.1,3.3,15.2-0.3
                C88.6,58.6,97.1,44,97.1,32C97.1,26.3,95.2,22.3,92.3,19.9z M78.2,62c-9.1,5.3-16.6,1-16.6-9.6c0-10.6,7.4-23.4,16.6-28.7
                c9.1-5.3,16.6-1,16.6,9.6C94.8,43.8,87.4,56.7,78.2,62z"></path></g></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M26.5,74.7L21.8,72c0,0,0,0,0,0l0,0l0,0c-0.2-0.1-0.5-0.1-0.8,0.1c-0.7,0.4-1.3,1.4-1.3,2.2c0,0.4,0.1,0.6,0.3,0.8l0,0l0,0
                c0,0,0,0,0,0l4.7,2.7L26.5,74.7z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M80.9,42.7l-4.8-2.7c0,0,0,0,0,0l0,0l0,0c-0.2-0.1-0.5-0.1-0.8,0.1c-0.7,0.4-1.3,1.4-1.3,2.2c0,0.4,0.1,0.6,0.3,0.8l0,0l0,0
                c0,0,0,0,0,0l4.7,2.7L80.9,42.7z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M62.2,48c5.4-3.6,12.2-7.4,12.2-7.4l-0.5,2c0,0-6.8,4.5-12.1,8l0.3-2.1c5.4-3.5,12.4-7.9,12.4-7.9"></path><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                53.6,54.4 53.6,54.4 53.7,54.1"></polygon><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M80.9,42.7L80.9,42.7L63.9,31.8L61,30l-0.6,2.1l18.1,11.7L59.1,54.5c-2.5,1.3-3.5,1-3.6,0.6c-0.2-0.8,1-1.4,2.8-2.6l0.1-2.4
                c0,0-1.2,0.7-2.2,1.5c-0.8,0.5-1.5,1-2.4,2.1l-1,2.8l2.5,0.9l0.8,0.1c0.9-0.1,2-0.1,2.9-0.7l21-11.8c0,0,1.4-0.7,1.4-1.5
                C81.6,43.1,81.3,42.8,80.9,42.7z"></path></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M55.2,56.9L50.1,54c0,0,0,0,0,0l0,0l0,0c-0.2-0.1-0.5-0.1-0.8,0.1c-0.7,0.4-1.3,1.4-1.3,2.2c0,0.4,0.1,0.6,0.3,0.8l0,0l0,0
                c0,0,0,0,0,0l5,2.9L55.2,56.9z"></path><g><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -23.4603 76.273)" fill="#F8F8F8" cx="54.3" cy="58.5" rx="1.8" ry="1"></ellipse><ellipse transform="matrix(0.5 -0.866 0.866 0.5 -23.4603 76.273)" fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="54.3" cy="58.5" rx="1.8" ry="1"></ellipse></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M49.7,57.3c-3.7-0.6-7-2.6-9.3-5.5l-8-10.1l0.7-2.7l8,10.1c2.3,2.9,5.3,5.3,8.9,6.1c0,0,1,0,0.7,1.3
                C50.5,57.2,49.7,57.3,49.7,57.3z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M50.5,55.1l8.9-28.8c0,0,0.9-0.1,1.2,0c1.3,0.2,1.3,0.9,1.3,0.9l-8.7,28.3c0,0-0.3,0.7-1.3,0.7C50.7,56.2,50.5,55.1,50.5,55.1z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M59.6,26.6l3.3-11.1h2.3L61.8,27c0,0-0.3,0.5-1.1,0.5C59.7,27.5,59.6,26.6,59.6,26.6z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70.5,9.8c0,0-0.1,0-0.2-0.1c0,0-0.1-0.1-0.1-0.1c-3.1-1.8-6-0.8-8.8,0.8c-3.3,1.9-5.6,1.7-8,4.3c0,0,0,3.7,0.9,4.2
                c2.3,1.6,5.1-0.9,7.5-1.7c4.5-1.4,6.2,0.4,9.4-1.5c1.2-0.7,1.8-1.5,1.8-2.4c0-0.5,0.1-2.6,0-3.8C73,8.7,71.6,10.5,70.5,9.8z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70.5,6.5c0,0-0.1,0-0.2-0.1c0,0-0.1-0.1-0.1-0.1c-3.1-1.8-7.6-2.1-10.4-0.4c-3.3,1.9-0.2,2.8-2.6,5.5c-1.3,1.4-5.5,2.8-2.9,4.3
                c2.4,1.4,5.1-0.9,7.5-1.7c4.5-1.4,6.2,0.4,9.4-1.5C74.1,10.9,73.6,8.3,70.5,6.5z"></path><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M27,76.9c0.1-0.3,7.9-23.6,7.9-23.6c0.3-0.9,0.6-2.9,0.2-3.7c0,0-0.6-2.8-1.5-3.7c-0.2-0.3-1-0.1-1.4,0.8
                c-0.7,1.5-0.1,2.1-0.1,2.1l0.5,0.9c0.2,0.5,0.3,1,0.2,1.5c0,0-7.7,24.3-7.9,25c-0.2,0.7-0.4,1.7,0.5,1.9
                C26.3,78.4,26.8,77.3,27,76.9z"></path><g><g><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="25.4" y1="78.2" x2="22.3" y2="93.2"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="27" y1="76.9" x2="35.2" y2="78.6"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="28.2" y1="73.5" x2="38.4" y2="60.7"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26.6" y1="71" x2="29.5" y2="52.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.8" y1="75.4" x2="15.6" y2="61.8"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.4" y1="76.8" x2="6.9" y2="79.1"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.5" y1="77.9" x2="9.4" y2="93.4"></line></g></g><g><g><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="20.9" y1="72.1" x2="22.2" y2="56"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="19.5" y1="73.1" x2="10.1" y2="70"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="19.2" y1="75" x2="6.8" y2="87.2"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="20.2" y1="75.6" x2="15.2" y2="95.4"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="22.6" y1="76.5" x2="29.5" y2="87.2"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="28.5" y1="71.6" x2="38.4" y2="69.1"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="23.3" y1="72.9" x2="25.9" y2="72.2"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="33.6" y1="56.9" x2="35.2" y2="54.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="22.1" y1="71.7" x2="28.8" y2="63"></line></g></g><g><g><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="76.1" y1="47.4" x2="77.5" y2="61.4"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="75.8" y1="43.7" x2="75.9" y2="45.1"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="81.5" y1="44" x2="90.4" y2="46.8"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="77.2" y1="40.2" x2="93.5" y2="28.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="76.3" y1="39.7" x2="84.5" y2="21.5"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="74.3" y1="38.5" x2="70.7" y2="30.1"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="74" y1="42" x2="62.2" y2="47.1"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="70.6" y1="50.4" x2="64.6" y2="61.7"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="74.6" y1="43.1" x2="72.4" y2="47.1"></line></g></g><g><g><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="80" y1="42.2" x2="77.8" y2="23.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="76.7" y1="42.7" x2="65.4" y2="38.3"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="79.4" y1="45.6" x2="70.3" y2="63.7"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="80.7" y1="45" x2="84.6" y2="55.4"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="81.7" y1="43.3" x2="93.5" y2="37.4"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="80.9" y1="42.5" x2="90.4" y2="23.1"></line></g></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M53.5,58.4l-2.6,11.8c0,0-0.3,1.3,0.9,1.6c1.1,0.2,1.4-0.9,1.4-0.9l2.6-12.2c0,0,0.5-1.8-0.9-1.8C53.8,57,53.5,58.4,53.5,58.4z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                60.5,71.2 54.5,67.7 50.5,70 50.6,71.6 56.6,75 60.6,72.5"></polygon>
                <g><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M25.7,7l-6.5-4c0,0,0,0,0,0l0,0l0,0C19,3,18.7,3,18.4,3.1c-0.6,0.4-1.1,1.3-1.1,2c0,0.3,0.1,0.6,0.3,0.7l0,0l0,0c0,0,0,0,0,0
                l6.5,4L25.7,7z"></path><g><ellipse transform="matrix(0.5 -0.866 0.866 0.5 5.1512 25.8003)" fill="#F8F8F8" cx="24.9" cy="8.4" rx="1.6" ry="0.9"></ellipse><ellipse transform="matrix(0.5 -0.866 0.866 0.5 5.1512 25.8003)" fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="24.9" cy="8.4" rx="1.6" ry="0.9"></ellipse></g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.7,25.5l1-3.3c0,0,0.9-0.1,1.2,0c1.3,0.2,1.3,0.9,1.3,0.9l-1.1,3.7"></path><g><g><path fill="#F8F8F8" d="M24.6,9.5L24.6,9.5C24.6,9.5,24.6,9.5,24.6,9.5z"></path>
                <path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M24.6,9.5L24.6,9.5C24.6,9.5,24.6,9.5,24.6,9.5z"></path></g><g><path fill="#F8F8F8" d="M56.2,23.9l-6.4-3.4c-1-0.5-2.2-0.6-3.2-0.2l-8.3,3.2c-0.6,0.2-1.4,0.2-1.9-0.1L30.5,20
                c-0.6-0.4-1.1-1.1-1.1-1.8l-0.1-2L29,12.3c-0.1-1.9-1.2-3.6-2.8-4.5l-0.4-0.2c0,0,0,0,0,0l0,0l0,0c-0.1-0.1-0.3,0-0.5,0.1
                c-0.5,0.3-0.8,0.9-0.8,1.4c0,0.3,0.1,0.4,0.2,0.5l0,0l0.6,0.4c0.9,0.5,1.4,1.4,1.5,2.4l0.2,3.3l0.1,1.8l0.1,1
                c0.1,1.2,0.7,2.3,1.7,3l0,0l6.7,3.9c1,0.6,2.2,0.7,3.3,0.3l7.5-2.8c1.1-0.4,2.3-0.3,3.3,0.3l5.5,3.2c0,0,1.7,0.9,1.5-0.6
                C56.4,24.1,56.2,23.9,56.2,23.9z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M56.2,23.9l-6.4-3.4c-1-0.5-2.2-0.6-3.2-0.2l-8.3,3.2c-0.6,0.2-1.4,0.2-1.9-0.1L30.5,20c-0.6-0.4-1.1-1.1-1.1-1.8l-0.1-2
                L29,12.3c-0.1-1.9-1.2-3.6-2.8-4.5l-0.4-0.2c0,0,0,0,0,0l0,0l0,0c-0.1-0.1-0.3,0-0.5,0.1c-0.5,0.3-0.8,0.9-0.8,1.4
                c0,0.3,0.1,0.4,0.2,0.5l0,0l0.6,0.4c0.9,0.5,1.4,1.4,1.5,2.4l0.2,3.3l0.1,1.8l0.1,1c0.1,1.2,0.7,2.3,1.7,3l0,0l6.7,3.9
                c1,0.6,2.2,0.7,3.3,0.3l7.5-2.8c1.1-0.4,2.3-0.3,3.3,0.3l5.5,3.2c0,0,1.7,0.9,1.5-0.6C56.4,24.1,56.2,23.9,56.2,23.9z"></path></g></g><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M58.3,24.8l-6.5-4c0,0,0,0,0,0l0,0l0,0c-0.2-0.1-0.5-0.1-0.8,0.1c-0.6,0.4-1.1,1.3-1.1,2c0,0.3,0.1,0.6,0.3,0.7l0,0l0,0
                c0,0,0,0,0,0l6.5,4L58.3,24.8z"></path><g><ellipse transform="matrix(0.5 -0.866 0.866 0.5 6.0497 62.8404)" fill="#F8F8F8" cx="57.4" cy="26.2" rx="1.6" ry="0.9"></ellipse><ellipse transform="matrix(0.5 -0.866 0.866 0.5 6.0497 62.8404)" fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="57.4" cy="26.2" rx="1.6" ry="0.9"></ellipse></g><g><polygon fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                15.4,37.9 36.9,50.3 26.1,56.9 4.4,44.4"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                21,19.9 42.5,32.3 24.8,41.9 3.3,29.5"></polygon><polyline fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                36.9,50.3 42.5,32.3 24.8,41.9 26.1,56.9 36.9,50.3"></polyline><polyline fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                15.4,37.9 21,19.9 3.3,29.5 4.4,44.4 15.4,37.9"></polyline><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                3.3,29.5 4.4,44.4 26.1,56.9 24.8,41.9"></polygon><g display="none"><g><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26.1" y1="56.9" x2="24.8" y2="41.9"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="20.7" y1="53.8" x2="19.4" y2="38.8"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="15.3" y1="50.7" x2="14" y2="35.7"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="9.9" y1="47.5" x2="8.7" y2="32.6"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="4.4" y1="44.4" x2="3.3" y2="29.5"></line></g><g>	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="21" y1="19.9" x2="15.4" y2="37.9"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26.4" y1="23" x2="20.8" y2="41"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="31.7" y1="26.1" x2="26.1" y2="44.1"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="37.1" y1="29.2" x2="31.5" y2="47.2"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="42.5" y1="32.3" x2="36.9" y2="50.3"></line></g><g>	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="4.4" y1="44.4" x2="15.4" y2="37.9"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="9.9" y1="47.5" x2="20.8" y2="41"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="15.3" y1="50.7" x2="26.1" y2="44.1"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="20.7" y1="53.8" x2="31.5" y2="47.2"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26.1" y1="56.9" x2="36.9" y2="50.3"></line></g><g>	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="4.4" y1="44.4" x2="15.4" y2="37.9"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="4.1" y1="39.4" x2="17.3" y2="31.9"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="3.7" y1="34.4" x2="19.1" y2="25.9"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="3.3" y1="29.5" x2="21" y2="19.9"></line></g><g>	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="21" y1="19.9" x2="42.5" y2="32.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="19.1" y1="25.9" x2="40.6" y2="38.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="17.3" y1="31.9" x2="38.7" y2="44.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="15.4" y1="37.9" x2="36.9" y2="50.3"></line></g><g display="inline">	<line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="3.3" y1="29.5" x2="24.8" y2="41.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="3.7" y1="34.4" x2="25.2" y2="46.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="4.1" y1="39.4" x2="25.7" y2="51.9"></line><line fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="4.4" y1="44.4" x2="26.1" y2="56.9"></line></g></g><g display="none">	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.8" y1="41.9" x2="42.5" y2="32.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="25.2" y1="46.9" x2="40.6" y2="38.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="25.7" y1="51.9" x2="38.7" y2="44.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="26.1" y1="56.9" x2="36.9" y2="50.3"></line></g><g display="none">	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="42.5" y1="32.3" x2="36.9" y2="50.3"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="36.6" y1="35.5" x2="33.3" y2="52.5"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="30.7" y1="38.7" x2="29.7" y2="54.7"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="24.8" y1="41.9" x2="26.1" y2="56.9"></line></g><g display="none">	<line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="21" y1="19.9" x2="15.4" y2="38"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="15.1" y1="23.1" x2="11.8" y2="40.1"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="9.2" y1="26.3" x2="8.1" y2="42.2"></line><line display="inline" fill="none" stroke="#231815" stroke-width="0.25" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="3.3" y1="29.5" x2="4.4" y2="44.4"></line></g></g></g>
            </g>
        </symbol>
        <symbol id="air-cleaner" viewBox="0 0 100 100">
            <g>
                <path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M73.9,21.2l-9.8,6.1c-0.6,0.4-1.5,0.4-2.1,0L29.4,7.9l-3.5,69.3c0,1.7,0.8,3.2,2.2,4L57.3,98c2.2,1.3,5,1.3,7.2,0l8-4.6
                c1-0.6,1.6-1.6,1.6-2.8L73.9,21.2z"></path><polygon fill="#F8F8F8" points="74.1,92.5 73.9,21.2 63.1,27.9 60.9,99 60.9,99 63.8,98.4"></polygon><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M73.9,21.2l-0.7,1l-9,5.2c-0.7,0.4-1.5,0.4-2.2,0L29.4,7.9l-3.5,69.3c0,1.7,0.8,3.2,2.2,4L57.3,98c2.2,1.3,5,1.3,7.2,0l8-4.6
                c1-0.6,1.6-1.6,1.6-2.8L73.9,21.2z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M39,1.4l-8.9,5.1c-0.9,0.5-0.9,1.9,0,2.4l31.6,18.2c0.8,0.5,1.9,0.5,2.7,0l8.7-5c0.9-0.5,0.9-1.9,0-2.4L41.8,1.4
                C40.9,0.9,39.9,0.9,39,1.4z"></path><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                44.8,30.2 42,28.5 42,24.8 44.8,26.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                71.7,43.4 64.3,47.4 64.3,49.5 71.7,45.5"></polygon><g><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                60.4,21.8 38.5,9.2 42.9,6.7 64.8,19.3"></polygon><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="38.5" y1="9.2" x2="60.4" y2="21.8"></line><line fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="40.7" y1="7.9" x2="62.6" y2="20.6"></line></g>
            </g>
        </symbol>
        <symbol id="light" viewBox="0 0 100 100">
            <g>
                <ellipse fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="50" cy="89.8" rx="15.9" ry="9.2"></ellipse><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M51.4,89.8V25.3h-2.7v64.4c0,0.2,0.1,0.4,0.4,0.6c0.5,0.3,1.4,0.3,1.9,0C51.2,90.2,51.4,90,51.4,89.8z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M65.9,30.8c0-0.5-0.1-1.1-0.3-1.6L62.1,7.3l-24.2,0l-3.6,22c-0.2,0.5-0.3,1.1-0.3,1.6l0,0h0c0,2.4,1.6,4.7,4.7,6.5
                c6.2,3.6,16.3,3.6,22.5,0C64.4,35.6,65.9,33.2,65.9,30.8L65.9,30.8L65.9,30.8z"></path><path fill="#F8F8F8" d="M65.7,29.2L62.1,7.3L50,7.3V40c4.1,0,8.2-0.9,11.3-2.7c3.1-1.8,4.7-4.1,4.7-6.5h0v0
                C65.9,30.3,65.8,29.8,65.7,29.2z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M65.9,30.8c0-0.5-0.1-1.1-0.3-1.6L62.1,7.3l-24.2,0l-3.6,22c-0.2,0.5-0.3,1.1-0.3,1.6l0,0h0c0,2.4,1.6,4.7,4.7,6.5
                c6.2,3.6,16.3,3.6,22.5,0C64.4,35.6,65.9,33.2,65.9,30.8L65.9,30.8L65.9,30.8z"></path><ellipse fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="50" cy="8.1" rx="12.2" ry="7.1"></ellipse>
            </g>
        </symbol>
        <symbol id="suitcase" viewBox="0 0 100 100">
            <g>
                <path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M30.3,82c0-1.3,0.9-1.8,2-1.2c1.1,0.6,2,2.2,2,3.5c0,0.8-0.3,1-0.8,1.4L32,86.6C30.9,85.9,30.3,83.3,30.3,82z"></path><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -37.8602 26.6505)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="30.8" cy="84" rx="1.6" ry="2.8"></ellipse><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M51.6,94.5c0-1.3,0.9-1.8,2-1.2s2,2.2,2,3.5c0,0.8-0.3,1-0.8,1.4L53.3,99C52.2,98.4,51.6,95.8,51.6,94.5z"></path><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -41.2322 38.9562)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="52.1" cy="96.4" rx="1.6" ry="2.8"></ellipse><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M67,86.1c0-1.3,0.9-1.8,2-1.2c1.1,0.6,2,2.2,2,3.5c0,0.8-0.3,1-0.8,1.4l-1.5,0.8C67.6,90,67,87.4,67,86.1z"></path><ellipse transform="matrix(0.866 -0.5 0.5 0.866 -34.9931 45.5392)" fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="67.5" cy="88.1" rx="1.6" ry="2.8"></ellipse><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70.3,39.6L44.8,24.8c-0.8-0.5-1.7-0.4-2.4,0c-0.7,0.4-12.6,7.4-13.4,7.8c0,0,0,0,0,0c0,0,0,0,0,0c0,0,0,0,0,0
                c-0.7,0.4-1.1,1.1-1.1,2l0,42.6c0,1.5,0.8,2.9,2.1,3.7l25.3,14.6c0.8,0.4,1.6,0.4,2.3,0l0,0l0,0c0,0,0,0,0,0l13.6-8
                c0.6-0.4,1-1.1,1-2l0-42.6C72.3,41.6,71.7,40.3,70.3,39.6z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70.3,39.6L44.8,24.8c-0.8-0.5-1.7-0.4-2.4,0c-0.7,0.4-12.6,7.4-13.4,7.8c0,0,0,0,0,0c0,0,0,0,0,0c0,0,0,0,0,0
                c-0.7,0.4-1.1,1.1-1.1,2l0,42.6c0,1.5,0.8,2.9,2.1,3.7l25.3,14.6c0.8,0.4,1.6,0.4,2.3,0l0,0l0,0c0,0,0,0,0,0l13.6-8
                c0.6-0.4,1-1.1,1-2l0-42.6C72.3,41.6,71.7,40.3,70.3,39.6z"></path><path fill="#F8F8F8" d="M69.2,42.5l-8.7,5c-1.1,0.6-1.7,1.8-1.7,3l0,42.8c0,0.8,0.9,1.4,1.6,0.9l10.2-5.9c1.1-0.6,1.7-1.8,1.7-3
                l0-41C72.3,42.7,70.5,41.7,69.2,42.5z"></path><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M70.1,39.4L44.8,24.8c-0.8-0.5-1.7-0.4-2.4,0c-0.7,0.4-12.7,7.4-13.5,7.8c0,0,0,0,0,0c0,0,0,0,0,0c0,0,0,0,0,0
                c-0.7,0.4-1.2,1.2-1.2,2.1l0,42.6c0,1.5,0.8,2.9,2.1,3.7l25.3,14.6c0.8,0.4,1.6,0.4,2.3,0l0,0l0,0c0,0,0,0,0,0l13.7-7.9
                c0.7-0.6,1-1.1,1-2l0-42.6C72.3,41.6,71.4,40.2,70.1,39.4z"></path><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50.9,86.6 52.9,87.7 52.9,51.9 51,50.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                45.1,83.2 47.1,84.3 47.1,48.5 45.2,47.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                39.3,79.8 41.3,81 41.3,45.2 39.4,44"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                62.6,35.1 64.5,36.2 64.5,13.8 62.6,12.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                64.5,36.2 66.4,37.3 66.4,12.7 64.5,13.8"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                50.9,28.4 52.8,29.5 52.8,4.9 50.9,6"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                49,27.3 50.9,28.4 50.9,6 49.1,4.9"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                33.5,76.5 35.4,77.6 35.4,41.8 33.5,40.7"></polygon><path fill="none" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M64.3,42.8L39,28.2c-0.8-0.5-1.7-0.4-2.4,0l-2,1.1c0.7-0.4,1.6-0.5,2.4,0L62.4,44c1.3,0.8,2.1,2.2,2.1,3.7v0.8v4.7v38.5l1.9-1.1
                V52v-4.2v-1.2C66.4,45,65.6,43.6,64.3,42.8z"></path><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M64.5,13.8l1.9-1.1c0-4.1-2.3-7.2-7-9.9C57.1,1.4,55.3,1,53.5,1c-2.6,0-3.7,1.9-3.7,1.9L50.9,6l2-1.1c0,0,0.2-0.8,2.3-0.3
                l6.3,3.7L64.5,13.8z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M62.6,12.7c0-2.8-2.6-5.5-5.9-7.4S50.9,3.3,50.9,6l-1.8-1.1c0-3.4,4-3.8,8.7-1.1s6.8,6,6.8,10.1L62.6,12.7"></path></g><g><path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M57.2,41l1.9-1.1c0-4.1-2.3-7.2-7-9.9c-2.3-1.4-4.1-1.8-5.9-1.8c-2.6,0-3.7,1.9-3.7,1.9l1.1,3.1l2-1.1c0,0,0.2-0.8,2.3-0.3
                l6.3,3.7L57.2,41z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M55.3,39.9c0-2.8-2.6-5.5-5.9-7.4c-3.2-1.9-5.9-2.1-5.9,0.6L41.7,32c0-3.4,4-3.8,8.7-1.1s6.8,6,6.8,10.1L55.3,39.9"></path></g>
            </g>
        </symbol>
        <symbol id="carpet" viewBox="0 0 100 100">
            <g>
                <path fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M1.4,50.7l47.4,27.4c0.8,0.4,1.7,0.4,2.5,0l47.4-27.4c0.5-0.3,0.5-1.1,0-1.4L51.2,21.9c-0.8-0.4-1.7-0.4-2.5,0L1.4,49.3
                C0.9,49.6,0.9,50.4,1.4,50.7z"></path><path fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" d="
                M7.6,50.7l41.1,23.8c0.8,0.4,1.7,0.4,2.5,0l41.1-23.8c0.5-0.3,0.5-1.1,0-1.4L51.2,25.5c-0.8-0.4-1.7-0.4-2.5,0L7.6,49.3
                C7.1,49.6,7.1,50.4,7.6,50.7z"></path>
            </g>
        </symbol>
        <symbol id="cardboard" viewBox="0 0 100 100">
            <g>
                <polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.7,99 95.7,76.5 43.5,46.3 4.3,68.9"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.7,53.7 95.7,31.2 43.5,1 4.3,23.6"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                56.7,99 56.7,53.7 95.7,31.2 95.7,76.5"></polygon><polygon fill="#FFFFFF" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                4.3,23.6 4.3,68.9 56.7,99 56.7,53.7"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                20.6,14.2 72.9,44.4 79.4,40.6 27.1,10.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.4,40.6 79.4,51.9 72.9,55.7 72.9,44.4"></polygon><polygon fill="#F8F8F8" stroke="#231815" stroke-width="0.5" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                79.4,74.6 79.4,85.9 72.9,89.7 72.9,78.4"></polygon>
            </g>
        </symbol>
    </defs>
</svg></div>
    <svg display="none" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
        <defs>
            <symbol id="arrow_back" viewBox="0 0 24 24">
                <path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"></path>
            </symbol>
            <symbol id="bookmark_border" viewBox="0 0 24 24">
                <path d="M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2zm0 15l-5-2.18L7 18V5h10v13z"></path>
            </symbol>
            <symbol id="bookmark" viewBox="0 0 24 24">
                <path d="M17 3H7c-1.1 0-1.99.9-1.99 2L5 21l7-3 7 3V5c0-1.1-.9-2-2-2z"></path>
            </symbol>
            <symbol id="close" viewBox="0 0 24 24">
                <path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path>
            </symbol>
            <symbol id="mood" viewBox="0 0 24 24">
                <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm3.5-9c.83 0 1.5-.67 1.5-1.5S16.33 8 15.5 8 14 8.67 14 9.5s.67 1.5 1.5 1.5zm-7 0c.83 0 1.5-.67 1.5-1.5S9.33 8 8.5 8 7 8.67 7 9.5 7.67 11 8.5 11zm3.5 6.5c2.33 0 4.31-1.46 5.11-3.5H6.89c.8 2.04 2.78 3.5 5.11 3.5z"></path>
            </symbol>
            <symbol id="sentiment_very_dissatisfied" viewBox="0 0 24 24">
                <path fill="none" d="M0 0h24v24H0V0z"></path>
                <circle cx="15.5" cy="9.5" r="1.5"></circle>
                <circle cx="8.5" cy="9.5" r="1.5"></circle>
                <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm0-6c-2.33 0-4.32 1.45-5.12 3.5h1.67c.69-1.19 1.97-2 3.45-2s2.75.81 3.45 2h1.67c-.8-2.05-2.79-3.5-5.12-3.5z"></path>
            </symbol>
            <symbol id="chevron_right" viewBox="0 0 24 24">
                <path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"></path>
            </symbol>
            <symbol id="help" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"></path>
            <symbol id="chevron_left" viewBox="0 0 24 24">
                <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z"></path>
            </symbol>
            <symbol id="warning" viewBox="0 0 24 24">
                <path d="M0 0h24v24H0z" fill="none"></path><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"></path>
            </symbol>
            <symbol id="keyboard_arrow_right" viewBox="0 0 24 24">
                <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"></path><path fill="none" d="M0 0h24v24H0V0z"></path>
            </symbol>    
            <symbol id="open_in_new" viewBox="0 0 24 24">
                <path d="M19 19H5V5h7V3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2v-7h-2v7zM14 3v2h3.59l-9.83 9.83 1.41 1.41L19 6.41V10h2V3h-7z"></path>
            </symbol>
            <symbol id="build" viewBox="0 0 24 24">
                <path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z"></path>
            </symbol>
            <symbol id="aircon" viewBox="0 0 34 34">
                	<path d="M31.11,9.4H2.89c-1.06,0-1.92,0.86-1.92,1.92v10.55c0,1.06,0.86,1.92,1.92,1.92h1.24l1.82-3.58H27.8l2.06,3.58
                            h1.25c1.06,0,1.92-0.86,1.92-1.92V11.32C33.03,10.26,32.17,9.4,31.11,9.4z"></path>
                    <polygon points="6.82,21.64 5.73,23.8 28.22,23.8 26.98,21.64"></polygon>
            </symbol>
            <symbol id="bath" viewBox="0 0 34 34">
                <path d="M32.16,10.74H1.84c-0.45,0-0.82,0.35-0.82,0.78c0,0.43,0.37,0.78,0.82,0.78h0.99l2.7,7.96
                        c0.44,1.28,1.36,2.32,2.54,2.94l0,0c-0.44,1.42-2.3,1.82-2.26,2.61c0.04,0.8,1.24,0.62,2.04,0.27c0.8-0.35,2.56-2.23,2.56-2.23
                        l-0.01,0c0.11,0.01,0.21,0.01,0.32,0.01h12.46c0.11,0.11,1.78,1.87,2.55,2.22c0.8,0.35,1.99,0.53,2.04-0.27
                        c0.04-0.76-1.66-1.17-2.19-2.45c1.36-0.61,2.43-1.74,2.9-3.17l2.58-7.9h1.09c0.45,0,0.82-0.35,0.82-0.78
                        C32.98,11.1,32.61,10.74,32.16,10.74z"></path>
            </symbol>
            <symbol id="house" viewBox="0 0 34 34">
                <path d="M13.78,30.68v-9.66h6.44v9.66h8.05V17.8h4.83L17,3.32L0.9,17.8h4.83v12.88H13.78z"></path>
            </symbol>
            <symbol id="washer" viewBox="0 0 34 34">
                <path d="M12.89,24.02c2.27,2.27,5.96,2.27,8.23,0s2.27-5.96,0-8.23L12.89,24.02z M25.72,2.48L8.28,2.47
                    c-1.61,0-2.91,1.29-2.91,2.91v23.25c0,1.61,1.29,2.91,2.91,2.91h17.44c1.61,0,2.91-1.29,2.91-2.91V5.37
                    C28.63,3.76,27.33,2.48,25.72,2.48z M14.09,5.37c0.8,0,1.45,0.65,1.45,1.45s-0.65,1.45-1.45,1.45c-0.8,0-1.45-0.65-1.45-1.45
                    S13.29,5.37,14.09,5.37z M9.73,5.37c0.8,0,1.45,0.65,1.45,1.45s-0.65,1.45-1.45,1.45c-0.8,0-1.45-0.65-1.45-1.45
                    S8.93,5.37,9.73,5.37z M17,28.63c-4.81,0-8.72-3.91-8.72-8.72s3.91-8.72,8.72-8.72s8.72,3.91,8.72,8.72S21.81,28.63,17,28.63z"></path>
            </symbol>
            <symbol id="water-cleaning" viewBox="0 0 34 34">
                <path d="M17,31.69c5.68,0,10.28-4.6,10.28-10.28C27.28,13.7,17,2.31,17,2.31S6.72,13.7,6.72,21.41
                    C6.72,27.09,11.32,31.69,17,31.69z"></path>
            </symbol>
            <symbol id="fan" viewBox="0 0 34 34">
                <path d="M16.73,13.19c0.87,0,1.67,0.25,2.38,0.65c1.68-3.03,3.66-8.25,3.5-8.99c-0.23-1.03-1.77-2.07-8.05-1.76
                    S8.3,6.16,10.62,7.16c3.01,1.3,4.31,3.55,4.97,6.18C15.95,13.25,16.33,13.19,16.73,13.19z"></path>
                <path d="M11.89,18.03c-3.47,0.06-8.94,0.95-9.5,1.46c-0.78,0.71-0.9,2.57,2.5,7.85s5.79,3.88,5.49,1.38
                    c-0.38-3.24,0.91-5.49,2.84-7.37C12.41,20.49,11.89,19.32,11.89,18.03z"></path>
                <path d="M29.18,18.14c-2.62,1.95-5.22,1.96-7.82,1.22c-0.35,1.2-1.14,2.2-2.19,2.83c1.78,2.97,5.29,7.27,6.01,7.5
                    c1.01,0.32,2.67-0.5,5.55-6.09C33.61,18,31.2,16.64,29.18,18.14z"></path>
                <path d="M20.09,18.03c0-1.27-0.71-2.36-1.75-2.93c-0.48-0.26-1.02-0.43-1.6-0.43c-0.29,0-0.58,0.05-0.85,0.12
                    c-1.44,0.38-2.51,1.68-2.51,3.23c0,0.02,0,0.03,0,0.05c0.01,0.9,0.37,1.71,0.96,2.3c0.61,0.62,1.46,1.01,2.39,1.01
                    c0.64,0,1.23-0.19,1.74-0.5c0.73-0.44,1.27-1.15,1.49-1.99C20.03,18.62,20.09,18.33,20.09,18.03z"></path>
            </symbol>
            <symbol id="toilet" viewBox="0 0 34 34">
                <path d="M7.54,1.96L4.73,2.35l2.22,15.8v5c0,1.07,0.38,2.09,1.06,2.89c1.25,1.45,1.94,3.33,1.94,5.29v0.71h8.31v-0.88
                    c0-1.63,1.26-2.95,2.81-2.95c4.23,0,7.65-3.6,7.65-8.04v-2.33H9.77L7.54,1.96z"></path>
                <path d="M28.62,15.18H10.89c-0.36,0-0.65,0.29-0.65,0.65V16c0,0.36,0.29,0.65,0.65,0.65h17.74
                    c0.36,0,0.65-0.29,0.65-0.65v-0.16C29.27,15.48,28.98,15.18,28.62,15.18z"></path>
            </symbol>
            <symbol id="kitchen" viewBox="0 0 34 34">
                <path d="M1.46,8.34v17.33h31.08V8.34H1.46z M6.33,10.13h21.34v0.76H6.33V10.13z M15.73,18.92H14.4
                    c-0.26,1.86-1.75,3.31-3.63,3.5v1.25H9.91v-1.25c-1.88-0.2-3.37-1.64-3.63-3.5H5.08v-0.86h1.16c0.14-2,1.69-3.58,3.66-3.79v-1.25
                    h0.86v1.25c1.98,0.21,3.52,1.8,3.66,3.79h1.3V18.92z M28.87,18.92h-1.26c-0.26,1.88-1.79,3.34-3.7,3.51v1.24h-0.86v-1.25
                    c-1.85-0.23-3.31-1.66-3.57-3.5h-1.26v-0.86h1.23c0.14-1.97,1.65-3.55,3.59-3.78v-1.25h0.86v1.24c2.01,0.18,3.59,1.78,3.73,3.8
                    h1.23V18.92z"></path>
            </symbol>
            <symbol id="housekeeping" viewBox="0 0 34 34">
                <path d="M30.42,24.64c-0.16-2.36-0.35-5.3-3.27-5.3v-1.83c-2.7,0-4.88-2.33-4.88-5.21V7.9h-1.12
                    c0-1.58-0.26-2.98-0.76-4.16c-0.58-1.36-1.85-2.24-3.31-2.29c-1.4-0.05-2.69,0.71-3.34,1.97C13.12,4.66,12.8,6.16,12.8,7.9h-1.12
                    v4.4c0,2.88-2.19,5.21-4.88,5.21h0v1.83c-2.86,0.04-3.06,2.95-3.21,5.29c-0.1,1.43-0.19,2.92-0.86,3.2l0.41,0.98
                    c1.27-0.54,1.38-2.27,1.5-4.1c0.17-2.57,0.42-4.26,2.16-4.3v12.14h20.36V20.4c1.79,0,2.04,1.71,2.21,4.31
                    c0.12,1.83,0.24,3.57,1.5,4.1l0.41-0.98C30.62,27.55,30.52,26.07,30.42,24.64z M14.69,3.91c0.47-0.91,1.34-1.45,2.36-1.4
                    c1.04,0.04,1.95,0.67,2.37,1.65c0.45,1.05,0.67,2.3,0.67,3.74h-6.24C13.85,6.33,14.14,4.99,14.69,3.91z M20.93,24.4
                    c0,2.17-1.76,3.93-3.93,3.93c-2.17,0-3.93-1.76-3.93-3.93v-1.28h7.86V24.4z"></path>
            </symbol>
            <symbol id="disposal" viewBox="0 0 34 34">
                <path d="M7.05,28.6c0,1.82,1.49,3.32,3.32,3.32h13.26c1.82,0,3.32-1.49,3.32-3.32V8.71H7.05V28.6z M28.6,3.74h-5.8
                    l-1.66-1.66h-8.29L11.2,3.74H5.4v3.32H28.6V3.74z"></path>
            </symbol>
            <symbol id="rip" viewBox="0 0 34 34">
                <path d="M27.46,17c0-3.32-1.56-6.29-3.97-8.2l-1.26-7.49H11.77L10.53,8.8C8.1,10.71,6.54,13.67,6.54,17
                    s1.56,6.29,3.99,8.2l1.24,7.49h10.46l1.26-7.49C25.9,23.29,27.46,20.32,27.46,17z M9.16,17c0-4.33,3.52-7.84,7.84-7.84
                    s7.84,3.52,7.84,7.84s-3.52,7.84-7.84,7.84S9.16,21.33,9.16,17z"></path>
            </symbol>
            <symbol id="moving" viewBox="0 0 34 34">
                <path d="M28.24,11.38h-4.22V5.76H4.35c-1.55,0-2.81,1.27-2.81,2.81v15.46h2.81c0,2.33,1.88,4.22,4.22,4.22
                    s4.22-1.88,4.22-4.22h8.43c0,2.33,1.88,4.22,4.22,4.22s4.22-1.88,4.22-4.22h2.81V17L28.24,11.38z M8.57,26.14
                    c-1.17,0-2.11-0.94-2.11-2.11c0-1.17,0.94-2.11,2.11-2.11s2.11,0.94,2.11,2.11C10.67,25.19,9.73,26.14,8.57,26.14z M27.54,13.49
                    L30.3,17h-6.27v-3.51H27.54z M25.43,26.14c-1.17,0-2.11-0.94-2.11-2.11c0-1.17,0.94-2.11,2.11-2.11s2.11,0.94,2.11,2.11
                    C27.54,25.19,26.6,26.14,25.43,26.14z"></path>
            </symbol>
            <symbol id="aircon-install" viewBox="0 0 34 34">
                <path d="M22.89,21.46c-0.06-0.07-0.1-0.15-0.15-0.23H7.19l-1.05,2.07h20.94l-0.28-0.35
                    C25.34,23.24,23.84,22.66,22.89,21.46z"></path>
                <path d="M22.13,19.87c-0.25-1.05-0.09-2.16,0.52-3.08l0.29-0.44l2.26,2.81l1.27-1l-2.22-2.83l0.53-0.17
                    c1.63-0.52,3.42,0.02,4.47,1.36c0.94,1.2,1.13,2.8,0.52,4.15l1.8,2.3c0.47-0.33,0.79-0.88,0.79-1.51V11.32
                    c0-1.02-0.83-1.84-1.84-1.84H3.4c-1.02,0-1.84,0.83-1.84,1.84v10.14c0,1.02,0.83,1.84,1.84,1.84H4.6l1.75-3.44H22.13z"></path>
                <path d="M33.5,26.73l-0.02-0.07l-2.65-3.37l-1.98-2.52l0.12-0.22c0.6-1.12,0.47-2.51-0.33-3.53
                    c-0.73-0.93-1.9-1.38-3.06-1.22l1.97,2.52l-2.01,1.57l-0.48,0.37l-0.3-0.37l-1.74-2.17c-0.29,0.68-0.32,1.45-0.11,2.17
                    c0.12,0.39,0.31,0.77,0.58,1.12c0.07,0.09,0.15,0.17,0.23,0.25c0.81,0.84,2,1.21,3.12,0.92l0.2-0.05l0.05-0.01l0.96,1.22l0.46,0.58
                    l3.21,4.09c0.06,0.08,0.16,0.09,0.24,0.03l1.44-1.13c0.1-0.06,0.12-0.11,0.12-0.14L33.5,26.73z"></path>
            </symbol>
            <symbol id="screen" viewBox="0 0 34 34">
                <path d="M8.26,1.13v31.75h17.48V1.13H8.26z M23.83,31.38H10.19V17.74h13.64V31.38z M23.83,16.26H10.19V2.62h13.64
                    V16.26z"></path>
            </symbol>
            <symbol id="fusuma" viewBox="0 0 34 34">
                <path d="M1.7,30.24h14.57V3.76H1.7V30.24z M12.87,16.35h2.18v2.18h-2.18V16.35z"></path>
                <path d="M17.73,3.76v26.47H32.3V3.76H17.73z M21.14,18.53h-2.18v-2.18h2.18V18.53z"></path>
            </symbol>
            <symbol id="tatami" viewBox="0 0 34 34">
                <rect x="1.24" y="8.33" width="31.51" height="0.64"></rect>
                <polygon points="1.25,22.64 32.75,22.64 32.75,11.36 1.24,11.36 1.24,25.67 32.75,25.67 32.75,25.03 1.25,25.03 	"></polygon>
                <rect x="32.75" y="22.64" class="st1" width="0.01" height="2.39"></rect>
            </symbol>
            <symbol id="Gradient" viewBox="0 0 64 64">
                <image id="Gradient" x="10.156" y="10.156" width="43.688" height="43.688" xlink:href="data:img/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAYAAAAehFoBAAAPmklEQVRYhXWZW4wlx1nH/99XVd1nzuzM7G1mvevY3s3yYFiDY8dOZIK8ViB2YotLICABhshxHOQHcJzwEvOcN4gvDyBZxIGAEssyMQiCL0gmC8ghEZYdY+MVUnzLemd3Z3e9cz2nL1Uf+r6qc2b8wEil7tPdU/2rf323qqZjt78KhgCI0D+CgPRE4uTcEeTDAD5a1XR4ZugP+MBzRFI7oiGJwE1bqgJo6FL+zUnAUbZYpOWEcg2QPm0hShO7uL651ZwdN/1bLPQDSniRBFGfIQFcUhBGMkKGEMH7rjMwvQwD1GbnPz07F+6f311/miD7FUybDUoSKFkX8Ck3hwQF9fYiAesADHznbxgwl+tMBB4OwLWU6zh/YWPrqdW2eRCg12HSKZH2ThBxoBtu+c8CmUEJqKuavrp///A+Ajyk3JsekV8uCV4UMJlyBioJE3VdUTTDFui046j9xNwXKayoEBNA6pc31h4e9elPBNwoVFbZgW762L9PgYG4cGBp7h+Co+PTQUhWcgKuEGEHrC+AfmIWU1XTDnUnoFMlM6hQNj8QqKgJylf0rX1KJ06tXvpVIV6dmIWZBMPstbps366nQhePU5dvZ1MRSEqvnruw9s+xb3/kJJ7ySBss6RKLiBO55CXmAQDwKeq0mML5WjEVZLskYLdTKsFuEM8BdHlw/tqluX23M/E1KCqrphXR8cPzu75zem3tUwJqkyr88WufNlMYBPenl+3e9WUz8aImUnzpnYsXvkgi/+YUyu5lOIeIkBKCdizbKhsgsomoslkXPU40JDChODZnRXVy7Ug3H9x94EEif73JXBxtZWP1a+M+flllpduO/b063NVH9u75bxbxEwfcapvvnF2/9LsMGauCCqgmoIBBBJWCSUSFrB6reZiVTQC3G+1o2+DZFPh9T+ibabB3du/f1mHwGxajyO73py6t/GyCP+l9arG7HtwfYvT6UpgJxP86v3b+94LEsTe1ogFWqqraMPK0T8xAXzOBnQC7guAw0cq6LsDZYzK0mwXhQwR6A6BlAY83N8/9/nDh4FVE7gb1nQTye+rq/vWm/QP65asfr4/u3XuOkebNHCjhjYtnPuYQX8igETX6rKRk0MoUR4aUEqIMLoGE7Z4OninrB2QHVD1BO9Wl6xcXrvhHgA4B1J5dPX0/wH+eHc/dtLhw6AV9LpGRrZ25dG7JO2purKidd5RyLJb+pRqjFwyUeosItSqrwDRRNzuUKUsCR0VZef+0qwNRxtw2AxtcfmLf/AceZYmHyhxUl89f9vDK2umnktAyIN/n1L3E7K4TUznNB8QbvefxdRV3FkN1on6yeubZgXQYoDe4bArZbkNxqm0TiNm5Smg3ZUkuc8BBgyNaJuEzU88XNofLWZXVH67KyUhlTzpkH6Q/ksw0EtbXzzy7d+7gdRpe1J4D+uv8vHdHdKqpJAPqR68Mir3WxWbrEiHcBBIlBpew5yTdsjCz7+5hPX8rQ5a2FbVYe65p1p7bGF16DKB/hbhp2IrN6r/U1dxvm2NZEpULAf2PcgpzkDR+Rd8nJZrMKuuC94suRXuxKjpEt6ygtWi4SgYa0GdIVVZts8B6yNX75y//i4r8LQYp/XY2nLgWYWm2nr1zVz17Z0z991ZX371XhE8qeDM6+4cB4qtq121R0v++t7F8rwNt5gGJZofTGolE1RfGwFWLfsA0ZzFVp18ShtJfqAqwgvI0SsQcaycKQ379wMKRv2GRIZdCiSfJgWQ7lAmVOEHwRLcs7b7ixUurb342CT8JcRfGozO/NR7laB2oKFuAGe6iiiSijgdUTHO+5jSTo0AqDtY1agLB1MwDyfF3Cqpm8ZtL80e/zRJdqaNKZjTYtyX1b6u4jv2VAB+eIJcUPNy7cOXjl1bf+B3APaHmIMlbjMlgUnKsmo6MVWGNEipEIMz4GUozlcBClQFLN64MskdtMXeHOWSHu3pp/uhfsXTO5Vyk3afx+PxjbXPxYQJe5fcB4tig2vPFwczi5whcyhJy++YOf2N17cevgNxJ4TzlEI8kMlU4ghrT3K4JhGTItUiokppDj8qiQ9vVetTf6Ay4Qosgue0fHvgzL/0wmIn02tbXV//njticu8ejf1UH6nWQoiGxg5futb5duWdz9fU7WLp1rVuctTRcmD30NafPoIWnDkyd9WmZ1fqJG9nccmRiSZ6DgWnn2gx8y36jK6A9fMr3gsSbZ7i6PWRQ7TBtrL7+GY/4TLlvNu4mpoRYHFVnLD6zuXryMyx9UmhtwYVPeaTjjB4OnUF7DbHmO9pPiq7UL9m6E7iSbVhfXlqlDnXqUSU1iw41WmsLgz33aGcaVRSqG519zIs8Z0X8pNyUHZFkei3HaY/4XD8++5gOViG0zQz23J1jeDRQTw3YtciD6K2fndA+JH2IcvhSu0WDinpU1JlKgXJkUN+dm61vYxnlGlmAtjv3UGCUoj5nsUllm6uvZEcuWc8ic3vxIa73fd5qFjAGYf6T3egsQG665vEERKfFopjSqeRG/Q9vipIYYMU9drlNAw6kaTc7mh4d5FA92FrkslQiwTuDqnnN3qIoGncSZedJNF09oCyrJmWkgF5jxHcAvjJnalpkSQcFssxUKhLJdUpyih9NjEQ5rvvajzDjEzQ9B+7Qj8a5xtUHuQDnILNY1aMJLKRv36hCgwycYU3FxJBYjokwLTAlrxRtIHH8Y3b1lRYPtFiitCRCyynHAjh9o01TD+aIlChDaw0zrLYwUGDXm9FH35qi5jSqLE3ibIKvx1bcWxp1PSR01otC5Mo0q6sFQzJgB4mczw2MyqRrVRezLUk+ALnqUwMQjtnMrKtos5MkrwP9oBqhngBzh1SAPUWrxJgmuUdWfNXkuKvQQT4ovs2qmrIwVU1JVcSUjhBmmK+bUVqBDk981KrcMnaSeI4obzZYupBo5VFeUiUw9zZbKoyvqzHqkMwcPPdIoYOjUuxQLh9zSMHpUI9XIFi0eiHhSgn9MRG8ZmWkVqZT4GwWCmuQOq3sEKMHRT5GIlfqVoHkNeeKQ1qOltKLCamaFIsJJbMoNQ2F5jo0qKoxqqpBqBpUvkOtLXQIvof3PULo4UMPNKvP+LqBr1q4ukW1J9zn7ZnOnvOhK+ddPg/5upv041vUs8M/Yu6mySA2F5+d7DzktWSartYxOUd2PuIIrsIY6jyhACvsBLSeAmQo2rz0dVd1YAWuWoTFcLfz/ScUiHRm3DbcpHHY/n8X+k8M5oefd6EBc2u7S32z8pc8hZLpAnhybtCTyKSBQCFVMR8a+NAq7DAUaPYxw7s4ATlBaetpFzoD4dBxfXTuSef7W71PCgRWeN/ZkXUA5X859J+cObD0dxxa5joPGLLxNERO6LT/P9CuOMd0o4eD7zoFVQht3vXBAF3Uc4P2BZpdBK289yWuui2uOpjaoZ+vjs4/7fe4R52Px/LzCc4XUN8f8wvVo4ND+77LVTuXB9pC+4jNqS+prWK6YZPK8rSUqpBd2TRyKBGk3jvXjFwQeI42peT7Aen6rqzVbFSUa9zcMU7KTy7c5Y4sfKss5TSkMR8I92B/dY9Efgst3o5RvTpcJckdlt5DdA+PpIRtiaML797FPpy0Se/J8kvOifmd9pu4prKI1dKTJG15x83IB4ZznUUFcbF2nIE1pOU0u70LlGMmnsA7FxMdnftrJBqSzZpOIGsUOCyODvuoMbiH9FYW2qohWUzHVndu+bPO+ydzQslpu48ButhkG9S0gh5YQi6LAkg/YkazbuYwdZC4T6dep5bNLidTrLsDAgp6tPakvLX6EUZ3Il+LxX7VAd/fuPwGNSf686c/wj49abbN5R0+n2MaHYpZSNpLO/BTbNY9jbdW2M+YfbIzkIPEAm2suZwmS56y+ZBnKP8JvZbObt2CHh+nfYO7MBduoz4tksZgmwqb4hXZGD+bVppvSHTPs9cAljOZpmW2RaYmGrLfFmuteLeUcrC8yF7ad+srntrmTQ412GfAtIt/zkn8ttYhVBa45NjezYztHUbBxIGRejwvo/55rPWQTg6i12ZRa1l6XkYksHPTvQrbIlcwl5MBMYE9W9naC5e1io7XX4vJ0kvTdtp80zsvL9uGslcwQvipXbelU2tfIU+2+uYq1wb6kmLQ28Bl4163URUwtbrHiGU0siwtbL/RElen91PeRHFZUetfsnlpzSt6zrpRnnLGJMFg9gO37tjT0pz9svcD/NDVtMYO8+wA8v46DN1NVNP3WQtTnxWAK/bANDGHAp1h0QtcB4hCtoLUCDBiYJyLZbZyI4cUBWNT2vI5dE2nWYw8g5OzdR2Am4j4epkqI2sC/NDzgBpZbx6npcEXKBAoMPzVi4/g/OpxeN6yN/mscM7122vgiUlYKaXRoFOFBegErOA1kDYTMEpTaNvzkazyZHebXE7LOlPJmcrDmdkPPiJlQvU4Hq88DqDxGum4aR+kmbnPUWBPldOR3oA6fFM21u8kx2MzBy5tuuMg28AxA1OfIDWANoGaBFG/4ISkUcXl0AaDppwoUlZXn8kqm9KDetfBbwJ8g2xL03fdew9qLeceOH4AbujOE8sC7537eaoDqKpAw5mfod3ztyM2J1H7t7n2oMqDgsvNO1DF+egZ4hko5ygmZKbE+ShE03pZimwp5WtSokMSvjnsueIJoplflOjtI4z+33jr3YeixG/p0tXTrAfNOHW6BziEG1FXN+uLrTl3Pc/OnQDhVWyc/y6kfxmg0wDWIFgzl4uyhvx5C6lXc0g2CPH6zaB80LClj4aTqDY/ryQkmKdI84jpEAf+kNu3dIdvZ66JLdnSSE1Ia/yY2u/1/egrUrZqvZvx+mUNNHCtbK7+Cu069E9UV78A53Mcs5DmrsFw7pqpORC2o4SYVNozOCYr2tFHUB8hbQS1PaSJcOMeaRQhowTaSkhbAloHeIOQNh1SC0y+i5F9a0iQrv2P0eapXwO5drJO8DQTwDMOGDigdqs0uvhLwPCr2H3oPjjnDdrCR/keQTs8QWQbuECTrjJctG9aRD2EnB1te1AlU4ezZ/NscEeQjswHpstvTn2ztfzIeBwfELjG1relXjNghaWBA1ded9waePljjJe/juHe+1Etfhrs9pdvDdPPUmUJnJfyO4DR9xaixD7CKWzZ0BIHli6vqvU5nY0+IXUAtKnCnZzvt1afatbPPRhTeF2oRiqL1xzyGZ5nAmjgs8JVabprVvHrwOgLaE/dS8wfBruPgmePIMwtgcIcyA0AmskKRw1tle59WXok3Xbti3NZWNiiXlotjsS26eNIUhpj3K6ni+Nz3YXmzX6Lf9CN3It9F2KisL0HXoBtfxTA/wHWnoE72FgGSgAAAABJRU5ErkJggg=="></image>
            </symbol>
            <symbol id="event" viewBox="0 0 24 24">
                <path d="M17 12h-5v5h5v-5zM16 1v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2h-1V1h-2zm3 18H5V8h14v11z"></path>
            </symbol>
            <symbol id="search" viewBox="0 0 24 24">
                <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
            </symbol>
            <!-- iconフォントから移動 -->
            <symbol id="icon-credit-card" viewBox="0 0 256 256">
                <path d="M225.3,53.1H33.6c-11.9,0-21.7,9.7-21.7,21.7v109.5c0,11.9,9.7,21.7,21.7,21.7h191.7c11.9,0,21.7-9.7,21.7-21.7
                    V74.7C247,62.8,237.2,53.1,225.3,53.1z M33.6,64.4h191.7c5.7,0,10.3,4.6,10.3,10.3v15.8H23.2V74.7C23.2,69,27.9,64.4,33.6,64.4z
                    M225.3,194.6H33.6c-5.7,0-10.3-4.6-10.3-10.3v-65.1h212.4v65.1C235.6,190,231,194.6,225.3,194.6z"></path>
                <path d="M215,178.2h-66c-3.1,0-5.7-2.5-5.7-5.7s2.5-5.7,5.7-5.7h66c3.1,0,5.7,2.5,5.7,5.7S218.1,178.2,215,178.2z"></path>
            </symbol>
            <symbol id="icon-drum-type-washer" viewBox="0 0 256 256">
                <path d="M192,242.2H65.4c-11.9,0-21.7-9.7-21.7-21.7v-184c0-11.9,9.7-21.7,21.7-21.7H192c11.9,0,21.7,9.7,21.7,21.7v184
                    C213.7,232.4,203.9,242.2,192,242.2z M65.4,26.1c-5.7,0-10.3,4.6-10.3,10.3v184c0,5.7,4.6,10.3,10.3,10.3H192
                    c5.7,0,10.3-4.6,10.3-10.3v-184c0-5.7-4.6-10.3-10.3-10.3H65.4z"></path>
                <path d="M127.9,208.7c-36.6,0-66.4-29.8-66.4-66.4c0-36.6,29.8-66.4,66.4-66.4c36.6,0,66.4,29.8,66.4,66.4
                    C194.2,178.9,164.4,208.7,127.9,208.7z M127.9,87.3c-30.3,0-55,24.7-55,55c0,30.3,24.7,55,55,55c30.3,0,55-24.7,55-55
                    C182.9,112,158.2,87.3,127.9,87.3z"></path>
                <path d="M85.2,142.1c0.4,23.6,19.8,42.5,43.4,42.1c23.1-0.4,41.7-19,42.1-42.1c-10.2,11.8-28.1,13.1-39.9,2.8
                    c-1-0.9-1.9-1.8-2.8-2.8c-10.2-11.8-28.1-13.1-39.9-2.8C87,140.2,86.1,141.1,85.2,142.1L85.2,142.1z"></path>
                <circle cx="181.7" cy="46.7" r="10.3"></circle>
                <circle cx="153.2" cy="46.7" r="10.3"></circle>
                <path d="M125.2,55.2H73.4c-4.7,0-8.5-3.8-8.5-8.5s3.8-8.5,8.5-8.5h51.8c4.7,0,8.5,3.8,8.5,8.5S129.9,55.2,125.2,55.2z"></path>
            </symbol>
            <symbol id="icon-women-staff" viewBox="0 0 256 256">
                <g>
                    <ellipse cx="74.5" cy="128.6" rx="5" ry="7.1"></ellipse>
                    <ellipse cx="131" cy="128.6" rx="5" ry="7.1"></ellipse>
                    <path d="M183.2,170.7c1.8-4.6,2.8-8.7,3.2-12.1c9.5-2,16.7-10.9,16.7-21.6c0-1.9-0.2-3.7-0.6-5.4
                        c7-6.4,24.5-23.5,24.5-34.3c0-9.7-14.1-26.4-18.4-31.3c-12-13.6-25.5-24.6-37.1-29.9c-34.2-16-82.7-13.5-110.3,5.8
                        C39.9,56.8,26.1,83.5,24.8,93.6c-2.6,19.5,12.7,36.9,17.8,42.1c-1.3,11.8-1.6,24.6,0.2,36.7c2,13.3,7.7,22.9,17.5,29.5
                        c3.9,2.6,8.4,4.7,13.6,6.4c-12,10.6-16.8,25.4-17,26.1c-0.7,2.2,0.5,4.6,2.8,5.3c0.4,0.1,0.9,0.2,1.3,0.2c1.8,0,3.5-1.2,4.1-3
                        c0.1-0.2,5.4-16.9,18.8-25.6c0.3-0.2,0.5-0.4,0.7-0.6c3.9,0.7,8.2,1.2,12.7,1.5c3.1,0.2,6.5,0.3,9.9,0.3c15.3,0,33.1-2.5,48.5-11.3
                        c5.4,5.5,19.2,20.4,22.6,35.3c0.5,2,2.2,3.3,4.1,3.3c0.3,0,0.6,0,1-0.1c2.3-0.5,3.7-2.8,3.2-5.1c-3.7-16.1-17-31.4-23.6-38.2
                        c0.8-0.6,1.6-1.2,2.4-1.9c2.6,8.1,9.4,15.1,20.1,20.5c10,5.1,20,7.1,20.4,7.2c0.3,0.1,0.5,0.1,0.8,0.1c1.7,0,3.3-1,4-2.7
                        c0.3-0.8,7.1-18.6-1.6-33.2C204.1,178.4,195.4,173.1,183.2,170.7z M33.2,94.8c1-7.6,13.4-32.4,32.9-45.9
                        c25.4-17.7,70.1-19.9,101.8-5.1c23.6,11,50.5,44.8,50.5,53.5c0,3.4-6.2,13.5-19.7,26.1c-1.1-1.5-2.4-2.9-3.8-4
                        c0.6-16.4-2.4-32.9-8.7-48c-0.9-2.2-3.4-3.2-5.6-2.3c-2.2,0.9-3.2,3.4-2.3,5.6c5.4,12.8,8.1,26.8,8.1,40.7
                        c-0.4-0.1-0.8-0.2-1.3-0.2c-1.8-4-6-12-13.4-20.3c-2.9-3.2-6.4-6.6-10.7-9.9c-0.5-0.4-1-0.8-1.5-1.2c0,0-0.1,0-0.1-0.1
                        c-9.8-7.1-23.1-13.2-40.7-14.5c-19.2-1.4-36.4,0.8-48.7,5.9c-0.4,0.1-0.8,0.3-1.2,0.5c-7.3,3.2-12.8,7.5-15.9,12.6
                        c-0.2,0.3-0.3,0.5-0.4,0.8c-0.4,1.1-5.4,16-8.6,35.6C38.7,117.8,31.7,106.4,33.2,94.8z M155.1,91c2.4,1.5,5.1,9.8,4.1,23.3
                        c-30.8-4.4-75.4-16.3-82.9-32.5c10.9-3.7,25.7-5.3,41.8-4.1c15.4,1.2,27.3,6.3,36.2,12.7C154.6,90.6,154.9,90.8,155.1,91z
                        M97.8,204c-29.5-2-43.4-11.8-46.6-32.8c-5.1-33.5,7.8-74.3,9.3-79c1.7-2.6,4.5-5,8.1-7c5.2,11.4,21.6,21.1,48.9,28.9
                        c22.5,6.4,44.1,9.2,45,9.3c0.2,0,0.4,0,0.5,0c0.9,0,1.9-0.3,2.6-0.9c0.9-0.7,1.5-1.7,1.6-2.8c0.3-2.4,1-9.4,0.4-16.8
                        c7.4,8.9,10.4,17,10.7,17.7c0,0,0,0.1,0,0.1c0.1,0.1,0.1,0.3,0.2,0.4c0.1,0.1,0.1,0.2,0.2,0.3c0.1,0.1,0.2,0.2,0.2,0.3
                        c0.1,0.1,0.2,0.2,0.3,0.3c0.1,0.1,0.2,0.2,0.3,0.3c0.1,0.1,0.2,0.2,0.3,0.3c0.1,0.1,0.2,0.1,0.3,0.2c0.1,0.1,0.2,0.1,0.4,0.2
                        c0.1,0.1,0.2,0.1,0.4,0.1c0.1,0,0.3,0.1,0.4,0.1c0.1,0,0.2,0,0.4,0.1c0.2,0,0.3,0,0.5,0c0,0,0.1,0,0.1,0c4.9,0,9.2,3.3,11.1,7.9
                        c0.1,0.3,0.2,0.6,0.3,0.8c0.5,1.5,0.8,3.1,0.8,4.8c0,7.5-5.5,13.6-12.2,13.6c0,0-0.1,0-0.1,0c-1.1,0-2.2,0.5-2.9,1.3c0,0,0,0,0,0
                        c-0.2,0.2-0.3,0.4-0.5,0.6c0,0,0,0,0,0.1c-0.1,0.2-0.2,0.4-0.3,0.6c0,0.1-0.1,0.1-0.1,0.1c-0.1,0.2-0.1,0.4-0.2,0.6
                        c0,0.1-0.1,0.2-0.1,0.3c0,0.2,0,0.3,0,0.5c0,0.1,0,0.2,0,0.3c0,0,0,0,0,0c0,0,0,0,0,0c0.1,5.5-2.9,19-15.3,30.8
                        C148.3,199.5,125.8,205.9,97.8,204z M203.7,213.2c-3.5-1-9-2.7-14.5-5.5c-10.8-5.5-16.4-12.2-16.6-20.1c2.6-3,4.8-6.1,6.6-9.1
                        c11,1.7,18.5,5.9,22.4,12.4C206.3,198.7,205,208.2,203.7,213.2z"></path>
                    <path d="M122.8,162.7c-0.1,0.1-10.5,10.2-23.6,9.3c-5.4-0.3-10.2-3.5-12.7-8.2c-1.1-2.1-3.7-2.9-5.7-1.8
                        c-2.1,1.1-2.9,3.7-1.8,5.7c3.9,7.4,11.4,12.3,19.7,12.8c0.8,0.1,1.6,0.1,2.3,0.1c15.7,0,27.3-11.3,27.8-11.8c1.7-1.7,1.7-4.3,0-6
                        C127.2,161.1,124.5,161.1,122.8,162.7z"></path>
                    <path d="M94.3,156.8c0.8,1.4,2.2,2.1,3.7,2.1c0.7,0,1.4-0.2,2.1-0.6c2-1.2,2.7-3.8,1.6-5.8l-3.2-5.7
                        c2.2-2.3,4.7-6.1,5.7-12c0.4-2.3-1.2-4.5-3.5-4.9c-2.3-0.4-4.5,1.2-4.9,3.5c-1.1,6.4-4.8,8.8-4.9,8.8c-1,0.6-1.7,1.5-2,2.6
                        c-0.3,1.1-0.1,2.3,0.4,3.2L94.3,156.8z"></path>
                </g>
            </symbol>
            <symbol id="icon-lowest-price" viewBox="0 0 256 256">
                <path d="M173.2,72.5c-2.2-2.2-5.8-2.2-8,0l-38.3,38.3L90.8,74.6c-2.2-2.2-5.8-2.2-8,0c-2.2,2.2-2.2,5.8,0,8l38.4,38.4
                    h-29c-3.1,0-5.7,2.5-5.7,5.7c0,3.1,2.5,5.7,5.7,5.7h29V147h-29c-3.1,0-5.7,2.5-5.7,5.7s2.5,5.7,5.7,5.7h29V190
                    c0,3.1,2.5,5.7,5.7,5.7c3.1,0,5.7-2.5,5.7-5.7v-31.7h29c3.1,0,5.7-2.5,5.7-5.7s-2.5-5.7-5.7-5.7h-29v-14.6h29c3.1,0,5.7-2.5,5.7-5.7
                    c0-3.1-2.5-5.7-5.7-5.7h-29l40.6-40.6C175.4,78.3,175.4,74.7,173.2,72.5z"></path>
                <path d="M150.3,234.1c0-1,0.1-2,0.2-3C96.2,242.3,43.1,207.4,31.9,153S55.7,45.6,110,34.4s107.4,23.8,118.6,78.1
                    c4.4,21.6,1.7,44-7.9,63.9v1.3c2.9-1.6,6.2-2.5,9.5-2.5c1.1,0,2.2,0.1,3.3,0.3c23.6-57-3.6-122.3-60.6-145.8S50.7,33.2,27.2,90.2
                    s3.6,122.3,60.6,145.8c20.4,8.4,42.8,10.6,64.4,6.3C151,239.8,150.3,237,150.3,234.1z"></path>
                <path d="M232.7,226.6h-23.8l26.6-26.6c3.1-2.7,3.5-7.4,0.8-10.6s-7.4-3.5-10.6-0.8c-0.3,0.3-0.6,0.5-0.8,0.8l-16.2,16.2
                    v-39.9c0-4.1-3.4-7.5-7.5-7.5s-7.5,3.4-7.5,7.5v39.9l-16.2-16.2c-3-2.8-7.8-2.7-10.6,0.4c-2.7,2.9-2.7,7.3,0,10.2l26.6,26.6h-23.8
                    c-4.1,0-7.5,3.4-7.5,7.5s3.4,7.5,7.5,7.5h62.9c4.1,0,7.5-3.4,7.5-7.5S236.9,226.6,232.7,226.6L232.7,226.6z"></path>
            </symbol>
            <symbol id="icon-no-additional-fees" viewBox="0 0 256 256">
                <g>
                    <path d="M161.5,132.4c3.1,0,5.7-2.5,5.7-5.7c0-3.1-2.5-5.7-5.7-5.7h-29l40.6-40.6c2.2-2.2,2.2-5.8,0-8
                        c-2.2-2.2-5.8-2.2-8,0l-38.3,38.3L90.8,74.6c-2.2-2.2-5.8-2.2-8,0c-2.2,2.2-2.2,5.8,0,8l38.4,38.4h-29c-3.1,0-5.7,2.5-5.7,5.7
                        c0,3.1,2.5,5.7,5.7,5.7h29V147h-29c-3.1,0-5.7,2.5-5.7,5.7s2.5,5.7,5.7,5.7h29V190c0,3.1,2.5,5.7,5.7,5.7c3.1,0,5.7-2.5,5.7-5.7
                        v-31.7h29c3.1,0,5.7-2.5,5.7-5.7s-2.5-5.7-5.7-5.7h-29v-14.6H161.5z"></path>
                    <path d="M160.2,224c-52.3,18.4-109.6-9.1-128-61.4S41.3,53,93.6,34.6c52.3-18.4,109.6,9.1,128,61.4
                        c2.9,8.3,4.7,16.9,5.4,25.6c4.6,2.6,8.6,6.3,11.6,10.6c0-1,0-2,0-2.9c0-61.7-50-111.7-111.7-111.7S15.2,67.7,15.2,129.4
                        s50,111.7,111.7,111.7c11.4,0,22.8-1.8,33.7-5.2c-0.2-1.3-0.4-2.7-0.4-4V224z"></path>
                    <path d="M234.3,170.3v-18.6c0-13.6-11.5-24.7-25.7-24.7S183,138.1,183,151.7v18.5c-7,0.6-12.4,6.5-12.4,13.6v48
                        c0,7.5,6.1,13.7,13.7,13.7h48c7.5,0,13.7-6.1,13.7-13.7v-48C245.9,177,240.9,171.3,234.3,170.3z M208.7,138.4
                        c7.9,0,14.3,6,14.3,13.3v18.5h-28.7v-18.5C194.3,144.4,200.7,138.4,208.7,138.4z M234.6,231.8c0,1.3-1,2.3-2.3,2.3h-48
                        c-1.3,0-2.3-1-2.3-2.3v-48c0-1.3,1-2.3,2.3-2.3h48c1.3,0,2.3,1,2.3,2.3V231.8z"></path>
                </g>
            </symbol>
            <symbol id="icon-group" viewBox="0 0 256 256">
               <path d="M219.5,112.7c-4.1-4-8.8-7.1-13.8-9.3c6.4-5.5,10.5-13.7,10.5-22.8c0-16.6-13.4-30-30-30s-30,13.4-30,30
                c0,9.1,4.1,17.3,10.6,22.8c-3,1.3-5.9,3-8.6,5c-6-11.1-17.7-18.7-31.2-18.7c-13,0-24.3,7-30.5,17.3c-2.2-1.4-4.5-2.7-6.9-3.8
                c6.4-5.5,10.5-13.7,10.5-22.8c0-16.6-13.4-30-30-30S40,64,40,80.6c0,9.1,4.1,17.3,10.5,22.8c-16.9,7.5-28.6,24.4-28.6,44
                c0,8.4,5.8,15.6,14,17.5c16,3.8,32.4,4.9,48.7,3.2c-7.9,8.5-13.2,19.5-14.9,31.7c-0.3,2.4-0.5,4.8-0.4,7.2c0.1,9.6,6.8,18,16.1,20.1
                c13.6,3.2,27.4,4.8,41.4,4.8c13.9,0,27.8-1.6,41.4-4.8c9.4-2.1,16.1-10.5,16.1-20.1v-0.1c0-0.7,0-1.4,0-2.2
                c-0.5-14.3-6.3-27.2-15.3-37c17.1,2,34.4,1,51.2-3c8.2-1.9,13.9-9.1,14-17.4v-0.1C234.2,134.2,228.9,121.7,219.5,112.7z M186.1,61.9
                c10.3,0,18.7,8.4,18.7,18.7c0,10.3-8.4,18.7-18.7,18.7s-18.7-8.4-18.7-18.7S175.8,61.9,186.1,61.9z M126.8,101.1
                c13.3,0,24.1,10.8,24.1,24.1c0,13.3-10.8,24.1-24.1,24.1s-24.1-10.8-24.1-24.1S113.5,101.1,126.8,101.1z M70,61.9
                c10.3,0,18.7,8.4,18.7,18.7c0,10.3-8.4,18.7-18.7,18.7s-18.7-8.4-18.7-18.7S59.6,61.9,70,61.9z M38.5,153.8c-3-0.7-5.2-3.3-5.3-6.5
                c0-19.8,15.6-36,35.3-36.8c0.5,0,0.9,0,1.3,0c0,0,0,0,0.1,0c0.1,0,0.1,0,0.2,0c7.9,0,15.6,2.7,21.9,7.4c-0.5,2.3-0.7,4.8-0.7,7.2
                c0,10.9,5,20.7,12.7,27.2c-0.8,0.6-1.7,1.1-2.7,1.3C80.7,158.6,59.2,158.6,38.5,153.8z M173,207c-0.1,4.4-3.2,8.1-7.5,9.1
                c-25.5,6-52,6-77.5,0c-4.2-1-7.3-4.8-7.4-9.1c0-1.9,0.1-3.9,0.4-5.8c2.9-22.4,21.5-39.4,44-40.4c0.6,0,1.1,0,1.7,0c0,0,0.1,0,0.1,0
                c0,0,0.1,0,0.1,0c25.5,0.1,46.1,20.7,46.1,46.2V207z M222.8,147.3c-0.1,3.1-2.3,5.7-5.3,6.4c-20.7,4.9-42.2,4.9-62.9,0
                c-1.6-0.4-2.9-1.3-3.9-2.5c7-6.5,11.4-15.8,11.4-26.1c0-1.8-0.1-3.6-0.4-5.4c6.3-5.6,14.3-8.9,22.9-9.3c20.3-0.8,37.3,15,38.1,35.3
                C222.8,146.3,222.8,146.8,222.8,147.3L222.8,147.3z"></path>
            </symbol>
            <symbol id="icon-1-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M136.4,163c0,3.2-2.3,4.9-5.7,4.9c-3.4,0-5.8-1.7-5.8-4.8V102c0-2.2-0.6-3-2.8-2.9l-9.2,0.3
                        c-3.1,0.1-5.2-2.4-5.2-5.3c0-3.1,1.9-5.5,5-5.6l13.6-0.3c0.3,0,0.6,0,0.9,0c7.2,0,9.2,2.4,9.2,10.3V163z"></path>
                </g>
            </symbol>
            <symbol id="icon-2-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M152.2,158c2.8,0,4.3,2.1,4.3,4.9c0,2.9-1.5,5.4-4.3,5.4H106c-4.1,0-6.4-2.4-6.4-6.8c0-3.6,2.3-8.7,4.1-11.7
                        c3.4-6.4,9.2-12.6,18.7-18.8l6.5-4.4c9.7-6.4,14.3-10.1,14.3-17.6c0-7.1-5.8-11.6-14.7-11.6c-10.9,0-14.4,6.3-16.2,13
                        c-0.8,2.5-2.8,3.6-5.1,3.6c-0.7,0-1.3-0.1-1.9-0.2c-2.6-0.5-4.6-2.2-4.6-4.7c0-0.6,0.1-1.2,0.3-1.8c1-4.2,3.2-8.6,6.5-11.8
                        c4.7-4.8,11.2-7.7,21.5-7.7c15.9,0,25.8,8.1,25.8,21.4c0,12.3-7.4,17.9-17,23.9l-6.3,3.8c-10.7,6.7-17,12.9-19.5,21.1H152.2z"></path>
                </g>
            </symbol>
            <symbol id="icon-3-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M126.7,121.6c0.3,0,0.6,0,0.9,0c9.5,0,15.5-4.9,15.5-13.2c0-7.6-5.8-12.1-14.8-12.1c-8.6,0-13,3.7-15.3,9.7
                        c-0.9,2.1-2.4,2.8-4.2,2.8c-1,0-2-0.2-3-0.6c-2.3-0.7-3.7-2.2-3.7-4.2c0-0.7,0.2-1.4,0.5-2.2c3-7.4,10-14.9,26.1-14.9
                        c15.3,0,25.6,8,25.6,20.6c0,9.9-4.9,16.4-15.1,18.8c11.7,1.6,17.4,8.6,17.4,20.1c0,13.3-10.3,22.8-28.7,22.8
                        c-16.3,0-24.6-7.2-28-15.8c-0.3-0.7-0.4-1.4-0.4-2c0-2.3,1.8-4,4.3-4.7c0.9-0.2,1.7-0.3,2.4-0.3c2.2,0,3.8,1,4.8,3.3
                        c2.4,6,7.3,9.8,17.1,9.8c10,0,17.1-5.3,17.1-14.1c0-9.1-6.9-13.9-18.4-13.7l-5.6,0.1c-2.9,0.1-4.4-2.4-4.4-5.2
                        c0-2.8,1.5-5.3,4.4-5.2L126.7,121.6z"></path>
                </g>
            </symbol>
            <symbol id="icon-4-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M97.9,148.9c-3.7,0-6-2.1-6-6.1c0-3.8,1.2-5.9,3.5-9l30-40.9c2.7-3.6,4.6-5.4,9.4-5.4c3.9,0,6.4,1.8,6.4,6.4
                        v45.5h8.6c2.9,0,4.2,1.9,4.2,4.6c0,2.8-1.3,4.9-4.2,4.9h-8.6V164c0,3.1-2.1,4.6-5.4,4.6s-5.3-1.5-5.3-4.6v-15.1H97.9z M130.7,115.5
                        c0-4.7,0.3-11.5,0.8-17c-2.2,3.9-4.8,8-7.7,12.1l-17,24.1c-1.1,1.5-2.6,3.2-4.2,4.9c2.2-0.2,4.8-0.2,6.6-0.2h21.5L130.7,115.5
                        L130.7,115.5z"></path>
                </g>
            </symbol>
            <symbol id="icon-5-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M70.5,94.6c0.6-4.4,3-6.9,7.6-6.9h35.1c2.7,0,4.1,2.3,4.1,5.1c0,2.7-1.5,5-4.1,5H82.3c-1.3,0-1.9,0.6-2,1.8
                        l-1.7,16.9c-0.1,1.2-0.5,3-0.9,4.4c4.4-4.3,9.8-6.5,16.9-6.5c15.7,0,25.9,10.2,25.9,26c0,16.5-10.9,28-28,28
                        c-13.1,0-21.4-5.3-25.7-13.3c-0.6-0.9-0.8-1.8-0.8-2.7c0-2,1.3-3.8,3.1-4.8c1-0.6,2.1-0.9,3.2-0.9c1.7,0,3.3,0.8,4.5,2.8
                        c2.7,5.3,7.9,9,15.3,9c10.3,0,16.9-7.3,16.9-17.7c0-10.5-6.4-17-16.1-17c-6.7,0-11.3,2.8-14.2,7.2c-1.5,2-3,3.1-5.4,3.1
                        c-0.4,0-0.8,0-1.2-0.1c-3.1-0.3-5-1.9-5-4.8c0-0.2,0-0.5,0.1-0.8L70.5,94.6z"></path>
                    <path d="M135.2,142.9c-2.8,0-4.3-1.6-4.3-4.8c0-2.9,1.5-4.8,4.3-4.8h20.6v-19.6c0-2.9,1.7-4.4,4.7-4.4
                        c3.1,0,4.9,1.5,4.9,4.4v19.6h20.4c2.8,0,4.2,1.9,4.2,4.8c0,3.2-1.4,4.8-4.2,4.8h-20.4v20.5c0,2.9-1.8,4.4-4.9,4.4
                        c-3,0-4.7-1.5-4.7-4.4v-20.5H135.2z"></path>
                </g>
            </symbol>
            <symbol id="icon-10-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M88.9,151.3c0,2.4-1.8,3.8-4.6,3.8c-2.8,0-4.5-1.3-4.5-3.7v-39.5c0-1.2-0.3-1.8-1.5-1.8c-0.1,0-0.1,0-0.2,0
                        l-6.2,0.2c-2.4,0.1-3.9-2-3.9-4.2c0-2.4,1.5-4.4,3.8-4.4l9.6-0.2c0.2,0,0.4,0,0.6,0c5.3,0,6.9,1.7,6.9,7.5
                        C88.9,109,88.9,151.3,88.9,151.3z"></path>
                    <path d="M141.4,127.9c0,18-7.2,27.7-20.3,27.7c-13.4,0-20.2-9.6-20.2-27.9c0-17.8,7.2-27.3,20.3-27.3
                        C133.8,100.4,141.4,109,141.4,127.9z M109.9,127.8c0,12.8,3.6,19.8,11.2,19.8c7.7,0,11.2-6.7,11.2-19.8c0-12.5-3.5-19.3-11.2-19.3
                        C113.7,108.4,109.9,115.1,109.9,127.8z"></path>
                    <path d="M151.2,139.2c-2.1,0-3.3-1.3-3.3-4c0-2.5,1.2-3.8,3.3-3.8h13V119c0-2.1,1.3-3.3,3.9-3.3s3.9,1.2,3.9,3.3v12.5
                        h12.9c2.1,0,3.2,1.3,3.2,3.8c0,2.6-1.1,4-3.2,4H172v12.9c0,2.1-1.3,3.4-3.9,3.4s-3.9-1.3-3.9-3.4v-12.9h-13V139.2z"></path>
                </g>
            </symbol>
            <symbol id="icon-50-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M72.3,120.2c-0.1,0.7-0.3,1.7-0.5,2.6c2.8-2.5,6.3-3.8,10.8-3.8c10.7,0,17.6,6.8,17.6,17.7
                        c0,11.2-7.5,19-19.3,19c-9.4,0-14.9-3.8-17.7-8.9c-0.4-0.7-0.6-1.4-0.6-2c0-1.5,1-3,2.4-3.8c0.9-0.5,1.7-0.8,2.6-0.8
                        c1.3,0,2.6,0.7,3.4,2.1c1.8,3.2,5.1,5.5,9.6,5.5c6.4,0,10.4-4.5,10.4-11s-4-10.4-10-10.4c-4.1,0-6.9,1.6-8.7,4.2
                        c-1,1.5-2.2,2.2-4.2,2.2c-0.3,0-0.6,0-0.9-0.1c-2.4-0.3-3.8-1.6-3.8-3.8c0-0.2,0-0.4,0-0.6l2.2-22.3c0.4-3.2,2.2-4.9,5.5-4.9H95
                        c2,0,3,1.8,3,4c0,2.1-1.1,4-3,4H74.6c-0.8,0-1.3,0.4-1.3,1.2L72.3,120.2z"></path>
                    <path d="M146.7,127.9c0,18-7.2,27.7-20.3,27.7c-13.4,0-20.2-9.6-20.2-27.9c0-17.8,7.2-27.3,20.3-27.3
                        C139.1,100.3,146.7,109,146.7,127.9z M115.2,127.7c0,12.8,3.6,19.8,11.2,19.8c7.7,0,11.2-6.7,11.2-19.8c0-12.5-3.5-19.3-11.2-19.3
                        C119,108.4,115.2,115.1,115.2,127.7z"></path>
                    <path d="M156.5,139.2c-2.1,0-3.3-1.3-3.3-4c0-2.5,1.2-3.8,3.3-3.8h13v-12.5c0-2.1,1.3-3.3,3.9-3.3s3.9,1.2,3.9,3.3
                        v12.5h12.9c2.1,0,3.2,1.3,3.2,3.8c0,2.6-1.1,4-3.2,4h-12.9v12.9c0,2.1-1.3,3.4-3.9,3.4s-3.9-1.3-3.9-3.4v-12.9H156.5z"></path>
                </g>
            </symbol>
            <symbol id="icon-100-circle" viewBox="0 0 256 256">
               <path d="M128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9c61.8,0,112.1,50.3,112.1,112.1
                    S189.8,240.1,128,240.1z M128,27.3C72.5,27.3,27.3,72.5,27.3,128S72.5,228.7,128,228.7c55.5,0,100.7-45.2,100.7-100.7
                    S183.5,27.3,128,27.3z"></path>
                <g>
                    <path d="M66.3,151.2c0,2.4-1.8,3.8-4.6,3.8s-4.5-1.3-4.5-3.7v-39.5c0-1.2-0.3-1.8-1.5-1.8c-0.1,0-0.1,0-0.2,0l-6.2,0.2
                        c-2.4,0.1-3.9-2-3.9-4.2c0-2.4,1.5-4.4,3.8-4.4l9.6-0.2c0.2,0,0.4,0,0.6,0c5.3,0,6.9,1.7,6.9,7.5V151.2z"></path>
                    <path d="M117.4,127.9c0,18-7.2,27.7-20.3,27.7c-13.4,0-20.2-9.6-20.2-27.9c0-17.8,7.2-27.3,20.3-27.3
                        C109.8,100.3,117.4,109,117.4,127.9z M85.9,127.7c0,12.8,3.6,19.8,11.2,19.8c7.7,0,11.2-6.7,11.2-19.8c0-12.5-3.5-19.3-11.2-19.3
                        C89.7,108.4,85.9,115.1,85.9,127.7z"></path>
                    <path d="M163.9,127.9c0,18-7.2,27.7-20.3,27.7c-13.4,0-20.2-9.6-20.2-27.9c0-17.8,7.2-27.3,20.3-27.3
                        C156.3,100.3,163.9,109,163.9,127.9z M132.4,127.7c0,12.8,3.6,19.8,11.2,19.8c7.7,0,11.2-6.7,11.2-19.8c0-12.5-3.5-19.3-11.2-19.3
                        C136.1,108.4,132.4,115.1,132.4,127.7z"></path>
                    <path d="M173.7,139.2c-2.1,0-3.3-1.3-3.3-4c0-2.5,1.2-3.8,3.3-3.8h13v-12.5c0-2.1,1.3-3.3,3.9-3.3s3.9,1.2,3.9,3.3
                        v12.5h12.9c2.1,0,3.2,1.3,3.2,3.8c0,2.6-1.1,4-3.2,4h-12.9v12.9c0,2.1-1.3,3.4-3.9,3.4s-3.9-1.3-3.9-3.4v-12.9H173.7z"></path>
                </g>
            </symbol>
            <symbol id="icon-frown" viewBox="0 0 256 256">
               <path d="M128,240.1C128,240.1,128,240.1,128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9
                    c61.8,0,112.1,50.3,112.1,112.1C240,189.7,189.7,240,128,240.1z M128,27.2C72.4,27.2,27.2,72.4,27.2,128
                    c0,55.6,45.2,100.8,100.8,100.8c55.5-0.1,100.7-45.3,100.8-100.8C228.8,72.4,183.6,27.2,128,27.2z"></path>
                <circle cx="99.8" cy="107.3" r="12"></circle>
                <circle cx="156.2" cy="107.3" r="12"></circle>
                <path d="M178.7,178.1c-1.9,0-3.8-1-4.9-2.7c-8.1-13.4-26.1-22-45.8-22s-37.7,8.6-45.8,22c-1.6,2.7-5.1,3.5-7.8,1.9
                    c-2.7-1.6-3.5-5.1-1.9-7.8C82.6,152.8,104.4,142,128,142c23.6,0,45.4,10.8,55.5,27.5c1.6,2.7,0.8,6.2-1.9,7.8
                    C180.7,177.8,179.7,178.1,178.7,178.1z"></path>
            </symbol>
            <symbol id="icon-smile" viewBox="0 0 256 256">
               <path d="M128,240.1C128,240.1,128,240.1,128,240.1c-61.8,0-112.1-50.3-112.1-112.1S66.2,15.9,128,15.9
                    c61.8,0,112.1,50.3,112.1,112.1C240,189.7,189.7,240,128,240.1z M128,27.2C72.4,27.2,27.2,72.4,27.2,128
                    c0,55.6,45.2,100.8,100.8,100.8c55.5-0.1,100.7-45.3,100.8-100.8C228.8,72.4,183.6,27.2,128,27.2z"></path>
                <circle cx="99.8" cy="107.3" r="12"></circle>
                <circle cx="156.2" cy="107.3" r="12"></circle>
                <path d="M128,182c-23.6,0-45.4-10.8-55.5-27.5c-1.6-2.7-0.8-6.2,1.9-7.8c2.7-1.6,6.2-0.8,7.8,1.9
                    c8.1,13.4,26.1,22,45.8,22c19.7,0,37.7-8.6,45.8-22c1.6-2.7,5.1-3.5,7.8-1.9c2.7,1.6,3.5,5.1,1.9,7.8C173.4,171.3,151.6,182,128,182
                    z"></path>
            </symbol>
            <symbol id="curama-symbol" viewBox="0 0 20 20">
                <ellipse class="st0" cx="12.45" cy="4.7" rx="0.87" ry="0.78"></ellipse>
                <ellipse class="st0" cx="15.69" cy="4.64" rx="0.87" ry="0.78"></ellipse>
                <path class="st0" d="M19.23,14.21c-0.03-0.55-0.6-0.7-0.9-0.53c-1.13,0.75-2.48,1.25-4.26,1.49c-1.56,0.18-3.51,0.1-4.82-0.6
                    c-1.51-0.82-2.03-2.44,0.23-5.61c0.17-0.25,0.49-0.29,0.68-0.25c1.44,0.27,6.86,0.55,8.92-0.49c0.42-0.17,0.4-0.46,0.39-0.65
                    c-0.03-0.12-1.27-6.37-1.68-7.18c-0.19-0.35-0.4-0.35-0.51-0.38c-1.86-0.11-4.34,0.38-4.97,0.55C4.15,2.34,1.8,7.36,1.13,8.5
                    c-0.69,1.3-3.35,7.31,3.04,10.54c2.37,1.06,7.56,1.8,14.6-0.91c0.29-0.17,0.45-0.51,0.46-0.61C19.25,16.68,19.24,14.39,19.23,14.21
                    z M18.17,16.87c0,0.27-0.17,0.4-0.24,0.42C13.74,18.9,8.4,19.56,4.51,18c-2.6-1.35-3.3-3.03-3.37-5.19c-0.05-3.6,3.12-8.3,8.2-10.2
                    c2.12-0.9,5.18-1.46,7.02-1.51c0.23,0,0.53,0.16,0.61,0.45c0.26,0.95,0.97,4.24,1.19,5.29c0.05,0.23,0.03,0.53-0.35,0.67
                    c-1.6,0.43-5.45,0.5-7.73,0.1C9.84,7.6,9.14,7.64,8.66,8.25c-2.13,2.87-2.19,4.99-1.07,6.34c2.03,2.51,7.99,2.01,10.53,0.49
                    C18.11,15.17,18.19,16.72,18.17,16.87z"></path>
            </symbol>
        </symbol></defs>
    </svg>
    


<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-MV5S9K" class="iframe_gtm"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-MV5S9K');</script><script type="text/javascript" id="" src="<?php echo e(url('/')); ?>/files/ytag.js"></script>
<script type="text/javascript" id="">!function(b,e,f,g,a,c,d){b.fbq||(a=b.fbq=function(){a.callMethod?a.callMethod.apply(a,arguments):a.queue.push(arguments)},b._fbq||(b._fbq=a),a.push=a,a.loaded=!0,a.version="2.0",a.queue=[],c=e.createElement(f),c.async=!0,c.src=g,d=e.getElementsByTagName(f)[0],d.parentNode.insertBefore(c,d))}(window,document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init","648922258617202");fbq("set","agent","tmgoogletagmanager","648922258617202");fbq("track","PageView");</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=648922258617202&amp;ev=PageView&amp;noscript=1"></noscript>
<script type="text/javascript" id="">var __pParams=__pParams||[];__pParams.push({client_id:"414",c_1:"curama",c_2:"ClientSite"});</script>
<script type="text/javascript" id="" src="<?php echo e(url('/')); ?>/files/tr.js"></script>

    <header class="">
      <div id="top" class="header-content center-block">
        <div class="logo">
            
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>/">
                    <img src="<?php echo e(url('/')); ?>/files/img_logo.svg" height="72" width="273" alt="Living market">
                </a>
            </div>
            
        </div>
        

<a class="link-bookmarks hide-elements GA-applink" href="<?php echo e(url('/')); ?>/bookmarks/" role="button">
    <svg class="icon-s-bookmark icon-p-right icon-c-orange" role="img"><use xlink:href="#bookmark"></use>
    </svg>
    <div class="bookmark-badge-box"><span class="bookmark-badge"></span></div>
</a>
        <a href="<?php echo e(url('/')); ?>/category/" class="btn btn-category-list btn-basic"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Category list</font></font></a>

        
        <div class="link-area">
            <ul class="user-guide-menu list-unstyled">
                <li><a href="<?php echo e(url('/')); ?>/lp/shop/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Would you like to open a store?</font></font></a></li>
                <li><a href="<?php echo e(url('/')); ?>/about/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">For first-time users</font></font></a></li>
            </ul>
            <div class="text-right">
                <a class="btn btn-mypage btn-m" href="<?php echo e(url('/')); ?>/mypage/" role="button"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">My page</font></font></a>
            </div>
        </div>
        
      </div>
    </header>
    
    
        
    

    
    
    
<script type="text/javascript">
    let ajax = new XMLHttpRequest();
    let url = "<?php echo e(url('/')); ?>/files/img_moving_cargo.svg";
    if(url.length > 0) {
        ajax.open("GET", url, true);
        ajax.send();
        ajax.onload = function(e) {
            var div = document.createElement("div");
            div.innerHTML = ajax.responseText;
            document.body.insertBefore(div, document.body.childNodes[0]);
            $(document).trigger("ajaxSvgLoaded", []);
        }
    } else {
        console.log("No Cargo SVG URL link passed.");
    }
</script>

    <search-page ng-version="5.2.11"><!----><moving><!----><moving-search-pc>
<div class="container-fluid wrap-content-head">
    <div class="content center-block">
        <h1 class="ttl-main-page">
			<font style="vertical-align: inherit;">
				<font style="vertical-align: inherit;">
					Cheap move
				</font>
			</font>
		</h1>
    </div>
</div>
<div class="container-fluid wrap-filter">
    <div class="locationAndTypeForm">
        <div class="content center-block">
            <div class="wrap-filter-inner-moving clearfix">
                <dl class="filter-item-l-moving">
                    <dt class="filter-head"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Current address</font></font></dt>
                    <dd>
                        <input-location-pc class="input-moving"><input class="input-item read-only input-item-error" placeholder="Select area" readonly="" type="text">
<div class="location-modal" hidden="">
    <div class="wrap-popover-balloon">
        <div class="popover-balloon-content">
            <div class="popover-balloon-close">
                <svg class="icon-s-normal icon-p-right icon-c-gray" role="img"><use xlink:href="#close"></use></svg>
            </div>
            <dl class="popover-balloon-item wrap-select-area">
                <dt class="select-area-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Search by zip code</font></font></dt>
                <dd class="select-area-content">
                    <input-postalcode-pc><form name="inputPostalcodeForm" novalidate="" class="ng-untouched ng-pristine ng-valid">
    <input class="input-pcode read-only ng-untouched ng-pristine ng-valid" formcontrolname="postalcode" id="id_postalcode" maxlength="8" name="postalcode" placeholder="1500031" type="text"><button class="btn btn-attention btn-pcode disabled">
        <svg class="icon-s-normal icon-p-right icon-c-white" role="img"><use xlink:href="#search"></use></svg>
    </button>
    <!---->
</form>
</input-postalcode-pc>
                </dd>
                <dt class="select-area-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Search by prefecture</font></font></dt>
                <dd class="select-area-content">
                    <location-selector-pc class="location-modal"><!---->
<!----><div>
    <!----><!---->
        <p class="current-area">
            <a>
                <svg class="icon-s-normal icon-p-left icon-c-link" role="img"><use xlink:href="#arrow_back"></use></svg><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                Tokyo
            </font></font></a>
        </p>
    
    <ul class="area-navi list-unstyled">
        <!----><!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn area-navi-active"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    A line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Or line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Sa line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Na line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    And line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn area-navi-disabled"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Ra line
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    My line
                </font></font></button>
            </li>
        
    </ul>
    <!----><!---->
        <ul class="list-area-name list-unstyled">
            <!----><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Oyama Nishimachi</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Otaniguchi</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Akatsuka</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Otaniguchi Kitamachi</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Otaniguchikami Town</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Inari stand</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Aioi Town</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Shodosawa</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Akatsuka Shinmachi</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ohara Town</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Izumi Town</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Itabashi</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Oyama Kanai Town</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Oyama Higashi Town</font></font></a>
                    
                </div>
                <!---->
            </li><li>
                <!----><div>
                    <!---->
                    <!----><!---->
                        <a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Oyama Town</font></font></a>
                    
                </div>
                <!---->
            </li>
        </ul>
    
</div>
</location-selector-pc>
                </dd>
            </dl>
        </div>
    </div>
</div></input-location-pc>
                        <p class="text-error"></p>
                    </dd>
                </dl>

                <dl class="filter-item-l-moving">
                    <dt class="filter-head"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Moving destination</font></font></dt>
                    <dd>
                        <input-location-pc class="input-moving-arrival"><input class="input-item read-only input-item-error" placeholder="Select area" readonly="" type="text">
<div class="location-modal" hidden="">
    <div class="wrap-popover-balloon">
        <div class="popover-balloon-content">
            <div class="popover-balloon-close">
                <svg class="icon-s-normal icon-p-right icon-c-gray" role="img"><use xlink:href="#close"></use></svg>
            </div>
            <dl class="popover-balloon-item wrap-select-area">
                <dt class="select-area-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Search by zip code</font></font></dt>
                <dd class="select-area-content">
                    <input-postalcode-pc><form name="inputPostalcodeForm" novalidate="" class="ng-untouched ng-pristine ng-valid">
    <input class="input-pcode read-only ng-untouched ng-pristine ng-valid" formcontrolname="postalcode" id="id_postalcode" maxlength="8" name="postalcode" placeholder="1500031" type="text"><button class="btn btn-attention btn-pcode disabled">
        <svg class="icon-s-normal icon-p-right icon-c-white" role="img"><use xlink:href="#search"></use></svg>
    </button>
    <!---->
</form>
</input-postalcode-pc>
                </dd>
                <dt class="select-area-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Search by prefecture</font></font></dt>
                <dd class="select-area-content">
                    <location-selector-pc class="location-modal"><!---->
<!----><div>
    <!---->
    <ul class="area-navi list-unstyled">
        <!----><!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Hokkaido
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Tohoku
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn area-navi-active"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Kanto
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Chubu
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Kinki
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    China
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Shikoku
                </font></font></button>
            </li>
        <!---->
            <li class="area-navi-list">
                <button class="area-navi-list-btn"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                    Kyushu-Okinawa
                </font></font></button>
            </li>
        
    </ul>
    <!----><!---->
        <ul class="list-area-name list-unstyled">
            <!----><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Ibaraki Prefecture
                    </font></font></a>
                    <!---->
                </div>
            </li><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Tochigi Prefecture
                    </font></font></a>
                    <!---->
                </div>
            </li><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Gunma Prefecture
                    </font></font></a>
                    <!---->
                </div>
            </li><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Saitama
                    </font></font></a>
                    <!---->
                </div>
            </li><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Chiba
                    </font></font></a>
                    <!---->
                </div>
            </li><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Tokyo
                    </font></font></a>
                    <!---->
                </div>
            </li><li>
                <!---->
                <!----><div>
                    <!----><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Kanagawa Prefecture
                    </font></font></a>
                    <!---->
                </div>
            </li>
        </ul>
    
</div>
</location-selector-pc>
                </dd>
            </dl>
        </div>
    </div>
</div></input-location-pc>
                        <p class="text-error"></p>
                    </dd>
                </dl>

                <dl class="filter-item-s-moving">
                    <dt class="filter-head"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Baggage</font></font></dt>
                    <dd>
                        <cargo-pc><input class="input-item read-only input-item-error" placeholder="Select luggage" readonly="" type="text">
<div class="cargo-modal" hidden="">
    <div class="wrap-popover-balloon">
        <div class="popover-balloon-content">
            <div class="popover-balloon-close">
                <svg class="icon-s-normal icon-p-right icon-c-gray" role="img"><use xlink:href="#close"></use></svg>
            </div>
            <dl class="popover-balloon-item wrap-cargo" style="max-height: 481px; overflow-y: auto;">
                <!----><div class="cargo-form">
                    <!----><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!----><p class="cargo-type-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Living / Bedroom</font></font></p>
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">TV less than 40 inch</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#tv"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">TV stand</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#tv-board"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bed single</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#bed-single"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">futon</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#futon"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sofa 1 person</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#sofa"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">low table</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#low-table"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Kotatsu</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#kotatsu"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Color box</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#color-box"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3-tier case, costume case</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#clothes-chest"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Small shelf</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#rack-small"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bookshelf</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#shelf"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">chest</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#chest"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Closet</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#wardrobe-small"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">computer</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#pc"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">PC desk</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#pc-desk"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">printer</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#printer"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div>
                </div><div class="cargo-form">
                    <!----><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!----><p class="cargo-type-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">bathroom</font></font></p>
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Refrigerator 2 door</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#refrigerator-2door"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!---->
            <!----><div class="cargo-title">
                <span class="grouped-cargo-title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Washing machine vertical</font></font></span>
                <span class="glyphicon glyphicon-triangle-bottom grouped-cargo-title-icon"></span>
            </div>
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#washing-machine"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div><div>
        <!---->
        <!---->
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Dining table</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#dining-table"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">chair</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#chair"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Stand mirror</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#mirror"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cupboard</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#cupboard"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Microwave oven</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#microwave-oven"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div>
                </div><div class="cargo-form">
                    <!----><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!----><p class="cargo-type-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Outdoor / Other</font></font></p>
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Air conditioner</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#aircon"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">heater</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#heater"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vacuum cleaner</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#vacuum"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Fan</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#fan"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">bicycle</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#bicycle"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Air cleaner</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#air-cleaner"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">lighting equipment</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#light"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">suitcase</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#suitcase"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!---->
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">carpet</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#carpet"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!---->
    </div>
</div>
    </cargo-selector>
                    </div>
                </div><div class="cargo-form">
                    <!----><div>
                        <cargo-selector><!---->

<!----><div>
    <!----><div>
        <!----><p class="cargo-type-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cardboard</font></font></p>
        <!----><div class="cargo-selector-box">
            <!----><div class="cargo-title">
                <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cardboard</font></font></span>
            </div>
            <!---->
            <!---->
            <div class="cargo-content">
                <svg class="cargo-illust" role="img">
                    <use xlink:href="#cardboard"></use>
                </svg>
                <div class="cargo-counter">
                    <span class="cargo-counter-left"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-</font></font></span>
                    <span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">0</font></font></span>
                    <span class="cargo-counter-right"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">+</font></font></span>
                </div>
            </div>
        </div>
        <!----><div class="cargo-selector-box">
            <div class="cardboard-discription">
                <p class="cardboard-label"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Estimated number of pieces</font></font></p>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1 person ... 10 to 15 pieces</font></font></p>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2 people ... 20 ~ 30</font></font></p>
                <p><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">3 people ... 50 or more</font></font></p>
            </div>
        </div>
    </div>
</div>
    </cargo-selector>
                    </div>
                </div>
                <div class="cargo-submit">
                    <button class="btn btn-attention btn-cargo"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Selection completed</font></font></button>
                </div>
            </dl>
        </div>
    </div>
</div></cargo-pc>
                    </dd>
                </dl>

                <dl class="filter-item-s-moving">
                    <dt class="filter-head"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Operator</font></font></dt>
                    <dd>
                        <headcount-pc><input class="input-item read-only" placeholder="Operator" readonly="" type="text">
<div class="moving-head-count" hidden="">
    <div class="wrap-popover-balloon">
        <div class="popover-balloon-content">
            <div class="popover-balloon-close">
                <svg class="icon-s-normal icon-p-right icon-c-gray" role="img"><use xlink:href="#close"></use></svg>
            </div>
            <div class="popover-balloon-item wrap-select-type-moving">
                <div>
                    <!----><button class="btn-head-count "><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">2 people</font></font></button><button class="btn-head-count  btn-head-count-active"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">1 person</font></font></button>
                </div>
            </div>
        </div>
    </div>
</div></headcount-pc>
                    </dd>
                </dl>

                <dl class="filter-item-moving">
                    <dt class="filter-head"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Schedule</font></font></dt>
                    <dd id="calendar_selector">
                        <search-calendar-pc><div class="content-detail-filter">
    <div class="wrap-inner-icon">
        <input-datepicker datepicker-class="wrap-popover-balloon" focus-class="input-focus" input-class="input-date" maxdate="+2m" mindate="0d" placeholder="unspecified"><input class="input-item read-only hasDatepicker input-date" readonly="" type="text" id="dp1590762962715" placeholder="unspecified">
<svg class="icon-s-normal icon-p-inner icon-c-gray" role="img"><use xlink:href="#event"></use></svg>
<!----></input-datepicker>
    </div>
</div>
</search-calendar-pc>
                    </dd>
                </dl>
                <div class="moving-search-btn">
                    <button class="btn btn-attention btn-filter-action" id="search-button" type="button" disabled=""><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
                        Search
                    </font></font></button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="content center-block">
    <div class="left-content">
        <a class="box-block" href="<?php echo e(url('/')); ?>/lp/shop/?link_from=service_list" target="_blank">
            <div class="bnr-shop">
                <p><font style="vertical-align: inherit;"></font><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Let's open a store in the </font><font style="vertical-align: inherit;">living market</font></font></p>
            </div>
        </a>
    </div>

    <div class="right-content">        
        <!---->

        <!---->
        <!---->
        <!---->
        <!---->

        <!---->
        <!---->

        <search-result><!---->
<!---->
</search-result>
    </div>
</div>
</moving-search-pc>
<!----></moving>
<!---->
</search-page>
<footer>
      <div class="footer-content center-block">
        <a class="pagetop pagetop-fix" href="#top" style="display: block;"></a>
        <div class="footer-link">
          <div class="box-link">
          <h4 class="link-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Popular categories</font></font><span><a href="/category/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Category list</font></font></a></span></h4>
            <div class="clearfix">
              <ul class="list-left list-unstyled pull-left">
                <li><a href="/disposal/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Collection</font></font></a></li>
                <li><a href="/aircon/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Air conditioner cleaning</font></font></a></li>
                <li><a href="/house/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">House cleaning</font></font></a></li>
                <li><a href="/house/vacancy/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Vacancy cleaning</font></font></a></li>
                <li><a href="/water-cleaning/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cleaning around water (set plan)</font></font></a></li>
                <li><a href="/bath/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bath (bath) cleaning</font></font></a></li>
                <li><a href="/fan/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ventilation fan cleaning</font></font></a></li>
              </ul>
              <ul class="list-right list-unstyled pull-left">
                <li><a href="/washer/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Washing machine cleaning</font></font></a></li>
                <li><a href="/moving/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Cheap move</font></font></a></li>
                <li><a href="/housekeeping/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Housekeeping / Housekeeper</font></font></a></li>
                <li><a href="/rip/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Rearrangement</font></font></a></li>
                <li><a href="/tatami/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Refolding tatami mat (table change)</font></font></a></li>
                <li><a href="/aircon-install/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Air conditioner installation</font></font></a></li>
                <li><a href="/tv-antenna-install/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Antenna construction / installation</font></font></a></li>
              </ul>
            </div>
          </div>
          <div class="box-link">
            <h4 class="link-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">About living market</font></font></h4>
            <ul class="list-unstyled">
              <li><a href="/terms/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Terms of service</font></font></a></li>
              <li><a href="/privacy/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">privacy policy</font></font></a></li>
              <li><a href="/security/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Information security policy</font></font></a></li>
              <li><a href="/magazine/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Living Market Magazine</font></font></a></li>
              <li><a href="https://www.minma.jp/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Operating company</font></font></a></li>
            </ul>
            <h4 class="link-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Help &amp; Guide</font></font></h4>
            <ul class="list-unstyled">
              <li><a href="/about/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">For first-time users</font></font></a></li>
              <li><a href="/safety/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Safety and security of the living market</font></font></a></li>
              <li><a href="/guarantee/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Damage compensation system</font></font></a></li>
              <li><a href="https://faq.<?php echo e(url('/')); ?>/" target="_blank"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">help</font></font></a></li>
            </ul>
          </div>
          <div class="box-link">
            <h4 class="link-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">About opening a store</font></font></h4>
            <ul class="list-unstyled">
                <li><a href="/lp/shop/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Would you like to open a store in the Living Market?</font></font></a></li>
              <li><a href="/shop/"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Store management system login</font></font></a></li>
            </ul>
             <h4 class="link-ttl"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Official SNS</font></font></h4>
            <ul class="list-unstyled">  
                <li>
                    <a href="https://www.instagram.com/<?php echo e(url('/')); ?>/" target="_blank">
                        <svg class="link-insta-icon" role="img"><use xlink:href="#Gradient"></use></svg>
                    </a>
                </li>
            </ul>
            <img class="footer-isms" src="<?php echo e(url('/')); ?>/files/SGS_ISO-IEC_27001_with_ISMS-AC_TCL_LR.jpg" height="58" width="100" alt="ISMS-AC certification symbol">
          </div>
        </div>
      </div>
      <div class="wrap-copyright"><p class="copyright center-block text-right">
<span class="copy-size"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">©</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> 2011 </font></font><script>new Date().getFullYear()>2011&&document.write("-"+new Date().getFullYear());</script><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">-2020 minma Inc.
</font></font></p></div>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="https://cdn.curama.jp/static/pc/vendor/jquery-1.11.2.min.js"><\/script>')</script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://cdn.curama.jp/static/pc/vendor/jquery.hoverIntent.js"></script>
    <script src="https://cdn.curama.jp/static/pc/js/megahoverover.js"></script>
    <script src="https://cdn.curama.jp/static/pc/js/pagetop.js"></script>
    <div style="display: none">
        
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-23433297-4', 'auto');
    

</script>

        
    
<script>
    
    ga('set', 'contentGroup3', 'moving');
    
</script>


        
<script>
    ga('require', 'displayfeatures');
    ga('require', 'linkid', 'linkid.js');
    ga('send', 'pageview');
</script>

    </div>


    <script type="text/javascript">
        window.configuration = {
            scriptsUrl: "https://cdn.curama.jp/js/"
        };
    </script>
    
    <link rel="stylesheet" href="https://cdn.curama.jp/static/pc/css/curama-datepicker-theme.css">
    <script src="https://cdn.curama.jp/vendor/spin.js/spin.min.js"></script>
    <script src="https://cdn.curama.jp/vendor/svg4everybody/dist/svg4everybody.min.js"></script>
    <script>
        $(document).bind("ready, ajaxSvgLoaded", function() {
            svg4everybody();
        }); 
    </script>
    <script type="text/javascript">
       "use strict";
       var __caq = __caq || [];
       __caq.push(
            ['setExtras', {
                lr: "search-init",
                md: "pc"
            }],
            ['trackPageVisit']
        );
       (function() {
           var script = document.createElement("script");
           script.src = "https://cdn.curama.jp/js/dist/trackerBundle.js";
           document.body.appendChild(script);
       })();
   </script>

    <script>
        "use strict";
        window.module = 'aot';
        window.pageData = {"locationId":"aa99666f-ad64-46ce-81d0-5d1661728a53","serviceTypeId":"ee26d47a-a03a-4f26-814e-c7e3a13c0fd1","searchDuration":1};
        window.config = {"parentCategory":{"related_service_type_ids":["0b9d8ebf-61bc-4914-a618-24b67f913451","fe388254-e283-478f-9564-e178864c0c06","75bef101-aa73-48b4-b964-5c909c237577","99cb860e-8dfd-4a22-b121-61a1bd9abebb","d5d650d8-1ef5-4ef2-8e7f-358c6a506192","45c7585c-f3d3-4049-b2ca-29304386b2ac","30cd63bc-27b6-4d78-95bf-4a0271b4a324"],"undertakings":[],"components":[{"id":"7fa30bc3-df4a-4df5-ad39-aaf4d335b912","sort":1,"quantity":{"id":"4ed9303f-964c-46b6-b21c-24a023876e78"},"units":[],"component_type_id":3},{"id":"1168d27a-0156-430d-87e5-8b87f2e798fb","sort":2,"quantity":{"id":"5c101dbc-a66d-4bdf-a2fe-76a8c2c20826"},"units":[],"component_type_id":4},{"id":"0ac66300-fda8-4e1e-ae71-2b937af9b0cc","sort":3,"quantity":{"id":"1e68dbb2-7203-41cd-87cf-75e9d8fc3300"},"units":[],"component_type_id":6},{"id":"3ec7fb0e-d8a2-4189-a44d-004ba6bd802a","sort":4,"quantity":{"id":"18af6eb9-62fa-410b-9069-8cba09fa57ca"},"units":[],"component_type_id":6}],"features":[],"is_large_category":false,"include_item_details":true,"css_name":null,"name":"格安引越し","slug":"moving","status_id":3,"has_product":false,"questions":[],"sort":13,"service_type_market_prices":[{"market_price_lower":10600,"id":"c3fe90e4-1856-467d-bba3-0b94760c2711","market_price_upper":16600,"label":"10km","sort":1},{"market_price_lower":12600,"id":"09a3dcb8-907f-4194-89c2-6b899fcde322","market_price_upper":18600,"label":"20km","sort":2},{"market_price_lower":14600,"id":"71fc4581-5ef8-4481-908e-ff5549dcccfa","market_price_upper":20600,"label":"30km","sort":3},{"market_price_lower":16600,"id":"662a7f1b-831d-4f10-b4f5-c8a6adb57199","market_price_upper":22600,"label":"40km","sort":4}],"is_order":false,"use_price_filter":true,"licenses":[],"parent_id":"d501f3c1-b62f-445d-8be4-1b8bc77137e0","billing_type_id":1,"product_info":null,"attachments":[],"headcounts":[{"amount":2,"name":"2名","id":"0e155093-0ed3-49ac-8a68-9272d8e8c811","isDefault":false},{"amount":1,"name":"1名","id":"4d29fa0f-ae77-4220-a4f2-01724edff11e","isDefault":true}],"pattern_id":3,"flowsteps":[],"id":"ee26d47a-a03a-4f26-814e-c7e3a13c0fd1","service_type_detail":{"id":"4523a0a2-36a1-4598-bec7-e19c37855022","description":"単身からファミリーまで、家具の運び出しも安心・丁寧なプロの技で引越しをお手伝いします。","reservation_point":"引越し元から引越し先までの距離と運びたい荷物の量から、自分にあったサービスを選んで予約しましょう。ただし、事前に伝えていた家具や家電より荷物が多くてトラックに乗りきらないなどの理由で、当日に追加料金が発生することがあります。前日までにしておかなければいけないことやトラックに乗る荷物量は必ず事前に確認をしておきましょう。作業員の人数は「手伝うから少しでも安くしたい！」という方は1名、「少しでも楽をしたい！」という方は2名を選ぶことをおすすめします。例年、3月ごろの繁忙期には予約が集中するので、早めに予約したり時期をずらしたりすることで、希望の日程で予約しやすくなります。","request_to_stores":"部屋からの運び出し・積み込み・積み下ろし / 養生","merit":"くらしのマーケットの格安引越しでは、多くの引越し比較サイトにありがちな、登録直後に大量の見積もり電話やメールに悩まされることもありません。距離と荷物量の明朗でお手頃な料金で引越しをすることができます。料金だけではなく、実際に利用した人の口コミも参考にして選びましょう。サービスによっては女性スタッフを指定することもできるので、一人暮らしの女性やお年寄りの方でも安心です。","about":"引越しを料金や相場、口コミで比較し、オンラインで予約することができます。\r\n引越し元と引越し先、荷物を入力することで大手の引越し会社ではできない、格安の引越しサービスが見つかります。単身（一人暮らし）引越しから二人暮らしや家族での引越し、荷物配送にご利用ください。","default_request_to_customers":"・梱包はお客様自身でお願いいたします。\r\n\r\n＜ご予約に関する注意事項＞\r\n・直前でのご予約には対応できません。最低3日以上の余裕をもって、ご予約ください。\r\n・ご予約の日時が、当社の営業時間内であることをご確認ください。\r\n・予約の日程候補は、なるべく日時をずらしてください。\r\n・予約が集中し、ご希望の日時に伺えない場合がございます。その場合は、[メッセージ]にて改めて日時をお伺いします。","request_to_stores_for_store":"部屋からの運び出し・積み込み・積み下ろし / 養生 / 軽トラック以上","default_change_and_cancel":"予約成立後の変更・キャンセルは、作業の6日前まで承ります。\n期限を過ぎてのキャンセルは、5日前から2日前までは予約金額の25%、前日までは50%、それ以降は100%のキャンセル料が発生することがございますので、ご了承ください。","service_details":null,"about_detail":"引越しや配送、荷物の運搬をプロに依頼できるサービスです。一人暮らしで荷物が少ない方、近距離引越しで細かい荷物は自分たちで運べるという方、二人暮らしや小さなお子様がいる家族など様々な利用シーンにあった最適なサービスが見つかります。オフィスの移転に伴う引越しは、大手の引越しよりおトクな<a href=\"/office-moving/\" target=\"_blank\">オフィスの移転・引越しサービス</a>がおすすめです。また、引越しに伴って出る不用品の回収や退去前・入室前のクリーニングには、<a href=\"/disposal/\" target=\"_blank\">不用品回収</a>や<a href=\"/house/\" target=\"_blank\">ハウスクリーニング</a>も一緒に検討してみてはいかがでしょうか。"},"types":[],"search_duration":1,"hasChild":false,"distancePrice":200,"cargoes":[{"slugGroup":["tv-40"],"step":1,"firstItemOfType":true,"name":"テレビ\n40型未満","y":55,"sort":1,"z":22,"point":11,"x":90,"id":"2fe32433-ae24-408c-b29e-a32337f1f606","slug":"tv","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"テレビ\n40型以上","y":68,"sort":2,"z":30,"point":23,"x":112,"id":"d94ca4cc-e908-4a77-9741-a46763c5031a","slug":"tv-40","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"テレビ台","y":35,"sort":3,"z":37,"point":13,"x":100,"id":"d7a0effb-be14-4248-8a72-bb9be427849f","slug":"tv-board","cargo_type_id":1},{"slugGroup":["bed-semi-double","bed-double"],"step":1,"firstItemOfType":false,"name":"ベッド\nシングル","y":200,"sort":4,"z":45,"point":90,"x":100,"id":"9cf440a7-51df-4d7d-9cce-ba239fe834e4","slug":"bed-single","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ベッド\nセミダブル","y":200,"sort":5,"z":45,"point":108,"x":120,"id":"7115da97-1da9-4b52-ab36-06bbe5563153","slug":"bed-semi-double","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ベッド\nダブル","y":200,"sort":6,"z":45,"point":126,"x":140,"id":"2a3eb19a-2f77-451c-9e80-12285ab6a463","slug":"bed-double","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"布団","y":65,"sort":7,"z":100,"point":39,"x":60,"id":"7e0322ba-7c89-4886-bd6b-c933534d3d47","slug":"futon","cargo_type_id":1},{"slugGroup":["sofa-2","sofa-3"],"step":1,"firstItemOfType":false,"name":"ソファ 1人","y":78,"sort":8,"z":76,"point":46,"x":77,"id":"0be864b3-d7ba-4c92-b9d2-00de2208aebf","slug":"sofa","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ソファ 2人","y":77,"sort":9,"z":80,"point":86,"x":140,"id":"b7e0dd74-8049-4cbd-8606-4d7dceea005d","slug":"sofa-2","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ソファ 3人","y":77,"sort":10,"z":80,"point":111,"x":180,"id":"0f858b81-a8c0-4485-8f6e-1098b7b76602","slug":"sofa-3","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ローテーブル","y":75,"sort":11,"z":10,"point":9,"x":120,"id":"7172f542-bc74-492d-8be7-7e9a31267383","slug":"low-table","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"こたつ","y":38,"sort":12,"z":80,"point":24,"x":80,"id":"57689a28-5198-4b70-ac33-3d87b312eed3","slug":"kotatsu","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"カラーボックス","y":88,"sort":13,"z":30,"point":11,"x":42,"id":"2e2d86ac-dfde-450e-971d-e8e9cac68058","slug":"color-box","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"3段ケース・衣装ケース","y":63,"sort":14,"z":40,"point":14,"x":55,"id":"615e9649-6041-406e-a554-fad9ca260d5d","slug":"clothes-chest","cargo_type_id":1},{"slugGroup":["rack-large"],"step":1,"firstItemOfType":false,"name":"棚 小","y":90,"sort":15,"z":40,"point":23,"x":65,"id":"77bb77d1-c7fd-4371-8c1e-a6eca1fe5d35","slug":"rack-small","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"棚 大","y":180,"sort":16,"z":40,"point":47,"x":65,"id":"c5c48a85-6a8f-40c1-80ce-664d3e91054e","slug":"rack-large","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"本棚","y":181,"sort":17,"z":30,"point":48,"x":89,"id":"d62ea47b-6c7d-4856-b3ca-b6777c33cebe","slug":"shelf","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"チェスト","y":100,"sort":18,"z":42,"point":24,"x":56,"id":"0a444179-216d-4c3e-853f-d61db431234a","slug":"chest","cargo_type_id":1},{"slugGroup":["wardrobe-large"],"step":1,"firstItemOfType":false,"name":"タンス 小","y":90,"sort":19,"z":40,"point":29,"x":80,"id":"1f607eee-72e0-43bb-a400-6e5a8330a1d1","slug":"wardrobe-small","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"タンス 大","y":140,"sort":20,"z":42,"point":59,"x":100,"id":"cb8be9e7-39d8-45ef-a8d7-3edf14046c9c","slug":"wardrobe-large","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"パソコン","y":36,"sort":21,"z":42,"point":9,"x":19,"id":"d517fa88-624f-4ee4-b223-426f69cd7f5f","slug":"pc","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"PCデスク","y":72,"sort":22,"z":55,"point":48,"x":120,"id":"9617c9dc-3615-4aec-83dd-6603ca19ea9a","slug":"pc-desk","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"プリンター","y":15,"sort":23,"z":30,"point":2,"x":50,"id":"100e46e7-8284-4b91-bb7f-993b4f43ffa6","slug":"printer","cargo_type_id":1},{"slugGroup":["refrigerator-3door"],"step":1,"firstItemOfType":true,"name":"冷蔵庫\n2ドア","y":113,"sort":24,"z":59,"point":32,"x":48,"id":"89b207e3-6ff3-44ac-8554-f73653cb3813","slug":"refrigerator-2door","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"冷蔵庫\n3ドア","y":180,"sort":25,"z":69,"point":75,"x":60,"id":"3ff86f40-358d-4cda-858f-ac405fe16299","slug":"refrigerator-3door","cargo_type_id":2},{"slugGroup":["washing-machine-drum"],"step":1,"firstItemOfType":false,"name":"洗濯機 縦型","y":96,"sort":26,"z":57,"point":33,"x":60,"id":"3817b9e5-8b12-4304-9075-3399734fa128","slug":"washing-machine","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"洗濯機\nドラム型","y":110,"sort":27,"z":62,"point":48,"x":70,"id":"ef153a8a-3021-44dd-8031-91ef0aa887d1","slug":"washing-machine-drum","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ダイニングテーブル","y":63,"sort":28,"z":75,"point":35,"x":75,"id":"9c42d0b6-c6d4-405c-8819-f28931aee197","slug":"dining-table","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"イス","y":80,"sort":29,"z":55,"point":18,"x":40,"id":"5907bc03-5c90-4c0b-bdd4-988f1f2d5b3f","slug":"chair","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"スタンドミラー","y":150,"sort":30,"z":20,"point":12,"x":40,"id":"8ba43585-c4e6-4951-b1b2-a2d41b75fe1e","slug":"mirror","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"食器棚","y":178,"sort":31,"z":40,"point":43,"x":60,"id":"3f62092b-a472-48c6-96eb-b1c81dad2be6","slug":"cupboard","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"電子レンジ・\nオーブン","y":35,"sort":32,"z":39,"point":7,"x":48,"id":"926931c3-c947-4fb9-97ab-3a6b3f1f0a6d","slug":"microwave-oven","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":true,"name":"エアコン","y":25,"sort":33,"z":30,"point":18,"x":73,"id":"626d6e4f-4d5f-4ca9-a76a-672e833ca298","slug":"aircon","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ヒーター","y":64,"sort":34,"z":42,"point":7,"x":26,"id":"7f4ca055-b2b1-4b80-b013-16137e3eee3c","slug":"heater","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"掃除機","y":120,"sort":35,"z":24,"point":7,"x":25,"id":"83b722a7-458b-4952-a293-8680cc91fe0d","slug":"vacuum","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"扇風機","y":69,"sort":36,"z":36,"point":9,"x":37,"id":"ced0b772-0c0b-405d-9d57-299846727ca9","slug":"fan","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"自転車","y":109,"sort":37,"z":53,"point":105,"x":181,"id":"bf38632a-2ee0-44f4-a1af-8aa715b44063","slug":"bicycle","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"空気清浄機","y":61,"sort":38,"z":23,"point":6,"x":40,"id":"57d3add4-617f-429c-b69e-c2d8b77b1149","slug":"air-cleaner","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"照明器具","y":160,"sort":39,"z":30,"point":14,"x":30,"id":"925965ca-c0b4-4904-93d5-19a3ae9057e3","slug":"light","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"スーツケース","y":76,"sort":40,"z":29,"point":11,"x":51,"id":"6844920c-3262-411c-8039-6d5043fcf038","slug":"suitcase","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"カーペット","y":20,"sort":41,"z":200,"point":8,"x":20,"id":"7f994857-de06-4214-91e8-a83aa00a9717","slug":"carpet","cargo_type_id":3},{"slugGroup":[],"step":5,"firstItemOfType":true,"name":"ダンボール","y":34,"sort":42,"z":33,"point":6,"x":51,"id":"a3747642-6091-4725-b3fb-6c336bc136f8","slug":"cardboard","cargo_type_id":4}]},"requestedCategories":[{"isOrder":false,"isLargeCategory":false,"patternId":3,"statusId":3,"parentId":"d501f3c1-b62f-445d-8be4-1b8bc77137e0","searchDuration":1,"id":"ee26d47a-a03a-4f26-814e-c7e3a13c0fd1","hasProducts":false,"usePriceFilter":true,"path":"/moving/","slug":"moving","name":"格安引越し"}],"categorySlug":"moving","serviceTypeSlug":null,"requestedCategoryNames":["格安引越し"],"requestedLocationNames":[],"isMobile":false,"isCampaign":false,"headCounts":[{"amount":2,"name":"2名","id":"0e155093-0ed3-49ac-8a68-9272d8e8c811","isDefault":false},{"amount":1,"name":"1名","id":"4d29fa0f-ae77-4220-a4f2-01724edff11e","isDefault":true}],"cargoes":[{"slugGroup":["tv-40"],"step":1,"firstItemOfType":true,"name":"テレビ\n40型未満","y":55,"sort":1,"z":22,"point":11,"x":90,"id":"2fe32433-ae24-408c-b29e-a32337f1f606","slug":"tv","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"テレビ\n40型以上","y":68,"sort":2,"z":30,"point":23,"x":112,"id":"d94ca4cc-e908-4a77-9741-a46763c5031a","slug":"tv-40","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"テレビ台","y":35,"sort":3,"z":37,"point":13,"x":100,"id":"d7a0effb-be14-4248-8a72-bb9be427849f","slug":"tv-board","cargo_type_id":1},{"slugGroup":["bed-semi-double","bed-double"],"step":1,"firstItemOfType":false,"name":"ベッド\nシングル","y":200,"sort":4,"z":45,"point":90,"x":100,"id":"9cf440a7-51df-4d7d-9cce-ba239fe834e4","slug":"bed-single","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ベッド\nセミダブル","y":200,"sort":5,"z":45,"point":108,"x":120,"id":"7115da97-1da9-4b52-ab36-06bbe5563153","slug":"bed-semi-double","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ベッド\nダブル","y":200,"sort":6,"z":45,"point":126,"x":140,"id":"2a3eb19a-2f77-451c-9e80-12285ab6a463","slug":"bed-double","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"布団","y":65,"sort":7,"z":100,"point":39,"x":60,"id":"7e0322ba-7c89-4886-bd6b-c933534d3d47","slug":"futon","cargo_type_id":1},{"slugGroup":["sofa-2","sofa-3"],"step":1,"firstItemOfType":false,"name":"ソファ 1人","y":78,"sort":8,"z":76,"point":46,"x":77,"id":"0be864b3-d7ba-4c92-b9d2-00de2208aebf","slug":"sofa","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ソファ 2人","y":77,"sort":9,"z":80,"point":86,"x":140,"id":"b7e0dd74-8049-4cbd-8606-4d7dceea005d","slug":"sofa-2","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ソファ 3人","y":77,"sort":10,"z":80,"point":111,"x":180,"id":"0f858b81-a8c0-4485-8f6e-1098b7b76602","slug":"sofa-3","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ローテーブル","y":75,"sort":11,"z":10,"point":9,"x":120,"id":"7172f542-bc74-492d-8be7-7e9a31267383","slug":"low-table","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"こたつ","y":38,"sort":12,"z":80,"point":24,"x":80,"id":"57689a28-5198-4b70-ac33-3d87b312eed3","slug":"kotatsu","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"カラーボックス","y":88,"sort":13,"z":30,"point":11,"x":42,"id":"2e2d86ac-dfde-450e-971d-e8e9cac68058","slug":"color-box","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"3段ケース・衣装ケース","y":63,"sort":14,"z":40,"point":14,"x":55,"id":"615e9649-6041-406e-a554-fad9ca260d5d","slug":"clothes-chest","cargo_type_id":1},{"slugGroup":["rack-large"],"step":1,"firstItemOfType":false,"name":"棚 小","y":90,"sort":15,"z":40,"point":23,"x":65,"id":"77bb77d1-c7fd-4371-8c1e-a6eca1fe5d35","slug":"rack-small","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"棚 大","y":180,"sort":16,"z":40,"point":47,"x":65,"id":"c5c48a85-6a8f-40c1-80ce-664d3e91054e","slug":"rack-large","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"本棚","y":181,"sort":17,"z":30,"point":48,"x":89,"id":"d62ea47b-6c7d-4856-b3ca-b6777c33cebe","slug":"shelf","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"チェスト","y":100,"sort":18,"z":42,"point":24,"x":56,"id":"0a444179-216d-4c3e-853f-d61db431234a","slug":"chest","cargo_type_id":1},{"slugGroup":["wardrobe-large"],"step":1,"firstItemOfType":false,"name":"タンス 小","y":90,"sort":19,"z":40,"point":29,"x":80,"id":"1f607eee-72e0-43bb-a400-6e5a8330a1d1","slug":"wardrobe-small","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"タンス 大","y":140,"sort":20,"z":42,"point":59,"x":100,"id":"cb8be9e7-39d8-45ef-a8d7-3edf14046c9c","slug":"wardrobe-large","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"パソコン","y":36,"sort":21,"z":42,"point":9,"x":19,"id":"d517fa88-624f-4ee4-b223-426f69cd7f5f","slug":"pc","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"PCデスク","y":72,"sort":22,"z":55,"point":48,"x":120,"id":"9617c9dc-3615-4aec-83dd-6603ca19ea9a","slug":"pc-desk","cargo_type_id":1},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"プリンター","y":15,"sort":23,"z":30,"point":2,"x":50,"id":"100e46e7-8284-4b91-bb7f-993b4f43ffa6","slug":"printer","cargo_type_id":1},{"slugGroup":["refrigerator-3door"],"step":1,"firstItemOfType":true,"name":"冷蔵庫\n2ドア","y":113,"sort":24,"z":59,"point":32,"x":48,"id":"89b207e3-6ff3-44ac-8554-f73653cb3813","slug":"refrigerator-2door","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"冷蔵庫\n3ドア","y":180,"sort":25,"z":69,"point":75,"x":60,"id":"3ff86f40-358d-4cda-858f-ac405fe16299","slug":"refrigerator-3door","cargo_type_id":2},{"slugGroup":["washing-machine-drum"],"step":1,"firstItemOfType":false,"name":"洗濯機 縦型","y":96,"sort":26,"z":57,"point":33,"x":60,"id":"3817b9e5-8b12-4304-9075-3399734fa128","slug":"washing-machine","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"洗濯機\nドラム型","y":110,"sort":27,"z":62,"point":48,"x":70,"id":"ef153a8a-3021-44dd-8031-91ef0aa887d1","slug":"washing-machine-drum","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ダイニングテーブル","y":63,"sort":28,"z":75,"point":35,"x":75,"id":"9c42d0b6-c6d4-405c-8819-f28931aee197","slug":"dining-table","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"イス","y":80,"sort":29,"z":55,"point":18,"x":40,"id":"5907bc03-5c90-4c0b-bdd4-988f1f2d5b3f","slug":"chair","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"スタンドミラー","y":150,"sort":30,"z":20,"point":12,"x":40,"id":"8ba43585-c4e6-4951-b1b2-a2d41b75fe1e","slug":"mirror","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"食器棚","y":178,"sort":31,"z":40,"point":43,"x":60,"id":"3f62092b-a472-48c6-96eb-b1c81dad2be6","slug":"cupboard","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"電子レンジ・\nオーブン","y":35,"sort":32,"z":39,"point":7,"x":48,"id":"926931c3-c947-4fb9-97ab-3a6b3f1f0a6d","slug":"microwave-oven","cargo_type_id":2},{"slugGroup":[],"step":1,"firstItemOfType":true,"name":"エアコン","y":25,"sort":33,"z":30,"point":18,"x":73,"id":"626d6e4f-4d5f-4ca9-a76a-672e833ca298","slug":"aircon","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"ヒーター","y":64,"sort":34,"z":42,"point":7,"x":26,"id":"7f4ca055-b2b1-4b80-b013-16137e3eee3c","slug":"heater","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"掃除機","y":120,"sort":35,"z":24,"point":7,"x":25,"id":"83b722a7-458b-4952-a293-8680cc91fe0d","slug":"vacuum","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"扇風機","y":69,"sort":36,"z":36,"point":9,"x":37,"id":"ced0b772-0c0b-405d-9d57-299846727ca9","slug":"fan","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"自転車","y":109,"sort":37,"z":53,"point":105,"x":181,"id":"bf38632a-2ee0-44f4-a1af-8aa715b44063","slug":"bicycle","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"空気清浄機","y":61,"sort":38,"z":23,"point":6,"x":40,"id":"57d3add4-617f-429c-b69e-c2d8b77b1149","slug":"air-cleaner","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"照明器具","y":160,"sort":39,"z":30,"point":14,"x":30,"id":"925965ca-c0b4-4904-93d5-19a3ae9057e3","slug":"light","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"スーツケース","y":76,"sort":40,"z":29,"point":11,"x":51,"id":"6844920c-3262-411c-8039-6d5043fcf038","slug":"suitcase","cargo_type_id":3},{"slugGroup":[],"step":1,"firstItemOfType":false,"name":"カーペット","y":20,"sort":41,"z":200,"point":8,"x":20,"id":"7f994857-de06-4214-91e8-a83aa00a9717","slug":"carpet","cargo_type_id":3},{"slugGroup":[],"step":5,"firstItemOfType":true,"name":"ダンボール","y":34,"sort":42,"z":33,"point":6,"x":51,"id":"a3747642-6091-4725-b3fb-6c336bc136f8","slug":"cardboard","cargo_type_id":4}]};
    </script>
    
        <script src="https://cdn.curama.jp/js/dist/searchAotBundle.js"></script>
    

    <script src="https://cdn.curama.jp/static/pc/js/accordion.js"></script>
    <script>
        "use strict";
        //ローディングアニメーション
        function loopAnimation(id, className, delay) {
            var element = document.getElementById(id);
            if (!element) {
                return;
            }
            element.addEventListener("animationend", listener);

            function listener(event) {
                event.target.classList.remove(className);
                setTimeout(playAnimation, delay);
            }

            function playAnimation() {
                element.classList.add(className);
            }
        }

        loopAnimation("js-loading-animate", "loading-animate", 100);
    </script>
    <script>
        "use strict";
        $(function () {
            var fixObject = $('.wrap-filter'),
                offset = fixObject.offset();

            $(window).scroll(function () {
              if($(window).scrollTop() > offset.top) {
                fixObject.addClass('js-fixed');
              } else {
                fixObject.removeClass('js-fixed');
              }
            });
        });
    </script>
    <script src="https://cdn.curama.jp/common/js/check_postalcode_and_request.js"></script>
    <script>
        window.ParsleyConfig = {
            trigger: 'keyup change',
            errorsWrapper: '<p class="text-error"></p>',
            errorTemplate: '<span></span>'
        };
    </script>


    <script src="https://cdn.curama.jp/js/bookmark/bookmark.js" defer></script>    
    <script>
        "use strict";
        function callbackBadge(badgeCount) {
            if (badgeCount === "") {
                $('.link-bookmarks').addClass("hide-elements");
            } else {
                $('.bookmark-badge').text(badgeCount);
                $('.link-bookmarks').removeClass("hide-elements");
            }
        }
    </script>
    <script>
        "use strict";
        $(document).on("click", ".GA-applink", function () {
            ga('send', 'event', 'bookmarkbtn', 'bookmark-click', 'bookmark-badge-pc');
        });
    </script>
    
    
    
        
<script type="text/javascript">
    function reEnableButtons() {
        $("button[id!=search-button], input").each(function() {
            var $button = $(this);
            if ($button.attr("type") === "hidden") {
                return;
            }
            $button.prop("disabled", false);
        })
    }
    $(window).on("load pageshow", reEnableButtons);
</script>

    
    

<script type="text/javascript">
  (function () {
    var tagjs = document.createElement("script");
    var s = document.getElementsByTagName("script")[0];
    tagjs.async = true;
    tagjs.src = "https://s.yjtag.jp/tag.js#site=CSptNOu";
    s.parentNode.insertBefore(tagjs, s);
  }());
</script>
<noscript>
  <iframe src="https://b.yjtag.jp/iframe?c=CSptNOu" class="iframe_ytm"></iframe>
</noscript>

</body>
</html>
<?php /**PATH /home/onbiponi/public_html/curama/resources/views/welcome.blade.php ENDPATH**/ ?>