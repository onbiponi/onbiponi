		@auth
		<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
			@csrf
		</form>
		<form id="delete-form" action="#" method="POST" style="display: none;">
			@csrf
			@delete
		</form>
		@endauth
	</div> <!--end of content-->
	<!-- Scripts -->
	<script src="{{ asset('js/app.js') }}?{{ time() }}"></script>
	<!-- Smooth Scroll -->
	<!-- Data aos -->
	<script src="https://narayanganjclubltd.com/js/aos.js"></script>
	<script>AOS.init({once: true});</script>
	<!-- /Data aos -->
	<script src="{{ asset('js/smooth-scroll.js') }}"></script>
	<script src="{{ asset('js/theme.js') }}"></script>
	<script src="{{ asset('js/script.js') }}?{{ time() }}"></script>
	@yield('script')
</body>
</html>