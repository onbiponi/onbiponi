<header>
	<div class="row">
		<div class="col-6">
			<img src="{{ asset('images/logo.png') }}" />
		</div>
		<div class="col-6">
			<ul class="header-list">
                <li>
					<a href="/lp/shop/">Would you like to open a store?</a>
				</li>
                <li>
					<a href="/about/">For first-time users</a></li>
            </ul>
		</div>
	</div>
</header>